# Bodega · Control de materiales, herramientas y préstamos

Aplicación web hecha con **React (Vite)**, **Django + Django REST Framework** y **MySQL 8**. Implementa las 14 pantallas de los mockups y reutiliza `bodega.css` tal cual.

```
bodega/
├── backend/                 Django (API REST)
│   ├── config/              settings.py (BD por variables de entorno), urls.py
│   ├── usuarios/            Usuario con roles, login JWT, cambio de contraseña, perfil
│   ├── inventario/          Bodegas (ubicación, capacidad, responsable), categorías, ítems, stock, movimientos, seed
│   ├── prestamos/           Solicitudes → entrega → devolución, dashboard, tests
│   └── reportes/            Reportes filtrables: inventario, movimientos y préstamos
├── frontend/                React
│   └── src/
│       ├── api/client.js    fetch + JWT con refresco automático
│       ├── context/         sesión del usuario (AuthContext)
│       ├── components/      Layout (menú agrupado y responsivo), DataTable, Filtros, Gráficos, modales
│       ├── pages/           una página por mockup
│       └── styles/          bodega.css (original) + app.css (complementos)
├── docs/
│   ├── crear_base_mysql.sql crea la base y el usuario en MySQL
│   └── esquema.sql          esquema SQL de las tablas (referencia)
└── docker-compose.yml       MySQL + backend + frontend
```

---

## Opción A · Levantar todo con Docker (lo más rápido)

```bash
docker compose up --build
```

- Frontend: http://localhost:5173
- API: http://localhost:8000/api/
- Admin de Django: http://localhost:8000/admin/

La primera vez se crean las tablas y se cargan datos de demostración.

## Opción B · Instalación manual

### 1. Base de datos (MySQL 8)

Necesitas un servidor MySQL 8 (MySQL Community Server, XAMPP/Laragon con MySQL, o el de Docker).
Crea la base y el usuario ejecutando como root:

```bash
mysql -u root -p < docs/crear_base_mysql.sql
```

o pega el contenido de `docs/crear_base_mysql.sql` en MySQL Workbench / phpMyAdmin. Crea:

```sql
CREATE DATABASE bodega CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'bodega'@'localhost' IDENTIFIED BY 'bodega';
GRANT ALL PRIVILEGES ON bodega.* TO 'bodega'@'localhost';
```

Si usas otro usuario, contraseña o puerto, cámbialos en `backend/.env`.

### 2. Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                # edita los datos de conexión si es necesario
python manage.py migrate            # crea las tablas en MySQL
python manage.py seed               # datos de demostración (opcional)
python manage.py runserver          # http://localhost:8000
```

### 3. Frontend (en otra terminal)

```bash
cd frontend
npm install
npm run dev                         # http://localhost:5173
```

Vite redirige `/api` a `http://localhost:8000`, así que no hay que configurar CORS en desarrollo.

### Conexión a MySQL

- La conexión se configura en `backend/.env` (`DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT=3306`).
- El driver es **PyMySQL** (100 % Python): se instala con `pip` sin compilar nada, también en Windows.
  Se activa en `backend/config/__init__.py`.
- Las tablas usan `utf8mb4` (tildes y ñ) y motor InnoDB (claves foráneas y transacciones).
- Errores frecuentes:
  - `Access denied for user 'bodega'@'localhost'` → no se ejecutó `crear_base_mysql.sql` o la clave en `.env` no coincide.
  - `Can't connect to MySQL server` → el servicio MySQL no está iniciado o el puerto no es 3306.
  - `'cryptography' package is required` → `pip install -r requirements.txt` (MySQL 8 usa `caching_sha2_password`).
- Para una prueba rápida sin servidor puedes usar `DB_ENGINE=sqlite`.

---

## Usuarios de demostración

Contraseña de todos: **`Bodega#2026`**

| Correo | Rol | Qué puede hacer |
|---|---|---|
| admin@bodega.cl | admin | Todo, incluida la gestión de usuarios |
| carla.munoz@bodega.cl | bodeguero | Inventario, bodegas, categorías, entregas, historial, reportes |
| jose.perez@bodega.cl | trabajador | Ver catálogo, solicitar, devolver herramientas |
| nuevo@bodega.cl | trabajador | Muestra el flujo de **primer inicio de sesión** (debe cambiar la contraseña) |

`python manage.py seed --reset` borra todo y vuelve a cargar los datos de demo.

---

## Pantallas (mockup → ruta React → API)

| # | Mockup | Ruta | Roles | Endpoints |
|---|---|---|---|---|
| 01 | Login | `/login` | todos | `POST /api/auth/login/` |
| 02 | Cambiar contraseña | `/cambiar-password` | todos | `POST /api/auth/cambiar-password/` |
| 03 | Home | `/` | todos | `GET /api/dashboard/` |
| 04 | Catálogo y stock | `/catalogo-stock` | admin, bodeguero | `GET /api/items/` |
| 05 | Registrar / editar ítem | `/items/nuevo`, `/items/:id` | admin, bodeguero | `POST/PATCH /api/items/` |
| 06 | Historial de préstamos | `/historial` | admin, bodeguero | `GET /api/solicitudes/?estado=despachada,devuelta` |
| 07 | Mi perfil | `/perfil` | todos | `PATCH /api/auth/me/` |
| 08 | Bodegas | `/bodegas` | admin, bodeguero | `/api/bodegas/` · `/api/bodegas/responsables/` |
| 09 | Categorías | `/categorias` | admin, bodeguero | `/api/categorias/` |
| 10 | Catálogo (trabajador) | `/catalogo` | trabajador | `GET /api/items/` |
| 11 | Solicitar | `/solicitar/:itemId` | trabajador | `POST /api/solicitudes/` |
| 12 | Solicitudes pendientes | `/solicitudes` | admin, bodeguero | `POST /api/solicitudes/:id/entregar/` · `/rechazar/` |
| 13 | Comentar devolución | `/devolver/:id` | trabajador | `POST /api/solicitudes/:id/devolver/` |
| 14 | Crear usuario | `/usuarios/nuevo` | admin | `POST /api/usuarios/` |
| + | Usuarios | `/usuarios` | admin | `/api/usuarios/` (rol, restablecer clave, activar) |
| + | Mis préstamos | `/mis-prestamos` | trabajador | `GET /api/solicitudes/?mias=1` · `/cancelar/` |
| + | Reportes | `/reportes/inventario`, `/reportes/movimientos`, `/reportes/prestamos` | admin, bodeguero | `GET /api/reportes/{inventario,movimientos,prestamos,opciones}/` |

Todas las rutas de la API (salvo login y refresh) requieren el encabezado `Authorization: Bearer <token>`.
Los permisos se validan en el backend; el menú de React solo oculta lo que cada rol no puede usar.

## Menú y diseño responsivo

- El menú lateral se agrupa en secciones genéricas según el rol: **Inicio**, **Inventario** (catálogo, bodegas,
  categorías), **Préstamos** (solicitudes, historial), **Reportes** y **Administración** (solo admin).
- Escritorio: menú fijo; con el botón inferior se contrae a solo íconos (se recuerda la preferencia).
- Tablet y móvil (< 992 px): barra superior con botón ☰ que abre el menú deslizable.
- En móvil (< 768 px) cada fila de las tablas se muestra como tarjeta; ninguna página tiene desplazamiento horizontal.

## Reportes

Cada reporte tiene una barra de filtros. Los filtros se guardan en la URL (se pueden recargar o compartir) y se envían
al backend, que recalcula **a la vez** los indicadores, los gráficos, la tabla y la exportación a CSV.

| Reporte | Filtros | Muestra |
|---|---|---|
| Inventario | bodega, categoría, tipo, estado de stock, búsqueda | ítems, unidades, críticos, stock bajo, ocupación; unidades por categoría; ocupación por bodega |
| Movimientos | período (7/30/90 días, mes, rango), bodega, tipo, categoría, ítem, usuario, búsqueda | entradas, salidas, devoluciones, ajustes; unidades por día; ítems más entregados |
| Préstamos | período, estado, trabajador, tipo, categoría, bodega, solo sobre stock, búsqueda | pendientes, en préstamo, vencidos, devueltos (% a tiempo y en buen estado); por estado, trabajador e ítem |

## Modelo de datos

```
usuario ──< solicitud >── item >── categoria
                │           │
                └── bodega ─┴──< stock (item, bodega, cantidad ≥ 0)
                            └──< movimiento_stock (entrada / salida / devolución / ajuste)
```

- **item**: SKU automático según tipo (`HRM-0001` herramienta, `MAT-` material, `EPP-` protección), no editable.
  Estado calculado con el stock total: *Sin stock* (0), *Crítico* (≤ stock crítico), *Stock bajo* (< stock mínimo), *Disponible*.
- **solicitud**: `pendiente → despachada → devuelta` (o `rechazada` / `cancelada`).
  Las **herramientas** son préstamos con fecha límite (por defecto 3 días, `PRESTAMO_DIAS_DEFAULT`) y se devuelven con comentario.
  Materiales y EPP se consumen: quedan *despachados*.
- **bodega**: nombre, ubicación, capacidad (unidades), responsable (bodeguero/admin) y descripción.
  El espacio disponible es `capacidad − unidades guardadas`. Una entrada o ajuste que no cabe se rechaza; la capacidad
  no puede quedar por debajo de lo ya guardado. Las devoluciones siempre se aceptan.
- **Solicitudes sobre stock**: un trabajador puede pedir más de lo disponible (incluso un ítem sin stock), pero el
  **motivo es obligatorio** (mínimo 15 caracteres). Queda marcada `excede_stock` con el stock que había al pedir; el
  bodeguero la ve destacada y la entrega cuando repone, o la rechaza.
- Cada cambio de stock se hace con bloqueo de fila (`select_for_update`) y queda registrado en `movimiento_stock`.
  MySQL impide stock negativo con un `CHECK` (`stock_no_negativo`).

## Reglas implementadas

- Contraseña: mínimo 9 caracteres, una mayúscula, un número y un carácter especial (validado en React y en Django).
- Usuarios nuevos reciben una contraseña temporal y deben cambiarla en su primer inicio de sesión.
- "Acuérdate de mí": la sesión persiste al cerrar el navegador (`localStorage`); si no, dura lo que la pestaña.
- Mi perfil exige la contraseña actual para guardar.
- Se puede solicitar más de lo disponible solo con motivo; no se puede entregar desde una bodega sin stock suficiente.
- Comentario de devolución: 30 a 2500 caracteres.
- No se eliminan categorías con productos ni bodegas con stock. Ítems y usuarios se **desactivan** (se conserva el historial);
  un usuario con herramientas prestadas no se puede desactivar.
- Vista de usuarios: resumen por rol, filtros por rol y estado, préstamos activos, último acceso y edición de todos sus datos.
- Historial: fila roja si el préstamo está vencido, amarilla si vence en menos de 24 h.

## Tests

```bash
cd backend
python manage.py test
```

Django crea y borra una base temporal `test_bodega`; el usuario `bodega` necesita permiso sobre ella
(ya incluido en `crear_base_mysql.sql`).

Cubren login, primer inicio, capacidad de bodegas, solicitudes sobre stock, filtros de los tres reportes, edición de usuarios, permisos por rol, perfil, SKU y estados de stock, protección de categorías y el flujo
completo solicitud → entrega → devolución.

## Producción (resumen)

- `DJANGO_DEBUG=False`, una `DJANGO_SECRET_KEY` propia y `DJANGO_ALLOWED_HOSTS` con tu dominio.
- `npm run build` genera `frontend/dist/` para servirlo con Nginx (o similar), redirigiendo `/api` a Django con gunicorn:
  `gunicorn config.wsgi:application`.
