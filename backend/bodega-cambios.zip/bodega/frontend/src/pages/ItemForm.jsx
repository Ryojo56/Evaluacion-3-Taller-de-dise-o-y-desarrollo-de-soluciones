// 05 · Registrar o editar ítem
import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import { Alerta, Cargando, Modal } from '../components/ui'

const PREFIJO = { herramienta: 'HRM', material: 'MAT', epp: 'EPP' }

export default function ItemForm() {
  const { id } = useParams()
  const editando = Boolean(id)
  const navigate = useNavigate()
  const [cats, setCats] = useState([])
  const [bodegas, setBodegas] = useState([])
  const [f, setF] = useState({
    nombre: '', tipo: 'herramienta', categoria: '', descripcion: '', stock_minimo: 5, stock_critico: 2, sku: '', activo: true,
  })
  const [stocks, setStocks] = useState({}) // { bodegaId: cantidad }
  const [originales, setOriginales] = useState({}) // stock del ítem antes de editar (ya ocupa espacio)
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState(null)
  const [errCampos, setErrCampos] = useState({})
  const [enviado, setEnviado] = useState(false)
  const [confirmarBaja, setConfirmarBaja] = useState(false)

  useEffect(() => {
    Promise.all([api.get('/categorias/'), api.get('/bodegas/'), editando ? api.get(`/items/${id}/`) : null])
      .then(([c, b, item]) => {
        setCats(c)
        setBodegas(b)
        const inicial = Object.fromEntries(b.map((x) => [x.id, 0]))
        if (item) {
          setF({ ...item })
          item.stock_por_bodega.forEach((s) => { inicial[s.bodega] = s.cantidad })
        }
        setStocks(inicial)
        setOriginales({ ...inicial })
      })
      .catch((e) => setError(e.message))
      .finally(() => setCargando(false))
  }, [id]) // eslint-disable-line react-hooks/exhaustive-deps

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const num = (v) => (v === '' ? NaN : Number(v))

  // Validación en el cliente (el backend vuelve a validar)
  const errores = {}
  if (!f.nombre.trim()) errores.nombre = 'El nombre es obligatorio.'
  if (!f.categoria) errores.categoria = 'Selecciona una categoría.'
  Object.entries(stocks).forEach(([b, v]) => {
    if (Number.isNaN(num(v)) || !Number.isInteger(num(v))) errores[`stock_${b}`] = 'Ingresa un número entero.'
    else if (num(v) < 0) errores[`stock_${b}`] = 'El stock no puede ser negativo.'
    else {
      const bod = bodegas.find((x) => String(x.id) === String(b))
      const maximo = bod ? bod.espacio_disponible + (originales[b] || 0) : Infinity
      if (num(v) > maximo) errores[`stock_${b}`] = `No cabe: en ${bod.nombre} caben como máximo ${Math.max(maximo, 0)} unidades de este ítem.`
    }
  })
  if (num(f.stock_minimo) < 0 || Number.isNaN(num(f.stock_minimo))) errores.stock_minimo = 'Debe ser 0 o más.'
  if (num(f.stock_critico) < 0 || Number.isNaN(num(f.stock_critico))) errores.stock_critico = 'Debe ser 0 o más.'
  else if (num(f.stock_critico) > num(f.stock_minimo)) errores.stock_critico = 'No puede superar al stock mínimo.'
  const todos = { ...errores, ...errCampos }
  // Los errores de stock se muestran de inmediato (como en el mockup); el resto, al intentar guardar
  const err = (k) => (enviado || k.startsWith('stock_') ? todos[k] : errCampos[k])

  async function onSubmit(e) {
    e.preventDefault()
    setEnviado(true)
    setErrCampos({})
    setError(null)
    if (Object.keys(errores).length) return
    const body = {
      nombre: f.nombre.trim(), tipo: f.tipo, categoria: f.categoria, descripcion: f.descripcion,
      stock_minimo: num(f.stock_minimo), stock_critico: num(f.stock_critico),
      stocks: Object.entries(stocks).map(([bodega, cantidad]) => ({ bodega: Number(bodega), cantidad: num(cantidad) })),
    }
    try {
      const item = editando ? await api.patch(`/items/${id}/`, body) : await api.post('/items/', body)
      navigate('/catalogo-stock', { state: { flash: `Ítem ${item.sku} guardado correctamente.` } })
    } catch (ex) {
      setError(ex.message)
      if (ex.data && typeof ex.data === 'object') {
        setErrCampos(Object.fromEntries(Object.keys(ex.data).map((k) => [k, ex.campo(k)])))
      }
    }
  }

  async function cambiarActivo() {
    try {
      if (f.activo) await api.del(`/items/${id}/`)
      else await api.patch(`/items/${id}/`, { activo: true })
      navigate('/catalogo-stock', { state: { flash: f.activo ? 'Ítem dado de baja del catálogo.' : 'Ítem reactivado.' } })
    } catch (ex) {
      setError(ex.message)
    }
  }

  if (cargando) return <Cargando />
  const inv = (k) => (err(k) ? 'is-invalid' : '')

  return (
    <div className="card p-4 p-md-5" style={{ maxWidth: 640 }}>
      <h1 className="h4 fw-bold mb-4">Panel: {editando ? 'editar' : 'registrar'} ítem</h1>
      <Alerta onClose={() => setError(null)}>{error}</Alerta>
      <form noValidate onSubmit={onSubmit}>
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label text-secondary">Nombre</label>
          <input type="text" id="nombre" className={`form-control ${inv('nombre')}`} placeholder="Ej. Taladro percutor 1/2"
            value={f.nombre} onChange={set('nombre')} />
          <div className="invalid-feedback">{err('nombre')}</div>
        </div>
        <div className="row g-3 mb-3">
          <div className="col-md-6">
            <label htmlFor="tipo" className="form-label text-secondary">Tipo</label>
            <select id="tipo" className={`form-select ${inv('tipo')}`} value={f.tipo} onChange={set('tipo')} disabled={editando}>
              <option value="herramienta">Herramienta (se presta y se devuelve)</option>
              <option value="material">Material (consumible)</option>
              <option value="epp">Equipo de protección</option>
            </select>
            <div className="invalid-feedback">{err('tipo')}</div>
          </div>
          <div className="col-md-6">
            <label htmlFor="categoria" className="form-label text-secondary">Categoría</label>
            <select id="categoria" className={`form-select ${inv('categoria')}`} value={f.categoria} onChange={set('categoria')}>
              <option value="">Selecciona…</option>
              {cats.map((c) => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select>
            <div className="invalid-feedback">{err('categoria')}</div>
          </div>
        </div>
        <div className="mb-3">
          <label htmlFor="sku" className="form-label text-secondary">SKU (no editable)</label>
          <input type="text" id="sku" className="form-control sku bg-light" readOnly
            value={editando ? f.sku : `${PREFIJO[f.tipo]}-#### (se asigna al guardar)`} />
        </div>

        <fieldset className="mb-3">
          <legend className="form-label text-secondary fs-6">{editando ? 'Stock por bodega' : 'Stock inicial'}</legend>
          {bodegas.length === 0 && <div className="small text-secondary">Primero crea una bodega.</div>}
          <div className="row g-2">
            {bodegas.map((b) => (
              <div className="col-sm-6" key={b.id}>
                <div className="input-group has-validation">
                  <span className="input-group-text small">{b.nombre}</span>
                  <input type="number" min="0" step="1" aria-label={`Stock en ${b.nombre}`} aria-describedby={`err${b.id}`}
                    className={`form-control ${inv(`stock_${b.id}`)}`}
                    value={stocks[b.id]} onChange={(e) => setStocks({ ...stocks, [b.id]: e.target.value })} />
                  <div id={`err${b.id}`} className="invalid-feedback">{err(`stock_${b.id}`)}</div>
                </div>
                {!err(`stock_${b.id}`) && (
                  <div className="form-text">
                    Libre: {Math.max(0, b.espacio_disponible + (originales[b.id] || 0) - (num(stocks[b.id]) || 0))} de {b.capacidad}
                  </div>
                )}
              </div>
            ))}
          </div>
        </fieldset>

        <div className="row g-3 mb-3">
          <div className="col-6">
            <label htmlFor="min" className="form-label text-secondary small">Stock mínimo (alerta "Stock bajo")</label>
            <input type="number" min="0" id="min" className={`form-control ${inv('stock_minimo')}`}
              value={f.stock_minimo} onChange={set('stock_minimo')} />
            <div className="invalid-feedback">{err('stock_minimo')}</div>
          </div>
          <div className="col-6">
            <label htmlFor="crit" className="form-label text-secondary small">Stock crítico</label>
            <input type="number" min="0" id="crit" className={`form-control ${inv('stock_critico')}`}
              value={f.stock_critico} onChange={set('stock_critico')} />
            <div className="invalid-feedback">{err('stock_critico')}</div>
          </div>
        </div>
        <div className="mb-4">
          <label htmlFor="desc" className="form-label text-secondary small">Descripción (opcional)</label>
          <textarea id="desc" rows="2" className="form-control" value={f.descripcion} onChange={set('descripcion')} />
        </div>
        <div className="d-flex gap-2">
          <button type="submit" className="btn btn-accent flex-fill py-2">Guardar cambios</button>
          <button type="button" className="btn btn-outline-secondary flex-fill py-2" onClick={() => navigate('/catalogo-stock')}>
            Cancelar
          </button>
        </div>
        {editando && (
          <div className="text-center mt-3">
            <button type="button" className={`btn btn-link btn-sm ${f.activo ? 'link-danger' : ''}`} onClick={() => setConfirmarBaja(true)}>
              {f.activo ? 'Dar de baja del catálogo' : 'Reactivar ítem'}
            </button>
          </div>
        )}
      </form>

      <Modal titulo={f.activo ? 'Dar de baja ítem' : 'Reactivar ítem'} abierto={confirmarBaja} onClose={() => setConfirmarBaja(false)}
        pie={<>
          <button className="btn btn-outline-secondary" onClick={() => setConfirmarBaja(false)}>Cancelar</button>
          <button className={`btn ${f.activo ? 'btn-danger' : 'btn-accent'}`} onClick={cambiarActivo}>Confirmar</button>
        </>}>
        {f.activo
          ? <p className="mb-0">El ítem <strong>{f.nombre}</strong> dejará de aparecer en el catálogo de los trabajadores. Su historial se conserva.</p>
          : <p className="mb-0">El ítem <strong>{f.nombre}</strong> volverá a estar disponible para solicitudes.</p>}
      </Modal>
    </div>
  )
}
