// 03 · Home
import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import { badge } from '../utils'
import { Flash, useCarga } from '../components/ui'
import { useAuth } from '../context/AuthContext'

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

export default function Home() {
  const { user, esGestor } = useAuth()
  const navigate = useNavigate()
  const { data } = useCarga(() => api.get('/dashboard/'))
  const [q, setQ] = useState('')
  const [escuchando, setEscuchando] = useState(false)
  const [verNotif, setVerNotif] = useState(false)
  const notifRef = useRef(null)

  // Cierra el menú de notificaciones al hacer clic fuera
  useEffect(() => {
    const cerrar = (e) => notifRef.current && !notifRef.current.contains(e.target) && setVerNotif(false)
    document.addEventListener('mousedown', cerrar)
    return () => document.removeEventListener('mousedown', cerrar)
  }, [])

  const rutaCatalogo = esGestor ? '/catalogo-stock' : '/catalogo'
  function buscar(texto) {
    navigate(`${rutaCatalogo}?q=${encodeURIComponent(texto.trim())}`)
  }

  // Búsqueda por voz (Web Speech API, disponible en Chrome/Edge)
  function buscarPorVoz() {
    if (!SpeechRecognition) return alert('Tu navegador no soporta búsqueda por voz.')
    const rec = new SpeechRecognition()
    rec.lang = 'es-CL'
    rec.onresult = (e) => {
      const texto = e.results[0][0].transcript
      setQ(texto)
      buscar(texto)
    }
    rec.onend = () => setEscuchando(false)
    setEscuchando(true)
    rec.start()
  }

  const notifs = data?.notificaciones || []
  const accesos = esGestor
    ? [['/reportes/inventario', 'Inventario'], ['/reportes/movimientos', 'Movimientos'], ['/reportes/prestamos', 'Préstamos']]
    : [['/catalogo', 'Ver catálogo'], ['/mis-prestamos', 'Mis préstamos'], ['/perfil', 'Mi perfil']]

  return (
    <>
      <header className="home-header d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <h1 className="h3 fw-bold mb-0">Hola, {user.nombre_completo}</h1>
        <div className="home-tools d-flex align-items-center gap-2 gap-md-3">
          <div className="position-relative" ref={notifRef}>
            <button className="btn btn-light position-relative" aria-label="Notificaciones" onClick={() => setVerNotif(!verNotif)}>
              🔔
              {notifs.length > 0 && (
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  {notifs.length}
                </span>
              )}
            </button>
            {verNotif && (
              <div className="card notif-menu p-2">
                <div className="small fw-semibold px-2 py-1">Notificaciones</div>
                {notifs.length === 0 && <div className="small text-secondary px-2 py-2">No tienes notificaciones.</div>}
                {notifs.map((n, i) => (
                  <Link key={i} to={n.link} className="d-block small text-reset text-decoration-none rounded-2 px-2 py-2 bg-light-subtle border-bottom">
                    <span className={`${badge(n.tipo === 'pendiente' ? 'primary' : n.tipo === 'vencido' ? 'danger' : 'warning')} me-2`}>
                      {n.tipo === 'pendiente' ? 'Solicitud' : n.tipo === 'vencido' ? 'Vencido' : 'Por vencer'}
                    </span>
                    {n.texto}
                  </Link>
                ))}
              </div>
            )}
          </div>
          <form className="input-group" onSubmit={(e) => { e.preventDefault(); buscar(q) }}>
            <input type="search" className="form-control" placeholder="Buscar herramienta"
              value={q} onChange={(e) => setQ(e.target.value)} />
            <button type="button" className={`btn ${escuchando ? 'btn-danger' : 'btn-outline-secondary'}`}
              aria-label="Buscar por voz" onClick={buscarPorVoz}>🎤</button>
          </form>
        </div>
      </header>

      <Flash />
      <h2 className="h5 text-secondary mb-3">Resumen general del sistema.</h2>
      <div className="row g-3 mb-4">
        {(data?.tarjetas || [{}, {}, {}]).map((t, i) => (
          <div className="col-12 col-md-4" key={i}>
            <Link to={t.link || '#'} className="card stat text-center p-4 h-100">
              <div className="text-secondary">{t.titulo || '…'}</div>
              <div className="display-5 fw-bold">
                {t.tono ? <span className={badge(t.tono)}>{t.valor}</span> : t.valor ?? '–'}
              </div>
            </Link>
          </div>
        ))}
      </div>

      <h2 className="h5 text-secondary mb-3">{esGestor ? 'Accesos rápidos a reportes' : 'Accesos rápidos'}</h2>
      <div className="card bg-dark p-3">
        <div className="row g-3">
          {accesos.map(([to, label]) => (
            <div className="col-12 col-md-4" key={to}>
              <Link to={to} className="btn btn-light w-100 py-3">{label}</Link>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}
