// 08 · Bodegas: ubicación, capacidad, espacio disponible y responsable
import { useState } from 'react'
import { api } from '../api/client'
import Icon from '../components/Icon'
import { Alerta, Cargando, Modal, PageHeader, SectionTabs, useCarga } from '../components/ui'
import { TABS_BODEGAS } from '../components/CrudSimple'

const VACIA = { nombre: '', ubicacion: '', capacidad: '', responsable: '', descripcion: '' }
const nf = new Intl.NumberFormat('es-CL')

export function BarraOcupacion({ pct }) {
  const nivel = pct >= 90 ? 'alta' : pct >= 70 ? 'media' : ''
  return (
    <div className={`ocupacion ${nivel}`} role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin="0" aria-valuemax="100"
      aria-label={`Ocupación ${Math.round(pct)}%`}>
      <span style={{ width: `${Math.min(100, pct)}%` }} />
    </div>
  )
}

export default function Bodegas() {
  const { data, cargando, recargar } = useCarga(() => Promise.all([api.get('/bodegas/'), api.get('/bodegas/responsables/')]))
  const [bodegas, responsables] = data || [[], []]
  const [editando, setEditando] = useState(null)
  const [borrando, setBorrando] = useState(null)
  const [f, setF] = useState(VACIA)
  const [errores, setErrores] = useState({})
  const [error, setError] = useState(null)
  const [msg, setMsg] = useState(null)
  const [enviando, setEnviando] = useState(false)

  function abrir(b) {
    setError(null)
    setErrores({})
    setEditando(b)
    setF(b.id ? {
      nombre: b.nombre, ubicacion: b.ubicacion, capacidad: b.capacidad,
      responsable: b.responsable ?? '', descripcion: b.descripcion,
    } : VACIA)
  }
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  // Validación en el cliente (el backend vuelve a validar)
  function validar() {
    const e = {}
    if (!f.nombre.trim()) e.nombre = 'El nombre es obligatorio.'
    if (!f.ubicacion.trim()) e.ubicacion = 'Indica dónde está la bodega.'
    const cap = Number(f.capacidad)
    if (!Number.isInteger(cap) || cap < 1) e.capacidad = 'Ingresa un número entero mayor que 0.'
    else if (editando?.id && cap < editando.unidades_ocupadas) {
      e.capacidad = `Ya hay ${editando.unidades_ocupadas} unidades guardadas: la capacidad no puede ser menor.`
    }
    return e
  }

  async function guardar(ev) {
    ev.preventDefault()
    const e = validar()
    setErrores(e)
    setError(null)
    if (Object.keys(e).length) return
    setEnviando(true)
    const body = {
      nombre: f.nombre.trim(), ubicacion: f.ubicacion.trim(), capacidad: Number(f.capacidad),
      responsable: f.responsable ? Number(f.responsable) : null, descripcion: f.descripcion.trim(),
    }
    try {
      if (editando.id) await api.patch(`/bodegas/${editando.id}/`, body)
      else await api.post('/bodegas/', body)
      setMsg(`Bodega "${body.nombre}" guardada.`)
      setEditando(null)
      recargar()
    } catch (ex) {
      const porCampo = Object.fromEntries(Object.keys(VACIA).map((k) => [k, ex.campo(k)]).filter(([, v]) => v))
      setErrores(porCampo)
      if (!Object.keys(porCampo).length) setError(ex.message)
    } finally {
      setEnviando(false)
    }
  }

  async function eliminar() {
    setEnviando(true)
    setError(null)
    try {
      await api.del(`/bodegas/${borrando.id}/`)
      setMsg(`Bodega "${borrando.nombre}" eliminada.`)
      setBorrando(null)
      recargar()
    } catch (ex) {
      setError(ex.message)
    } finally {
      setEnviando(false)
    }
  }

  const ocupado = bodegas.reduce((t, b) => t + b.unidades_ocupadas, 0)
  const capacidad = bodegas.reduce((t, b) => t + b.capacidad, 0)
  const inv = (k) => (errores[k] ? 'is-invalid' : '')

  return (
    <>
      <SectionTabs tabs={TABS_BODEGAS} />
      <PageHeader titulo="Bodegas"
        subtitulo={bodegas.length ? `${bodegas.length} bodegas · ${nf.format(ocupado)} de ${nf.format(capacidad)} unidades ocupadas` : null}>
        <button type="button" className="btn btn-accent" onClick={() => abrir({})}>+ Nueva bodega</button>
      </PageHeader>
      <Alerta tipo="success" onClose={() => setMsg(null)}>{msg}</Alerta>

      {cargando && <Cargando />}
      {!cargando && bodegas.length === 0 && (
        <div className="card p-5 text-center text-secondary">Aún no hay bodegas. Crea la primera para empezar a registrar stock.</div>
      )}
      <div className="row g-3">
        {bodegas.map((b) => (
          <div className="col-12 col-md-6 col-xxl-4" key={b.id}>
            <div className="card h-100 p-3 p-md-4 d-flex flex-column">
              <div className="d-flex justify-content-between align-items-start gap-2">
                <div className="min-w-0">
                  <h2 className="h5 fw-bold mb-1">{b.nombre}</h2>
                  <div className="small text-secondary d-flex gap-1 align-items-start">
                    <Icon name="pin" size={15} /> <span>{b.ubicacion || 'Sin ubicación'}</span>
                  </div>
                </div>
                <div className="d-flex flex-none">
                  <button type="button" className="btn btn-icon" onClick={() => abrir(b)} aria-label={`Editar ${b.nombre}`} title="Editar">
                    <Icon name="edit" />
                  </button>
                  <button type="button" className="btn btn-icon text-danger" onClick={() => { setError(null); setBorrando(b) }}
                    aria-label={`Eliminar ${b.nombre}`} title="Eliminar">
                    <Icon name="trash" />
                  </button>
                </div>
              </div>

              <div className="mt-3">
                <div className="d-flex justify-content-between small mb-1">
                  <span className="text-secondary">Ocupación</span>
                  <span className="fw-semibold">{b.ocupacion_pct}%</span>
                </div>
                <BarraOcupacion pct={b.ocupacion_pct} />
                <div className="d-flex justify-content-between small mt-1 text-secondary">
                  <span>{nf.format(b.unidades_ocupadas)} / {nf.format(b.capacidad)} unidades</span>
                </div>
              </div>

              <div className="row g-2 mt-2 text-center">
                <div className="col-6">
                  <div className="bg-light rounded-3 py-2">
                    <div className="fw-bold fs-5">{nf.format(b.espacio_disponible)}</div>
                    <div className="small text-secondary">Espacio disponible</div>
                  </div>
                </div>
                <div className="col-6">
                  <div className="bg-light rounded-3 py-2">
                    <div className="fw-bold fs-5">{b.items_distintos}</div>
                    <div className="small text-secondary">Ítems distintos</div>
                  </div>
                </div>
              </div>

              <div className="small mt-3 d-flex gap-2 align-items-center">
                <Icon name="user" size={15} className="text-secondary" />
                <span className="text-secondary">Responsable:</span>
                <span className="fw-medium">{b.responsable_nombre || 'Sin asignar'}</span>
              </div>
              {b.descripcion && <p className="small text-secondary mt-2 mb-0">{b.descripcion}</p>}
            </div>
          </div>
        ))}
      </div>

      <Modal titulo={editando?.id ? `Editar ${editando.nombre}` : 'Nueva bodega'} abierto={!!editando} onClose={() => setEditando(null)} size="modal-lg">
        <form onSubmit={guardar} noValidate>
          <Alerta onClose={() => setError(null)}>{error}</Alerta>
          <div className="row g-3">
            <div className="col-md-6">
              <label htmlFor="b_nombre" className="form-label small text-secondary">Nombre *</label>
              <input id="b_nombre" className={`form-control ${inv('nombre')}`} autoFocus value={f.nombre} onChange={set('nombre')}
                placeholder="Ej. Bodega Central" />
              <div className="invalid-feedback">{errores.nombre}</div>
            </div>
            <div className="col-md-6">
              <label htmlFor="b_resp" className="form-label small text-secondary">Responsable</label>
              <select id="b_resp" className={`form-select ${inv('responsable')}`} value={f.responsable} onChange={set('responsable')}>
                <option value="">Sin asignar</option>
                {responsables.map((r) => <option key={r.id} value={r.id}>{r.nombre} ({r.rol})</option>)}
              </select>
              <div className="invalid-feedback">{errores.responsable}</div>
            </div>
            <div className="col-12">
              <label htmlFor="b_ubic" className="form-label small text-secondary">Ubicación *</label>
              <input id="b_ubic" className={`form-control ${inv('ubicacion')}`} value={f.ubicacion} onChange={set('ubicacion')}
                placeholder="Dirección o sector, ej. Galpón principal, Av. Industrial 1450" />
              <div className="invalid-feedback">{errores.ubicacion}</div>
            </div>
            <div className="col-md-6">
              <label htmlFor="b_cap" className="form-label small text-secondary">Capacidad total (unidades) *</label>
              <input id="b_cap" type="number" min={editando?.unidades_ocupadas || 1} step="1" className={`form-control ${inv('capacidad')}`}
                value={f.capacidad} onChange={set('capacidad')} placeholder="Ej. 1000" />
              <div className="invalid-feedback">{errores.capacidad}</div>
            </div>
            <div className="col-md-6">
              <span className="form-label small text-secondary d-block">Espacio disponible</span>
              {(() => {
                const usado = editando?.unidades_ocupadas || 0
                const cap = Number(f.capacidad) || 0
                const libre = cap - usado
                return (
                  <div className="bg-light rounded-3 px-3 py-2">
                    <div className={`fw-bold ${libre < 0 ? 'text-danger' : ''}`}>{cap ? nf.format(libre) : '—'} unidades libres</div>
                    <div className="small text-secondary">{nf.format(usado)} unidades ya guardadas</div>
                  </div>
                )
              })()}
            </div>
            <div className="col-12">
              <label htmlFor="b_desc" className="form-label small text-secondary">Descripción (opcional)</label>
              <textarea id="b_desc" rows="2" className="form-control" value={f.descripcion} onChange={set('descripcion')}
                placeholder="Qué se guarda aquí, horarios, acceso…" />
            </div>
          </div>
          <div className="d-flex gap-2 mt-4">
            <button type="submit" className="btn btn-accent flex-fill" disabled={enviando}>{enviando ? 'Guardando…' : 'Guardar'}</button>
            <button type="button" className="btn btn-outline-secondary flex-fill" onClick={() => setEditando(null)}>Cancelar</button>
          </div>
        </form>
      </Modal>

      <Modal titulo="Eliminar bodega" abierto={!!borrando} onClose={() => setBorrando(null)}
        pie={<>
          <button className="btn btn-outline-secondary" onClick={() => setBorrando(null)}>Cancelar</button>
          <button className="btn btn-danger" onClick={eliminar} disabled={enviando}>Eliminar</button>
        </>}>
        <Alerta>{error}</Alerta>
        <p className="mb-0">¿Seguro que quieres eliminar <strong>{borrando?.nombre}</strong>? Solo se puede eliminar una bodega sin stock.</p>
      </Modal>
    </>
  )
}
