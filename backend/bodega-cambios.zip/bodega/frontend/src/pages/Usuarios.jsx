// Gestión de usuarios (administrador)
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import DataTable from '../components/DataTable'
import Icon from '../components/Icon'
import { Alerta, Flash, Modal, PageHeader, useCarga } from '../components/ui'
import { useAuth } from '../context/AuthContext'
import { badge, fechaHora } from '../utils'
import { ROLES } from './CrearUsuario'

const ROL_TONO = { admin: 'primary', bodeguero: 'info', trabajador: 'secondary' }
const ROL_TEXTO = Object.fromEntries(ROLES)

function haceCuanto(iso) {
  if (!iso) return 'Nunca'
  const min = Math.round((Date.now() - new Date(iso)) / 60000)
  if (min < 1) return 'Recién'
  if (min < 60) return `Hace ${min} min`
  if (min < 60 * 24) return `Hace ${Math.round(min / 60)} h`
  if (min < 60 * 24 * 30) return `Hace ${Math.round(min / 1440)} días`
  return fechaHora(iso).slice(0, 10)
}

const estadoDe = (u) => (!u.is_active ? 'inactivo' : u.debe_cambiar_password ? 'temporal' : 'activo')
const ESTADOS = {
  activo: ['success', 'Activo'],
  temporal: ['warning', 'Clave temporal'],
  inactivo: ['secondary', 'Inactivo'],
}

/** Menú "⋯" con acciones secundarias */
function MenuAcciones({ children }) {
  // Posición fija calculada desde el botón: así el menú no queda recortado por el scroll de la tabla.
  // Al desplazar la página el menú sigue al botón (no se cierra: en móvil el scroll es involuntario).
  const [abierto, setAbierto] = useState(false)
  const [pos, setPos] = useState({})
  const ref = useRef(null)
  const btn = useRef(null)
  useEffect(() => {
    if (!abierto) return
    const ubicar = () => {
      const r = btn.current.getBoundingClientRect()
      const arriba = window.innerHeight - r.bottom < 140
      setPos({ right: window.innerWidth - r.right, ...(arriba ? { bottom: window.innerHeight - r.top + 4 } : { top: r.bottom + 4 }) })
    }
    ubicar()
    const cerrar = (e) => { if (!ref.current?.contains(e.target)) setAbierto(false) }
    document.addEventListener('mousedown', cerrar)
    window.addEventListener('scroll', ubicar, true)
    window.addEventListener('resize', ubicar)
    return () => {
      document.removeEventListener('mousedown', cerrar)
      window.removeEventListener('scroll', ubicar, true)
      window.removeEventListener('resize', ubicar)
    }
  }, [abierto])
  return (
    <div className="d-inline-block" ref={ref}>
      <button ref={btn} type="button" className="btn btn-icon" aria-label="Más acciones" aria-haspopup="menu" aria-expanded={abierto}
        onClick={() => setAbierto(!abierto)}>
        <Icon name="dots" size={20} />
      </button>
      {abierto && (
        <div className="card p-1 shadow text-start" style={{ position: 'fixed', zIndex: 1030, minWidth: 220, ...pos }} role="menu"
          onClick={() => setAbierto(false)}>
          {children}
        </div>
      )}
    </div>
  )
}

export default function Usuarios() {
  const { user: yo } = useAuth()
  const { data, cargando, recargar } = useCarga(() => api.get('/usuarios/'))
  const usuarios = data || []
  const [buscar, setBuscar] = useState('')
  const [rol, setRol] = useState('')
  const [estado, setEstado] = useState('')
  const [editando, setEditando] = useState(null)
  const [f, setF] = useState({})
  const [errores, setErrores] = useState({})
  const [confirmar, setConfirmar] = useState(null) // { u, accion }
  const [clave, setClave] = useState(null)
  const [msg, setMsg] = useState(null)
  const [error, setError] = useState(null)
  const [enviando, setEnviando] = useState(false)

  const conteo = useMemo(() => {
    const c = { total: usuarios.length, activos: 0, temporal: 0, admin: 0, bodeguero: 0, trabajador: 0 }
    usuarios.forEach((u) => {
      if (u.is_active) c.activos++
      if (estadoDe(u) === 'temporal') c.temporal++
      c[u.rol]++
    })
    return c
  }, [usuarios])

  const filas = usuarios.filter((u) => (!rol || u.rol === rol) && (!estado || estadoDe(u) === estado))

  function abrirEdicion(u) {
    setErrores({})
    setError(null)
    setF({ nombre: u.nombre, apellido: u.apellido, email: u.email, telefono: u.telefono, rol: u.rol })
    setEditando(u)
  }

  async function guardar(e) {
    e.preventDefault()
    setEnviando(true)
    setErrores({})
    try {
      await api.patch(`/usuarios/${editando.id}/`, f)
      setMsg(`Datos de ${f.nombre} ${f.apellido} actualizados.`)
      setEditando(null)
      recargar()
    } catch (ex) {
      const porCampo = Object.fromEntries(Object.keys(f).map((k) => [k, ex.campo(k)]).filter(([, v]) => v))
      setErrores(porCampo)
      if (!Object.keys(porCampo).length) setError(ex.message)
    } finally {
      setEnviando(false)
    }
  }

  async function ejecutar() {
    const { u, accion } = confirmar
    setEnviando(true)
    setError(null)
    try {
      if (accion === 'reset') {
        const r = await api.post(`/usuarios/${u.id}/reset-password/`)
        setClave({ u, pwd: r.password_temporal })
      } else if (accion === 'desactivar') {
        await api.del(`/usuarios/${u.id}/`)
        setMsg(`${u.nombre_completo} fue desactivado. Ya no puede iniciar sesión.`)
      } else {
        await api.patch(`/usuarios/${u.id}/`, { is_active: true })
        setMsg(`${u.nombre_completo} fue reactivado.`)
      }
      setConfirmar(null)
      recargar()
    } catch (ex) {
      setError(ex.message)
    } finally {
      setEnviando(false)
    }
  }

  const columnas = [
    {
      key: 'nombre_completo', label: 'Usuario', primary: true,
      value: (u) => `${u.nombre_completo} ${u.email}`, sortValue: (u) => u.nombre_completo,
      render: (u) => (
        <div className="d-flex align-items-center gap-2 text-start">
          <span className={`avatar flex-none avatar-rol-${u.rol}`}>{u.iniciales}</span>
          <div className="lh-sm" style={{ minWidth: 0 }}>
            <div className="fw-semibold text-truncate">{u.nombre_completo}{u.id === yo.id && <span className="text-secondary fw-normal small"> (tú)</span>}</div>
            <div className="small text-secondary text-truncate">{u.email}</div>
          </div>
        </div>
      ),
    },
    { key: 'telefono', label: 'Teléfono', className: 'small text-nowrap', value: (u) => u.telefono || '—' },
    {
      key: 'rol', label: 'Rol', value: (u) => ROL_TEXTO[u.rol],
      render: (u) => <span className={badge(ROL_TONO[u.rol])}>{ROL_TEXTO[u.rol]}</span>,
    },
    {
      key: 'estado', label: 'Estado', value: (u) => ESTADOS[estadoDe(u)][1],
      render: (u) => { const [t, l] = ESTADOS[estadoDe(u)]; return <span className={badge(t)}>{l}</span> },
    },
    {
      key: 'prestamos_activos', label: 'Préstamos', value: (u) => u.prestamos_activos,
      render: (u) => (u.rol === 'trabajador'
        ? <span className={u.prestamos_activos ? 'fw-semibold' : 'text-secondary'} title={`${u.prestamos_activos} activos de ${u.solicitudes_total} solicitudes`}>
          {u.prestamos_activos} activo{u.prestamos_activos === 1 ? '' : 's'}<span className="d-block text-secondary small fw-normal">{u.solicitudes_total} solicitudes</span>
        </span>
        : <span className="text-secondary">—</span>),
    },
    {
      key: 'last_login', label: 'Último acceso', className: 'small text-secondary', value: (u) => haceCuanto(u.last_login),
      sortValue: (u) => u.last_login || '',
    },
    {
      key: 'acciones', label: 'Acciones', sortable: false, thClassName: 'text-end', className: 'text-end text-nowrap',
      render: (u) => (
        <>
          <button type="button" className="btn btn-icon" onClick={() => abrirEdicion(u)} aria-label={`Editar a ${u.nombre_completo}`} title="Editar">
            <Icon name="edit" />
          </button>
          {u.id !== yo.id && (
            <MenuAcciones>
              <button type="button" className="dropdown-item rounded-2 py-2" role="menuitem" onClick={() => setConfirmar({ u, accion: 'reset' })}>
                <Icon name="key" size={15} /> Restablecer contraseña
              </button>
              {u.is_active
                ? <button type="button" className="dropdown-item rounded-2 py-2 text-danger" role="menuitem" onClick={() => setConfirmar({ u, accion: 'desactivar' })}>
                  <Icon name="close" size={15} /> Desactivar cuenta
                </button>
                : <button type="button" className="dropdown-item rounded-2 py-2" role="menuitem" onClick={() => setConfirmar({ u, accion: 'activar' })}>
                  <Icon name="plus" size={15} /> Reactivar cuenta
                </button>}
            </MenuAcciones>
          )}
        </>
      ),
    },
  ]

  const textosConfirmar = {
    reset: ['Restablecer contraseña', 'Se generará una contraseña temporal nueva y deberá cambiarla al iniciar sesión.', 'Restablecer', 'btn-accent'],
    desactivar: ['Desactivar cuenta', 'No podrá iniciar sesión. Su historial de préstamos se conserva.', 'Desactivar', 'btn-danger'],
    activar: ['Reactivar cuenta', 'Podrá volver a iniciar sesión con su contraseña actual.', 'Reactivar', 'btn-accent'],
  }
  const tc = confirmar && textosConfirmar[confirmar.accion]
  const inv = (k) => (errores[k] ? 'is-invalid' : '')
  const kpis = [
    ['Usuarios', conteo.total, `${conteo.activos} activos`],
    ['Administradores', conteo.admin],
    ['Bodegueros', conteo.bodeguero],
    ['Trabajadores', conteo.trabajador],
    ['Con clave temporal', conteo.temporal, 'Aún no inician sesión'],
  ]

  return (
    <>
      <PageHeader titulo="Usuarios" subtitulo="Cuentas con acceso al sistema, sus roles y su actividad">
        <Link to="/usuarios/nuevo" className="btn btn-accent">+ Crear usuario</Link>
      </PageHeader>
      <Flash />
      <Alerta tipo="success" onClose={() => setMsg(null)}>{msg}</Alerta>

      <div className="row g-2 g-md-3 mb-3">
        {kpis.map(([l, v, sub]) => (
          <div className="col-6 col-md-4 col-xl" key={l}>
            <div className="card kpi h-100">
              <div className="kpi-label">{l}</div>
              <div className="kpi-value">{v}</div>
              {sub && <div className="kpi-sub">{sub}</div>}
            </div>
          </div>
        ))}
      </div>

      <div className="card filtros mb-3">
        <div className="row g-2 align-items-end">
          <div className="col-12 col-lg-4">
            <label className="form-label" htmlFor="u_buscar">Buscar</label>
            <input id="u_buscar" type="search" className="form-control" placeholder="Nombre, correo o teléfono…"
              value={buscar} onChange={(e) => setBuscar(e.target.value)} />
          </div>
          <div className="col-12 col-md-8 col-lg-5">
            <span className="form-label d-block">Rol</span>
            <div className="d-flex flex-wrap gap-1 filtro-rol" role="group" aria-label="Filtrar por rol">
              {[['', 'Todos'], ...ROLES].map(([v, l]) => (
                <button key={v} type="button" className={`btn btn-sm ${rol === v ? 'btn-dark' : 'btn-light'}`}
                  aria-pressed={rol === v} onClick={() => setRol(v)}>
                  {l} <span className="opacity-75">{v ? conteo[v] : conteo.total}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="col-12 col-md-4 col-lg-3">
            <label className="form-label" htmlFor="u_estado">Estado</label>
            <select id="u_estado" className="form-select" value={estado} onChange={(e) => setEstado(e.target.value)}>
              <option value="">Todos</option>
              <option value="activo">Activos</option>
              <option value="temporal">Con clave temporal</option>
              <option value="inactivo">Inactivos</option>
            </select>
          </div>
        </div>
      </div>

      <div className="card dt-card overflow-hidden">
        <DataTable columns={columnas} rows={filas} loading={cargando} search={buscar} defaultSort={{ key: 'nombre_completo', dir: 'asc' }}
          rowClassName={(u) => (!u.is_active ? 'text-secondary opacity-75' : undefined)} />
      </div>

      <Modal titulo={`Editar a ${editando?.nombre_completo}`} abierto={!!editando} onClose={() => setEditando(null)} size="modal-lg">
        <form onSubmit={guardar} noValidate>
          <Alerta onClose={() => setError(null)}>{error}</Alerta>
          <div className="row g-3">
            <div className="col-md-6">
              <label htmlFor="e_nom" className="form-label small text-secondary">Nombre</label>
              <input id="e_nom" className={`form-control ${inv('nombre')}`} value={f.nombre || ''} onChange={(e) => setF({ ...f, nombre: e.target.value })} />
              <div className="invalid-feedback">{errores.nombre}</div>
            </div>
            <div className="col-md-6">
              <label htmlFor="e_ape" className="form-label small text-secondary">Apellido</label>
              <input id="e_ape" className="form-control" value={f.apellido || ''} onChange={(e) => setF({ ...f, apellido: e.target.value })} />
            </div>
            <div className="col-md-7">
              <label htmlFor="e_mail" className="form-label small text-secondary">Correo</label>
              <input id="e_mail" type="email" className={`form-control ${inv('email')}`} value={f.email || ''} onChange={(e) => setF({ ...f, email: e.target.value })} />
              <div className="invalid-feedback">{errores.email}</div>
            </div>
            <div className="col-md-5">
              <label htmlFor="e_tel" className="form-label small text-secondary">Teléfono</label>
              <input id="e_tel" type="tel" className="form-control" value={f.telefono || ''} onChange={(e) => setF({ ...f, telefono: e.target.value })} />
            </div>
            <div className="col-12">
              <span className="form-label small text-secondary d-block">Rol</span>
              <div className="row g-2">
                {ROLES.map(([v, l]) => (
                  <div className="col-sm-4" key={v}>
                    <input type="radio" className="btn-check" name="rol" id={`rol_${v}`} checked={f.rol === v}
                      disabled={editando?.id === yo.id && v !== 'admin'} onChange={() => setF({ ...f, rol: v })} />
                    <label className="btn btn-outline-secondary w-100" htmlFor={`rol_${v}`}>{l}</label>
                  </div>
                ))}
              </div>
              {errores.rol && <div className="small text-danger mt-1">{errores.rol}</div>}
            </div>
          </div>
          <div className="d-flex gap-2 mt-4">
            <button type="submit" className="btn btn-accent flex-fill" disabled={enviando}>Guardar cambios</button>
            <button type="button" className="btn btn-outline-secondary flex-fill" onClick={() => setEditando(null)}>Cancelar</button>
          </div>
        </form>
      </Modal>

      <Modal titulo={tc?.[0]} abierto={!!confirmar} onClose={() => setConfirmar(null)}
        pie={<>
          <button className="btn btn-outline-secondary" onClick={() => setConfirmar(null)}>Cancelar</button>
          <button className={`btn ${tc?.[3]}`} onClick={ejecutar} disabled={enviando}>{tc?.[2]}</button>
        </>}>
        <Alerta>{error}</Alerta>
        <p className="mb-0"><strong>{confirmar?.u.nombre_completo}</strong>: {tc?.[1]}</p>
      </Modal>

      <Modal titulo="Contraseña restablecida" abierto={!!clave} onClose={() => setClave(null)}
        pie={<>
          <button className="btn btn-outline-secondary" onClick={() => navigator.clipboard?.writeText(clave.pwd)}>Copiar</button>
          <button className="btn btn-accent" onClick={() => setClave(null)}>Listo</button>
        </>}>
        <p className="small">Nueva contraseña temporal para <strong>{clave?.u.nombre_completo}</strong>. Deberá cambiarla al iniciar sesión.</p>
        <pre className="bg-light rounded-3 p-3 sku mb-0">{clave?.pwd}</pre>
      </Modal>
    </>
  )
}
