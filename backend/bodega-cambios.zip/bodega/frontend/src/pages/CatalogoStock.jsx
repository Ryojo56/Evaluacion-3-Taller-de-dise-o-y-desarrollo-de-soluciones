// 04 · Catálogo y stock (bodeguero / administrador)
import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import DataTable from '../components/DataTable'
import { BadgeStock, Flash, useCarga } from '../components/ui'
import { ESTADO_STOCK, stockPorBodega } from '../utils'

export default function CatalogoStock() {
  const [params, setParams] = useSearchParams()
  const [buscar, setBuscar] = useState(params.get('q') || '')
  const [categoria, setCategoria] = useState('')
  const filtroEstado = params.get('estado') // desde la tarjeta "stock crítico" del Home

  const { data, cargando } = useCarga(() =>
    Promise.all([api.get('/items/'), api.get('/categorias/'), api.get('/bodegas/')]),
  )
  const [items, categorias, bodegas] = data || [[], [], []]

  const esCritico = (i) => i.activo && ['critico', 'sin_stock'].includes(i.estado)
  const criticos = items.filter(esCritico).length
  const filas = items
    .filter((i) => !categoria || i.categoria_nombre === categoria)
    .filter((i) => filtroEstado !== 'critico' || esCritico(i))

  const columnas = [
    { key: 'sku', label: 'SKU', className: 'sku' },
    { key: 'nombre', label: 'Nombre', className: 'fw-semibold', primary: true },
    { key: 'categoria_nombre', label: 'Categoría' },
    { key: 'stock', label: 'Stock por bodega', value: stockPorBodega, sortValue: (i) => i.stock_total },
    {
      key: 'estado', label: 'Estado',
      value: (i) => (i.activo ? ESTADO_STOCK[i.estado].texto : 'Inactivo'),
      render: (i) => (i.activo ? <BadgeStock estado={i.estado} /> : <span className="badge text-bg-light border">Inactivo</span>),
    },
    {
      key: 'acciones', label: 'Acciones', sortable: false, thClassName: 'text-end', className: 'text-end',
      render: (i) => <Link to={`/items/${i.id}`}>Editar</Link>,
    },
  ]

  return (
    <>
      <div className="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
        <div>
          <h1 className="h3 fw-bold mb-0">Catálogo y stock</h1>
          <p className="text-secondary mb-0">{items.length} ítems en {bodegas.length} bodegas</p>
        </div>
        <button type="button" className="btn p-0 border-0" onClick={() => setParams(filtroEstado ? {} : { estado: 'critico' })}
          title={filtroEstado ? 'Quitar filtro' : 'Ver solo ítems críticos'}>
          <span className="badge rounded-pill text-bg-danger-subtle text-danger-emphasis fs-6">
            ● {criticos} en stock crítico {filtroEstado && '✕'}
          </span>
        </button>
      </div>
      <Flash />
      <div className="row g-2 mb-3">
        <div className="col-12 col-md-8">
          <input type="search" className="form-control" placeholder="Buscar por nombre..." aria-label="Buscar por nombre"
            value={buscar} onChange={(e) => setBuscar(e.target.value)} />
        </div>
        <div className="col-12 col-md-4">
          <select className="form-select" aria-label="Filtrar por categoría" value={categoria} onChange={(e) => setCategoria(e.target.value)}>
            <option value="">Todas las categorías</option>
            {categorias.map((c) => <option key={c.id} value={c.nombre}>{c.nombre}</option>)}
          </select>
        </div>
      </div>
      <div className="card dt-card overflow-hidden">
        <DataTable
          columns={columnas}
          rows={filas}
          search={buscar}
          loading={cargando}
          defaultSort={{ key: 'nombre', dir: 'asc' }}
          rowClassName={(i) => (!i.activo || i.estado === 'sin_stock' ? 'text-secondary opacity-75' : undefined)}
        />
      </div>
      <div className="text-end mt-3"><Link to="/items/nuevo" className="btn btn-accent">+ Registrar ítem</Link></div>
    </>
  )
}
