// 10 · Catálogo de materiales y herramientas (trabajador)
import { useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import { BadgeStock, Cargando, useCarga } from '../components/ui'
import { stockPorBodega } from '../utils'

// Para el trabajador "crítico" se muestra como "Stock bajo" (como en el mockup)
const estadoTrabajador = (e) => (e === 'critico' ? 'bajo' : e)

export default function CatalogoTrabajador() {
  const [params] = useSearchParams()
  const [buscar, setBuscar] = useState(params.get('q') || '')
  const [categoria, setCategoria] = useState('')
  const { data, cargando } = useCarga(() => Promise.all([api.get('/items/'), api.get('/categorias/')]))
  const [items, categorias] = data || [[], []]

  const visibles = useMemo(() => {
    const t = buscar.trim().toLowerCase()
    return items
      .filter((i) => !categoria || String(i.categoria) === categoria)
      .filter((i) => !t || [i.nombre, i.sku, i.categoria_nombre].some((v) => v.toLowerCase().includes(t)))
  }, [items, buscar, categoria])

  return (
    <>
      <h1 className="h3 fw-bold mb-0">Catálogo de materiales y herramientas</h1>
      <p className="text-secondary">Consulta la disponibilidad en las distintas bodegas y elige qué solicitar</p>
      <div className="row g-2 mb-4">
        <div className="col-12 col-md-8">
          <input type="search" className="form-control" placeholder="🔍 Buscar por nombre o categoría..."
            aria-label="Buscar por nombre o categoría" value={buscar} onChange={(e) => setBuscar(e.target.value)} />
        </div>
        <div className="col-12 col-md-4">
          <select className="form-select" aria-label="Filtrar por categoría" value={categoria} onChange={(e) => setCategoria(e.target.value)}>
            <option value="">Todas las categorías</option>
            {categorias.map((c) => <option key={c.id} value={c.id}>{c.nombre}</option>)}
          </select>
        </div>
      </div>

      {cargando && <Cargando />}
      {!cargando && visibles.length === 0 && <p className="text-secondary">No se encontraron ítems.</p>}
      <div className="row g-3">
        {visibles.map((i) => (
          <div className="col-12 col-md-6 col-xxl-4" key={i.id}>
            <div className="card stat h-100 p-3 d-flex flex-column">
              <div className="d-flex justify-content-between">
                <span className="sku">{i.sku}</span>
                <BadgeStock estado={estadoTrabajador(i.estado)} />
              </div>
              <h2 className="h5 fw-semibold mt-2 mb-0">{i.nombre}</h2>
              <p className="text-secondary small mb-2">{i.categoria_nombre} · {i.requiere_devolucion ? 'Préstamo' : 'Consumible'}</p>
              <p className="small">{stockPorBodega(i)}</p>
              {i.stock_total > 0
                ? <Link to={`/solicitar/${i.id}`} className="btn btn-accent w-100 mt-auto">Solicitar</Link>
                : <Link to={`/solicitar/${i.id}`} className="btn btn-outline-secondary w-100 mt-auto"
                  title="Sin stock: puedes solicitarlo indicando el motivo">Solicitar (sin stock)</Link>}
            </div>
          </div>
        ))}
      </div>
    </>
  )
}
