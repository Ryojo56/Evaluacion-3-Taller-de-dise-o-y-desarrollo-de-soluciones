// Reportes con filtros: Inventario, Movimientos y Préstamos.
// Los filtros (en la URL) se envían al backend, que recalcula KPIs, gráficos y filas;
// lo que se ve, lo que se grafica y lo que se exporta a CSV es siempre el mismo conjunto.
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api } from '../api/client'
import DataTable from '../components/DataTable'
import Filtros, { rangoPreset, useFiltros } from '../components/Filtros'
import { BarrasH, Columnas, Panel } from '../components/Graficos'
import { Alerta, BadgeStock, SectionTabs, useCarga } from '../components/ui'
import { BarraOcupacion } from './Bodegas'
import { badge, descargarCSV, fecha, fechaHora } from '../utils'

const TABS = [['/reportes/inventario', 'Inventario'], ['/reportes/movimientos', 'Movimientos'], ['/reportes/prestamos', 'Préstamos']]
const nf = new Intl.NumberFormat('es-CL')
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']

function useDebounce(valor, ms = 350) {
  const [v, setV] = useState(valor)
  useEffect(() => { const t = setTimeout(() => setV(valor), ms); return () => clearTimeout(t) }, [valor, ms])
  return v
}

/** Carga un reporte cada vez que cambian los filtros */
function useReporte(ruta, query) {
  const q = useDebounce(query)
  return useCarga(() => api.get(`/reportes/${ruta}/?${q}`), [q])
}

function Kpis({ items }) {
  return (
    <div className="row g-2 g-md-3 mb-3">
      {items.map(({ label, valor, sub, tono }) => (
        <div className="col-6 col-md-4 col-xl" key={label}>
          <div className="card kpi h-100">
            <div className="kpi-label">{label}</div>
            <div className={`kpi-value ${tono ? `text-${tono}-emphasis` : ''}`}>{valor ?? '—'}</div>
            {sub && <div className="kpi-sub">{sub}</div>}
          </div>
        </div>
      ))}
    </div>
  )
}

export default function Reportes() {
  const { tab } = useParams()
  const { data: opciones } = useCarga(() => api.get('/reportes/opciones/'))
  const op = opciones || {}
  return (
    <>
      <SectionTabs tabs={TABS} />
      {tab === 'movimientos' ? <Movimientos op={op} /> : tab === 'prestamos' ? <Prestamos op={op} /> : <Inventario op={op} />}
    </>
  )
}

// =========================================================================== Inventario
function Inventario({ op }) {
  const filtros = useFiltros()
  const { data, cargando, error } = useReporte('inventario', filtros.query)
  const r = data || { resumen: {}, bodegas: [], por_categoria: [], filas: [] }
  const res = r.resumen
  const bodegaSel = filtros.valores.bodega

  const columnas = [
    { key: 'sku', label: 'SKU', className: 'sku' },
    { key: 'nombre', label: 'Nombre', className: 'fw-semibold', primary: true },
    { key: 'categoria', label: 'Categoría' },
    { key: 'tipo', label: 'Tipo' },
    ...r.bodegas.map((b) => ({ key: `b${b.id}`, label: b.abreviatura, value: (f) => f.por_bodega[String(b.id)] ?? 0 })),
    ...(bodegaSel ? [{ key: 'stock_total', label: 'Total (todas)', className: 'text-secondary' }] : [{ key: 'stock', label: 'Total', className: 'fw-semibold' }]),
    { key: 'stock_minimo', label: 'Mínimo' },
    { key: 'estado', label: 'Estado', value: (f) => f.estado_display, render: (f) => <BadgeStock estado={f.estado} /> },
  ]

  return (
    <>
      <h1 className="h3 fw-bold mb-0">Reporte de inventario</h1>
      <p className="text-secondary">Stock actual por bodega, categoría y estado</p>
      <Filtros filtros={filtros} totalFilas={r.filas.length}
        onExportar={() => descargarCSV('inventario.csv', columnas, r.filas)}
        campos={[
          { key: 'bodega', label: 'Bodega', tipo: 'select', opciones: op.bodegas, todos: 'Todas' },
          { key: 'categoria', label: 'Categoría', tipo: 'select', opciones: op.categorias, todos: 'Todas' },
          { key: 'tipo', label: 'Tipo', tipo: 'select', opciones: op.tipos_item },
          { key: 'estado', label: 'Estado de stock', tipo: 'select', opciones: op.estados_stock },
          { key: 'q', label: 'Buscar', tipo: 'buscar', placeholder: 'SKU o nombre', col: 'col-12 col-md-8 col-xl' },
        ]} />
      <Alerta>{error?.message}</Alerta>
      <Kpis items={[
        { label: 'Ítems', valor: res.items },
        { label: bodegaSel ? 'Unidades en la bodega' : 'Unidades en stock', valor: res.unidades != null && nf.format(res.unidades) },
        { label: 'Críticos o sin stock', valor: res.criticos, tono: res.criticos ? 'danger' : null },
        { label: 'Stock bajo', valor: res.stock_bajo, tono: res.stock_bajo ? 'warning' : null },
        {
          label: 'Ocupación', valor: res.capacidad ? `${Math.round((100 * res.ocupado) / res.capacidad)}%` : '—',
          sub: res.capacidad ? `${nf.format(res.ocupado)} de ${nf.format(res.capacidad)} unidades` : null,
        },
      ]} />
      <div className="row g-3 mb-3">
        <div className="col-12 col-lg-6">
          <Panel titulo="Unidades por categoría" subtitulo="Según los filtros aplicados">
            <BarrasH datos={r.por_categoria} />
          </Panel>
        </div>
        <div className="col-12 col-lg-6">
          <Panel titulo="Ocupación por bodega" subtitulo="Unidades guardadas sobre la capacidad de cada bodega">
            {r.bodegas.map((b) => {
              const pct = b.capacidad ? (100 * b.ocupado) / b.capacidad : 0
              return (
                <div key={b.id} className="mb-3">
                  <div className="d-flex justify-content-between small gap-2">
                    <span className="fw-medium">{b.nombre}</span>
                    <span className="text-secondary">{nf.format(b.ocupado)} / {nf.format(b.capacidad)} · <strong className="text-body">{Math.round(pct)}%</strong></span>
                  </div>
                  <BarraOcupacion pct={pct} />
                  <div className="small text-secondary mt-1">{nf.format(b.unidades_filtradas)} unidades coinciden con los filtros · {nf.format(b.capacidad - b.ocupado)} libres</div>
                </div>
              )
            })}
          </Panel>
        </div>
      </div>
      <div className="card dt-card overflow-hidden">
        <DataTable columns={columnas} rows={r.filas} loading={cargando} defaultSort={{ key: 'nombre', dir: 'asc' }} pageLength={25} />
      </div>
    </>
  )
}

// =========================================================================== Movimientos
function etiquetaSerie(p) {
  const [a, m, d] = p.fecha.split('-')
  return p.mes
    ? { etiqueta: `${MESES[+m - 1]} ${a.slice(2)}`, etiquetaLarga: `${MESES[+m - 1]} ${a}` }
    : { etiqueta: `${d}-${m}`, etiquetaLarga: `${d}-${m}-${a}` }
}

function Movimientos({ op }) {
  const filtros = useFiltros(rangoPreset('30d'))
  const { data, cargando, error } = useReporte('movimientos', filtros.query)
  const r = data || { resumen: {}, serie: [], top_salidas: [], filas: [] }
  const res = r.resumen

  const columnas = [
    { key: 'fecha', label: 'Fecha', className: 'sku', value: (m) => fechaHora(m.fecha), sortValue: (m) => m.fecha },
    { key: 'item', label: 'Ítem', primary: true, value: (m) => `${m.item_sku} ${m.item_nombre}`, render: (m) => <><span className="sku">{m.item_sku}</span> {m.item_nombre}</> },
    { key: 'bodega_nombre', label: 'Bodega' },
    { key: 'tipo_display', label: 'Tipo' },
    {
      key: 'cantidad', label: 'Cantidad', value: (m) => m.cantidad,
      render: (m) => <span className={`fw-semibold ${m.cantidad > 0 ? 'text-success' : 'text-danger'}`}>{m.cantidad > 0 ? '+' : ''}{m.cantidad}</span>,
    },
    { key: 'stock_resultante', label: 'Stock final' },
    { key: 'usuario_nombre', label: 'Usuario' },
    { key: 'detalle', label: 'Detalle', className: 'small text-secondary' },
  ]

  return (
    <>
      <h1 className="h3 fw-bold mb-0">Movimientos de stock</h1>
      <p className="text-secondary">Entradas, entregas, devoluciones y ajustes en el período</p>
      <Filtros filtros={filtros} conFechas totalFilas={r.filas.length}
        onExportar={() => descargarCSV('movimientos.csv', columnas, r.filas)}
        campos={[
          { key: 'bodega', label: 'Bodega', tipo: 'select', opciones: op.bodegas, todos: 'Todas' },
          { key: 'tipo', label: 'Tipo de movimiento', tipo: 'select', opciones: op.tipos_movimiento },
          { key: 'categoria', label: 'Categoría', tipo: 'select', opciones: op.categorias, todos: 'Todas' },
          { key: 'item', label: 'Ítem', tipo: 'select', opciones: op.items },
          { key: 'usuario', label: 'Usuario', tipo: 'select', opciones: op.usuarios },
          { key: 'q', label: 'Buscar', tipo: 'buscar', placeholder: 'Ítem o detalle', col: 'col-12 col-md-8 col-xl' },
        ]} />
      <Alerta>{error?.message}</Alerta>
      {res.truncado && <Alerta tipo="warning">Se muestran los 2.000 movimientos más recientes. Acota el período para ver el resto.</Alerta>}
      <Kpis items={[
        { label: 'Movimientos', valor: res.movimientos },
        { label: 'Entradas', valor: res.entradas != null && `+${nf.format(res.entradas)}`, sub: 'unidades ingresadas' },
        { label: 'Salidas (entregas)', valor: res.salidas != null && nf.format(res.salidas), sub: 'unidades entregadas' },
        { label: 'Devoluciones', valor: res.devoluciones != null && `+${nf.format(res.devoluciones)}`, sub: 'unidades devueltas' },
        { label: 'Ajustes (neto)', valor: res.ajustes != null && `${res.ajustes > 0 ? '+' : ''}${nf.format(res.ajustes)}` },
      ]} />
      <div className="row g-3 mb-3">
        <div className="col-12 col-xl-8">
          <Panel titulo="Unidades por día" subtitulo="Ingresos (entradas, devoluciones y ajustes positivos) frente a salidas">
            <Columnas datos={r.serie.map((p) => ({ ...p, ...etiquetaSerie(p) }))}
              series={[{ key: 'ingresos', nombre: 'Ingresos' }, { key: 'salidas', nombre: 'Salidas' }]} />
          </Panel>
        </div>
        <div className="col-12 col-xl-4">
          <Panel titulo="Ítems más entregados" subtitulo="Unidades entregadas en el período">
            <BarrasH datos={r.top_salidas} />
          </Panel>
        </div>
      </div>
      <div className="card dt-card overflow-hidden">
        <DataTable columns={columnas} rows={r.filas} loading={cargando} defaultSort={{ key: 'fecha', dir: 'desc' }} pageLength={25} />
      </div>
    </>
  )
}

// =========================================================================== Préstamos
const TONO_ESTADO = { pendiente: 'primary', activo: 'info', vencido: 'danger', devuelto: 'success', consumido: 'secondary', rechazado: 'dark', cancelado: 'secondary' }

function Prestamos({ op }) {
  const filtros = useFiltros(rangoPreset('30d'))
  const { data, cargando, error } = useReporte('prestamos', filtros.query)
  const r = data || { resumen: {}, por_estado: [], por_trabajador: [], por_item: [], condicion_devolucion: [], filas: [] }
  const res = r.resumen

  const columnas = [
    { key: 'fecha', label: 'Solicitada', className: 'sku', value: (s) => fecha(s.fecha_solicitud), sortValue: (s) => s.fecha_solicitud },
    { key: 'item', label: 'Ítem', primary: true, value: (s) => `${s.item_sku} ${s.item_nombre}`, render: (s) => <><span className="sku">{s.item_sku}</span> {s.item_nombre}</> },
    { key: 'trabajador_nombre', label: 'Trabajador' },
    { key: 'cantidad', label: 'Cant.' },
    {
      key: 'estado', label: 'Estado', value: (s) => s.estado_reporte_display,
      render: (s) => <span className={badge(TONO_ESTADO[s.estado_reporte])}>{s.estado_reporte_display}</span>,
    },
    { key: 'bodega_nombre', label: 'Bodega', value: (s) => s.bodega_nombre || '—' },
    { key: 'limite', label: 'Fecha límite', className: 'sku', value: (s) => (s.fecha_limite ? fecha(s.fecha_limite) : '—'), sortValue: (s) => s.fecha_limite },
    { key: 'condicion', label: 'Devuelto en', value: (s) => s.estado_devolucion_display || '—' },
    { key: 'sobre', label: 'Sobre stock', value: (s) => (s.excede_stock ? 'Sí' : 'No'), render: (s) => (s.excede_stock ? <span className={badge('warning')} title={s.motivo}>Sí</span> : <span className="text-secondary">No</span>) },
  ]

  return (
    <>
      <h1 className="h3 fw-bold mb-0">Reporte de préstamos y solicitudes</h1>
      <p className="text-secondary">Solicitudes hechas en el período, su estado y cómo se devolvieron</p>
      <Filtros filtros={filtros} conFechas totalFilas={r.filas.length}
        onExportar={() => descargarCSV('prestamos.csv', columnas, r.filas)}
        campos={[
          { key: 'estado', label: 'Estado', tipo: 'select', opciones: op.estados_prestamo },
          { key: 'trabajador', label: 'Trabajador', tipo: 'select', opciones: op.trabajadores },
          { key: 'tipo', label: 'Tipo de ítem', tipo: 'select', opciones: op.tipos_item },
          { key: 'categoria', label: 'Categoría', tipo: 'select', opciones: op.categorias, todos: 'Todas' },
          { key: 'bodega', label: 'Bodega de entrega', tipo: 'select', opciones: op.bodegas, todos: 'Todas' },
          { key: 'sobre_stock', label: 'Solo pedidos sobre stock', tipo: 'check' },
          { key: 'q', label: 'Buscar', tipo: 'buscar', placeholder: 'Ítem o trabajador', col: 'col-12 col-md-8 col-xl' },
        ]} />
      <Alerta>{error?.message}</Alerta>
      <Kpis items={[
        { label: 'Solicitudes', valor: res.solicitudes, sub: res.unidades != null && `${nf.format(res.unidades)} unidades` },
        { label: 'Pendientes', valor: res.pendientes },
        { label: 'En préstamo', valor: res.activos },
        { label: 'Vencidos', valor: res.vencidos, tono: res.vencidos ? 'danger' : null },
        { label: 'Devueltos', valor: res.devueltos, sub: res.pct_a_tiempo != null ? `${res.pct_a_tiempo}% a tiempo · ${res.pct_buen_estado}% en buen estado` : null },
        { label: 'Pedidos sobre stock', valor: res.sobre_stock, tono: res.sobre_stock ? 'warning' : null },
      ]} />
      <div className="row g-3 mb-3">
        <div className="col-12 col-md-6 col-xl-4">
          <Panel titulo="Solicitudes por estado"><BarrasH datos={r.por_estado.filter((e) => e.valor)} /></Panel>
        </div>
        <div className="col-12 col-md-6 col-xl-4">
          <Panel titulo="Trabajadores con más solicitudes"><BarrasH datos={r.por_trabajador} /></Panel>
        </div>
        <div className="col-12 col-xl-4">
          <Panel titulo="Ítems más solicitados"><BarrasH datos={r.por_item} /></Panel>
        </div>
        <div className="col-12">
          <Panel titulo="Estado de las herramientas devueltas" subtitulo="Lo que informaron los trabajadores al devolver">
            <div className="row g-2 text-center">
              {r.condicion_devolucion.map((c) => (
                <div className="col-4" key={c.id}>
                  <div className="bg-light rounded-3 py-2">
                    <div className="fw-bold fs-4">{c.valor}</div>
                    <div className={`small ${badge({ bueno: 'success', regular: 'warning', con_falla: 'danger' }[c.id])}`}>{c.nombre}</div>
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
      <div className="card dt-card overflow-hidden">
        <DataTable columns={columnas} rows={r.filas} loading={cargando} defaultSort={{ key: 'fecha', dir: 'desc' }} pageLength={25} />
      </div>
    </>
  )
}
