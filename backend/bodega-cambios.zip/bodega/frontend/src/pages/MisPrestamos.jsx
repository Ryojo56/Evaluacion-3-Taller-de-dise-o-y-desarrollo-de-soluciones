// Mis préstamos y solicitudes (trabajador)
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import DataTable from '../components/DataTable'
import { Alerta, BadgeDevolucion, BadgeSolicitud, Flash, PageHeader, useCarga } from '../components/ui'
import { fecha, infoDevolucion } from '../utils'

export default function MisPrestamos() {
  const { data, cargando, recargar } = useCarga(() => api.get('/solicitudes/?mias=1'))
  const [buscar, setBuscar] = useState('')
  const [error, setError] = useState(null)

  async function cancelar(s) {
    setError(null)
    try {
      await api.post(`/solicitudes/${s.id}/cancelar/`)
      recargar()
    } catch (ex) {
      setError(ex.message)
    }
  }

  const columnas = [
    {
      key: 'item_nombre', label: 'Producto', primary: true, value: (s) => `${s.item_nombre} ${s.item_sku}`, sortValue: (s) => s.item_nombre,
      render: (s) => <><span className="fw-semibold">{s.item_nombre}</span> · <span className="sku">{s.item_sku}</span></>,
    },
    { key: 'cantidad', label: 'Cantidad' },
    { key: 'fecha', label: 'Solicitada', className: 'sku', value: (s) => fecha(s.fecha_solicitud), sortValue: (s) => s.fecha_solicitud },
    {
      key: 'estado', label: 'Estado', value: (s) => s.estado_display,
      render: (s) => (
        <>
          <BadgeSolicitud estado={s.estado} />
          {s.estado === 'pendiente' && s.excede_stock && s.disponible_actual < s.cantidad && (
            <div className="small text-warning-emphasis">Esperando reposición de stock</div>
          )}
          {s.estado === 'rechazada' && s.motivo_rechazo && <div className="small text-secondary">{s.motivo_rechazo}</div>}
        </>
      ),
    },
    {
      key: 'devolucion', label: 'Devolución', value: (s) => infoDevolucion(s).texto, sortValue: (s) => infoDevolucion(s).orden,
      render: (s) => s.estado === 'devuelta'
        ? <><BadgeDevolucion estado={s.estado_devolucion} /> <span className="sku">{fecha(s.fecha_devolucion)}</span></>
        : <span className={infoDevolucion(s).clase}>{infoDevolucion(s).texto}</span>,
    },
    {
      key: 'acciones', label: 'Acciones', sortable: false, thClassName: 'text-end', className: 'text-end text-nowrap',
      render: (s) => {
        if (s.estado === 'pendiente') return <button className="btn btn-link btn-sm link-danger p-0" onClick={() => cancelar(s)}>Cancelar</button>
        if (s.estado === 'despachada' && s.es_prestamo) return <Link to={`/devolver/${s.id}`} className="btn btn-accent btn-sm">Devolver</Link>
        return null
      },
    },
  ]

  return (
    <>
      <PageHeader titulo="Mis préstamos y solicitudes" subtitulo="Revisa el estado de lo que pediste y devuelve las herramientas a tiempo">
        <Link to="/catalogo" className="btn btn-accent">+ Nueva solicitud</Link>
      </PageHeader>
      <Flash />
      <Alerta onClose={() => setError(null)}>{error}</Alerta>
      <input type="search" className="form-control mb-3" style={{ maxWidth: 360 }} placeholder="🔍 Buscar..."
        aria-label="Buscar" value={buscar} onChange={(e) => setBuscar(e.target.value)} />
      <div className="card dt-card overflow-hidden">
        <DataTable columns={columnas} rows={data || []} loading={cargando} search={buscar}
          defaultSort={{ key: 'fecha', dir: 'desc' }} rowClassName={(s) => infoDevolucion(s).fila} />
      </div>
    </>
  )
}
