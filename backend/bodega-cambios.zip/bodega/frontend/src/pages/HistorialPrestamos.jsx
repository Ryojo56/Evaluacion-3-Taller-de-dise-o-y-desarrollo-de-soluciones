// 06 · Historial de préstamos y entregas
import { useState } from 'react'
import { api } from '../api/client'
import DataTable from '../components/DataTable'
import { BadgeDevolucion, Modal, SectionTabs, useCarga } from '../components/ui'
import { badge, fecha, fechaHora, infoDevolucion } from '../utils'

export const TABS_PRESTAMOS = [['/solicitudes', 'Solicitudes'], ['/historial', 'Historial']]

export function EstadoPrestamo({ s }) {
  if (s.estado === 'devuelta') return <BadgeDevolucion estado={s.estado_devolucion} />
  if (!s.es_prestamo) return <span className={badge('secondary')}>Entregado</span>
  if (s.vencida) return <span className={badge('danger')}>Vencido</span>
  return <span className={badge('primary')}>En préstamo</span>
}

const textoEstado = (s) =>
  s.estado === 'devuelta' ? s.estado_devolucion_display : !s.es_prestamo ? 'Entregado' : s.vencida ? 'Vencido' : 'En préstamo'

export default function HistorialPrestamos() {
  const [buscar, setBuscar] = useState('')
  const [orden, setOrden] = useState('desc')
  const [detalle, setDetalle] = useState(null)
  const { data, cargando } = useCarga(() => api.get('/solicitudes/?estado=despachada,devuelta'))

  const columnas = [
    {
      key: 'item', label: 'Herramienta', primary: true, value: (s) => `${s.item_nombre} ${s.item_sku}`, sortValue: (s) => s.item_nombre,
      render: (s) => (
        <button type="button" className="btn btn-link p-0 text-reset text-decoration-none text-start fw-semibold" onClick={() => setDetalle(s)}>
          {s.item_nombre} <span className="sku fw-normal">· {s.item_sku}</span>
        </button>
      ),
    },
    { key: 'trabajador_nombre', label: 'Trabajador', render: (s) => <>{s.trabajador_nombre}{s.cantidad > 1 && <span className="text-secondary small"> ×{s.cantidad}</span>}</> },
    { key: 'entrega', label: 'Entrega', className: 'sku', value: (s) => fecha(s.fecha_entrega), sortValue: (s) => s.fecha_entrega },
    {
      key: 'devolucion', label: 'Devolución', value: (s) => infoDevolucion(s).texto, sortValue: (s) => infoDevolucion(s).orden,
      render: (s) => { const d = infoDevolucion(s); return <span className={d.clase}>{d.texto}</span> },
    },
    { key: 'responsable_nombre', label: 'Responsable' },
    { key: 'estado', label: 'Estado', value: textoEstado, render: (s) => <EstadoPrestamo s={s} /> },
  ]

  return (
    <>
      <SectionTabs tabs={TABS_PRESTAMOS} />
      <h1 className="h3 fw-bold mb-0">Historial de préstamos y entregas</h1>
      <p className="text-secondary">Búsqueda por herramienta o trabajador</p>
      <div className="row g-2 mb-3">
        <div className="col-12 col-md-8">
          <input type="search" className="form-control" placeholder="Buscar por código de herramienta o trabajador"
            aria-label="Buscar por herramienta o trabajador" value={buscar} onChange={(e) => setBuscar(e.target.value)} />
        </div>
        <div className="col-12 col-md-4">
          <select className="form-select" aria-label="Ordenar por fecha" value={orden} onChange={(e) => setOrden(e.target.value)}>
            <option value="desc">Más recientes primero</option>
            <option value="asc">Más antiguas primero</option>
          </select>
        </div>
      </div>
      <div className="card dt-card overflow-hidden">
        <DataTable
          columns={columnas}
          rows={data || []}
          loading={cargando}
          search={buscar}
          defaultSort={{ key: 'entrega', dir: orden }}
          rowClassName={(s) => infoDevolucion(s).fila}
        />
      </div>

      <Modal titulo="Detalle del préstamo" abierto={!!detalle} onClose={() => setDetalle(null)}>
        {detalle && (
          <dl className="row small mb-0">
            <dt className="col-5">Ítem</dt><dd className="col-7">{detalle.item_nombre} <span className="sku">{detalle.item_sku}</span></dd>
            <dt className="col-5">Cantidad</dt><dd className="col-7">{detalle.cantidad}</dd>
            <dt className="col-5">Trabajador</dt><dd className="col-7">{detalle.trabajador_nombre}</dd>
            <dt className="col-5">Motivo</dt><dd className="col-7">{detalle.motivo || '—'}</dd>
            <dt className="col-5">Bodega</dt><dd className="col-7">{detalle.bodega_nombre}</dd>
            <dt className="col-5">Entregado</dt><dd className="col-7">{fechaHora(detalle.fecha_entrega)} por {detalle.responsable_nombre}</dd>
            {detalle.es_prestamo && <><dt className="col-5">Fecha límite</dt><dd className="col-7">{fechaHora(detalle.fecha_limite)}</dd></>}
            {detalle.estado === 'devuelta' && (
              <>
                <dt className="col-5">Devuelto</dt><dd className="col-7">{fechaHora(detalle.fecha_devolucion)}</dd>
                <dt className="col-5">Estado general</dt><dd className="col-7"><BadgeDevolucion estado={detalle.estado_devolucion} /></dd>
                <dt className="col-12 mt-2">Comentario del trabajador</dt>
                <dd className="col-12 bg-light rounded-3 p-2 mb-0" style={{ whiteSpace: 'pre-wrap' }}>{detalle.comentario_devolucion}</dd>
              </>
            )}
          </dl>
        )}
      </Modal>
    </>
  )
}
