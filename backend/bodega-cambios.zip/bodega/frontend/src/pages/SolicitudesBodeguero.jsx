// 12 · Solicitudes pendientes de entrega (bodeguero)
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import DataTable from '../components/DataTable'
import { Alerta, BadgeSolicitud, Modal, SectionTabs, useCarga } from '../components/ui'
import { aDatetimeLocal, badge, fecha } from '../utils'
import { TABS_PRESTAMOS } from './HistorialPrestamos'

const DIAS_PRESTAMO = 3

export default function SolicitudesBodeguero() {
  const [buscar, setBuscar] = useState('')
  const [filtro, setFiltro] = useState('pendiente,despachada')
  const { data, cargando, recargar } = useCarga(() => api.get(`/solicitudes/?estado=${filtro}`), [filtro])
  const [msg, setMsg] = useState(null)

  const [entregando, setEntregando] = useState(null) // { solicitud, item }
  const [bodega, setBodega] = useState('')
  const [limite, setLimite] = useState('')
  const [rechazando, setRechazando] = useState(null)
  const [motivoRechazo, setMotivoRechazo] = useState('')
  const [error, setError] = useState(null)
  const [enviando, setEnviando] = useState(false)

  async function abrirEntrega(s) {
    setError(null)
    const item = await api.get(`/items/${s.item}/`)
    // Sugiere la primera bodega con stock suficiente
    const conStock = item.stock_por_bodega.find((b) => b.cantidad >= s.cantidad)
    setBodega(conStock ? String(conStock.bodega) : '')
    setLimite(aDatetimeLocal(new Date(Date.now() + DIAS_PRESTAMO * 864e5)))
    setEntregando({ s, item })
  }

  async function confirmarEntrega() {
    setEnviando(true)
    setError(null)
    try {
      const body = { bodega: Number(bodega) }
      if (entregando.s.es_prestamo) body.fecha_limite = new Date(limite).toISOString()
      await api.post(`/solicitudes/${entregando.s.id}/entregar/`, body)
      setMsg(`Entrega registrada: ${entregando.s.item_nombre} para ${entregando.s.trabajador_nombre}.`)
      setEntregando(null)
      recargar()
    } catch (ex) {
      setError(ex.message)
    } finally {
      setEnviando(false)
    }
  }

  async function confirmarRechazo() {
    setEnviando(true)
    setError(null)
    try {
      await api.post(`/solicitudes/${rechazando.id}/rechazar/`, { motivo: motivoRechazo })
      setMsg(`Solicitud de ${rechazando.trabajador_nombre} rechazada.`)
      setRechazando(null)
      recargar()
    } catch (ex) {
      setError(ex.message)
    } finally {
      setEnviando(false)
    }
  }

  const columnas = [
    { key: 'trabajador_nombre', label: 'Trabajador', className: 'fw-semibold', primary: true },
    {
      key: 'item_nombre', label: 'Producto', value: (s) => `${s.item_nombre} · ${s.item_sku}`,
      render: (s) => (
        <div className="text-start">
          {s.item_nombre} · <span className="sku">{s.item_sku}</span>
          {s.excede_stock && s.estado === 'pendiente' && (
            <span className={`${badge(s.disponible_actual >= s.cantidad ? 'success' : 'warning')} ms-2`}
              title={`Al solicitar había ${s.stock_al_solicitar}`}>
              {s.disponible_actual >= s.cantidad ? 'Stock repuesto' : `Supera stock · hay ${s.disponible_actual}`}
            </span>
          )}
          {s.motivo && (
            <div className={`small ${s.excede_stock ? 'text-body border-start border-3 border-warning ps-2 mt-1' : 'text-secondary'}`}>
              {s.excede_stock && <strong>Motivo: </strong>}{s.motivo}
            </div>
          )}
        </div>
      ),
    },
    { key: 'cantidad', label: 'Cantidad' },
    { key: 'fecha', label: 'Fecha solicitud', className: 'sku', value: (s) => fecha(s.fecha_solicitud), sortValue: (s) => s.fecha_solicitud },
    { key: 'estado', label: 'Estado', value: (s) => s.estado_display, render: (s) => <BadgeSolicitud estado={s.estado} /> },
    {
      key: 'acciones', label: 'Acciones', sortable: false, thClassName: 'text-end', className: 'text-end text-nowrap',
      render: (s) =>
        s.estado === 'pendiente' ? (
          <>
            <button className="btn btn-link btn-sm link-danger me-1" onClick={() => { setError(null); setMotivoRechazo(''); setRechazando(s) }}>Rechazar</button>
            <button className="btn btn-accent btn-sm" onClick={() => abrirEntrega(s)}>Entregar</button>
          </>
        ) : (
          <span className="small">{s.estado === 'despachada' ? 'Ya entregada' : s.estado_display}</span>
        ),
    },
  ]

  const e = entregando
  return (
    <>
      <SectionTabs tabs={TABS_PRESTAMOS} />
      <h1 className="h3 fw-bold mb-0">Solicitudes pendientes de entrega</h1>
      <p className="text-secondary">Valida la entrega de un ítem solicitado por un trabajador</p>
      <Alerta tipo="success" onClose={() => setMsg(null)}>{msg}</Alerta>
      <div className="d-flex flex-wrap gap-2 mb-3">
        <input type="search" className="form-control" style={{ maxWidth: 360 }} placeholder="🔍 Buscar solicitud..."
          aria-label="Buscar solicitud" value={buscar} onChange={(ev) => setBuscar(ev.target.value)} />
        <select className="form-select w-auto" value={filtro} onChange={(ev) => setFiltro(ev.target.value)} aria-label="Filtrar por estado">
          <option value="pendiente,despachada">Pendientes y despachadas</option>
          <option value="pendiente">Solo pendientes</option>
          <option value="pendiente,despachada,devuelta,rechazada,cancelada">Todas</option>
        </select>
      </div>
      <div className="card dt-card overflow-hidden">
        <DataTable
          columns={columnas}
          rows={data || []}
          loading={cargando}
          search={buscar}
          defaultSort={{ key: 'fecha', dir: 'desc' }}
          rowClassName={(s) => (s.estado !== 'pendiente' ? 'text-secondary' : undefined)}
        />
      </div>

      <Modal titulo="Registrar entrega" abierto={!!e} onClose={() => setEntregando(null)}
        pie={<>
          <button className="btn btn-outline-secondary" onClick={() => setEntregando(null)}>Cancelar</button>
          <button className="btn btn-accent" onClick={confirmarEntrega} disabled={!bodega || enviando || (e?.s.es_prestamo && !limite)}>
            Confirmar entrega
          </button>
        </>}>
        {e && (
          <>
            <Alerta>{error}</Alerta>
            <div className="bg-light rounded-3 p-3 mb-3">
              <div className="fw-semibold">{e.s.item_nombre} <span className="sku">· {e.s.item_sku}</span></div>
              <div className="small">Cantidad: <strong>{e.s.cantidad}</strong> · Trabajador: {e.s.trabajador_nombre}</div>
            </div>
            <div className="mb-3">
              <label htmlFor="bod" className="form-label small text-secondary">Bodega de origen</label>
              <select id="bod" className="form-select" value={bodega} onChange={(ev) => setBodega(ev.target.value)}>
                <option value="">Selecciona…</option>
                {e.item.stock_por_bodega.map((b) => (
                  <option key={b.bodega} value={b.bodega} disabled={b.cantidad < e.s.cantidad}>
                    {b.bodega_nombre} (stock: {b.cantidad})
                  </option>
                ))}
              </select>
              {!e.item.stock_por_bodega.some((b) => b.cantidad >= e.s.cantidad) && (
                <div className="alert alert-warning small mt-2 mb-0">
                  Ninguna bodega tiene {e.s.cantidad} unidades (total disponible: {e.item.stock_total}).
                  Repón stock desde <Link to={`/items/${e.item.id}`}>la ficha del ítem</Link> o rechaza la solicitud indicando el motivo.
                  {e.s.excede_stock && <div className="mt-1"><strong>Motivo del trabajador:</strong> {e.s.motivo}</div>}
                </div>
              )}
            </div>
            {e.s.es_prestamo ? (
              <div className="mb-1">
                <label htmlFor="lim" className="form-label small text-secondary">Fecha límite de devolución</label>
                <input id="lim" type="datetime-local" className="form-control" value={limite}
                  min={aDatetimeLocal(new Date())} onChange={(ev) => setLimite(ev.target.value)} />
              </div>
            ) : (
              <p className="small text-secondary mb-0">Es un ítem consumible: no requiere devolución.</p>
            )}
          </>
        )}
      </Modal>

      <Modal titulo="Rechazar solicitud" abierto={!!rechazando} onClose={() => setRechazando(null)}
        pie={<>
          <button className="btn btn-outline-secondary" onClick={() => setRechazando(null)}>Cancelar</button>
          <button className="btn btn-danger" onClick={confirmarRechazo} disabled={enviando}>Rechazar</button>
        </>}>
        <Alerta>{error}</Alerta>
        <p className="small">{rechazando?.trabajador_nombre} solicitó {rechazando?.cantidad} × {rechazando?.item_nombre}.</p>
        <label htmlFor="mr" className="form-label small text-secondary">Motivo del rechazo (opcional)</label>
        <textarea id="mr" className="form-control" rows="3" maxLength={300} value={motivoRechazo} onChange={(ev) => setMotivoRechazo(ev.target.value)} />
      </Modal>
    </>
  )
}
