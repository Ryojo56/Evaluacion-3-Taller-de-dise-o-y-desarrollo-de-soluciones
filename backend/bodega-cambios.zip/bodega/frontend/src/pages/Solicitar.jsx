// 11 · Solicitar herramienta o material
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { api } from '../api/client'
import Icon from '../components/Icon'
import { Alerta, Cargando, useCarga } from '../components/ui'
import { useAuth } from '../context/AuthContext'
import { badge, hoy } from '../utils'

const MOTIVO_MINIMO = 15

export default function Solicitar() {
  const { itemId } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()
  const { data: item, cargando, error: errorCarga } = useCarga(() => api.get(`/items/${itemId}/`), [itemId])
  const [cantidad, setCantidad] = useState(1)
  const [motivo, setMotivo] = useState('')
  const [error, setError] = useState(null)
  const [enviando, setEnviando] = useState(false)
  const [tocado, setTocado] = useState(false)

  if (cargando) return <Cargando />
  if (errorCarga) return <Alerta>{errorCarga.message}</Alerta>

  const max = item.stock_total
  const cantidadValida = Number.isInteger(+cantidad) && +cantidad >= 1
  // Se puede pedir más de lo disponible, pero entonces el motivo es obligatorio
  const excede = cantidadValida && +cantidad > max
  const largoMotivo = motivo.trim().length
  const motivoValido = !excede || largoMotivo >= MOTIVO_MINIMO

  async function onSubmit(e) {
    e.preventDefault()
    setError(null)
    setEnviando(true)
    try {
      await api.post('/solicitudes/', { item: item.id, cantidad: +cantidad, motivo: motivo.trim() })
      navigate('/mis-prestamos', {
        state: {
          flash: excede
            ? `Solicitud de ${item.nombre} enviada. Como supera el stock actual, se entregará cuando el bodeguero reponga.`
            : `Solicitud de ${item.nombre} enviada. Queda pendiente hasta que el bodeguero la revise.`,
        },
      })
    } catch (ex) {
      setError(ex.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <div className="card" style={{ maxWidth: 640 }}>
      <div className="card-header bg-white d-flex justify-content-between align-items-center p-3">
        <h1 className="h6 fw-bold mb-0">Solicitar herramienta o material</h1>
        <Link to="/catalogo" className="small text-secondary text-decoration-none">← Volver al catálogo</Link>
      </div>
      <form className="card-body p-4" onSubmit={onSubmit} noValidate>
        <Alerta onClose={() => setError(null)}>{error}</Alerta>
        <div className="d-flex justify-content-between align-items-center gap-2 bg-light rounded-3 p-3 mb-4">
          <div>
            <div className="fw-semibold">{item.nombre}</div>
            <div className="sku">SKU: {item.sku}</div>
          </div>
          <span className={`${badge(max > 0 ? 'success' : 'secondary')} flex-none`}>Disponible: {max}</span>
        </div>
        <div className="mb-3">
          <label htmlFor="cant" className="form-label small text-secondary">Cantidad requerida</label>
          <input type="number" id="cant" className={`form-control ${cantidadValida ? '' : 'is-invalid'}`} min="1"
            value={cantidad} onChange={(e) => setCantidad(e.target.value)} aria-describedby="cantAyuda" />
          <div className="invalid-feedback">Ingresa una cantidad entera mayor que 0.</div>
        </div>
        {excede && (
          <div className="alert alert-warning small d-flex gap-2" id="cantAyuda" role="status">
            <Icon name="warning" />
            <div>
              Pides <strong>{cantidad}</strong> y hay <strong>{max}</strong> disponible{max === 1 ? '' : 's'}. Puedes enviar la solicitud,
              pero <strong>debes explicar el motivo</strong>: el bodeguero lo usará para gestionar la reposición y la entregará
              cuando haya stock suficiente.
            </div>
          </div>
        )}
        <div className="mb-3">
          <label htmlFor="mot" className="form-label small text-secondary">
            Motivo / tarea asociada {excede ? <strong className="text-danger">(obligatorio)</strong> : '(opcional)'}
          </label>
          <textarea id="mot" rows="3" maxLength={300}
            className={`form-control ${excede && tocado && !motivoValido ? 'is-invalid' : ''}`}
            placeholder={excede ? 'Ej. Se necesitan 20 sacos para terminar el radier de la bodega sur esta semana' : 'Ej. Mantención eléctrica taller B'}
            value={motivo} onChange={(e) => setMotivo(e.target.value)} onBlur={() => setTocado(true)} />
          <div className="invalid-feedback">Explica por qué necesitas esa cantidad (mínimo {MOTIVO_MINIMO} caracteres).</div>
          {excede && (
            <div className={`form-text ${largoMotivo < MOTIVO_MINIMO ? '' : 'text-success'}`}>
              {largoMotivo}/{MOTIVO_MINIMO} caracteres mínimos{largoMotivo >= MOTIVO_MINIMO && ' ✓'}
            </div>
          )}
        </div>
        <div className="alert alert-light border small">
          La solicitud quedará registrada con tu nombre ({user.nombre_completo}) y la fecha de hoy, {hoy()}, con estado{' '}
          <strong>Pendiente</strong> hasta ser revisada por el Bodeguero.
          {item.requiere_devolucion && ' Al tratarse de una herramienta, deberás devolverla en el plazo indicado al momento de la entrega.'}
        </div>
        <div className="d-flex gap-2 mt-4">
          <button type="submit" className="btn btn-accent flex-fill py-2" disabled={!cantidadValida || !motivoValido || enviando}>
            {enviando ? 'Enviando…' : 'Enviar solicitud'}
          </button>
          <button type="button" className="btn btn-outline-secondary flex-fill py-2" onClick={() => navigate('/catalogo')}>Cancelar</button>
        </div>
      </form>
    </div>
  )
}
