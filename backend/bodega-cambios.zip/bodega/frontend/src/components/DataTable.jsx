import { useEffect, useMemo, useState } from 'react'

/*
  Tabla con búsqueda, orden por columna y paginación.
  Replica el comportamiento y textos de DataTables (bodega-dt.js) sin jQuery.

  columns: [{
    key, label,
    value: fila => texto/número  (búsqueda, orden y CSV)
    render: fila => JSX          (opcional; por defecto muestra value)
    sortValue: fila => valor     (opcional; p.ej. fecha ISO para ordenar)
    sortable: false, className, thClassName
    primary: true                (en móvil se muestra como título de la tarjeta)
  }]
*/
const LONGITUDES = [5, 10, 25, 50]

export default function DataTable({
  columns,
  rows,
  search,              // texto de un buscador externo (DOM_EXT)
  showSearch = false,  // buscador propio (DOM_FULL)
  defaultSort,         // { key, dir: 'asc' | 'desc' }
  pageLength = 10,
  rowClassName,
  loading = false,
  responsive = true,   // en móvil, cada fila se muestra como tarjeta
}) {
  const [q, setQ] = useState('')
  const [orden, setOrden] = useState(defaultSort || null)
  const [largo, setLargo] = useState(pageLength)
  const [pagina, setPagina] = useState(0)
  const termino = (showSearch ? q : search || '').trim().toLowerCase()

  useEffect(() => {
    if (defaultSort) setOrden(defaultSort)
  }, [defaultSort?.key, defaultSort?.dir]) // eslint-disable-line react-hooks/exhaustive-deps

  const valor = (col, fila) => (col.value ? col.value(fila) : fila[col.key])

  const filtradas = useMemo(() => {
    if (!termino) return rows
    return rows.filter((f) =>
      columns.some((c) => String(valor(c, f) ?? '').toLowerCase().includes(termino)),
    )
  }, [rows, termino, columns]) // eslint-disable-line react-hooks/exhaustive-deps

  const ordenadas = useMemo(() => {
    const col = orden && columns.find((c) => c.key === orden.key)
    if (!col) return filtradas
    const get = col.sortValue || ((f) => valor(col, f))
    return [...filtradas].sort((a, b) => {
      const x = get(a)
      const y = get(b)
      if (x == null || x === '') return 1 // vacíos siempre al final
      if (y == null || y === '') return -1
      const cmp = typeof x === 'number' && typeof y === 'number'
        ? x - y
        : String(x).localeCompare(String(y), 'es', { numeric: true, sensitivity: 'base' })
      return orden.dir === 'asc' ? cmp : -cmp
    })
  }, [filtradas, orden, columns]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => setPagina(0), [termino, largo, rows])

  const total = ordenadas.length
  const paginas = Math.max(1, Math.ceil(total / largo))
  const p = Math.min(pagina, paginas - 1)
  const visibles = ordenadas.slice(p * largo, p * largo + largo)

  function ordenarPor(col) {
    if (col.sortable === false) return
    setOrden((o) => ({ key: col.key, dir: o?.key === col.key && o.dir === 'asc' ? 'desc' : 'asc' }))
  }

  return (
    <>
      {showSearch && (
        <div className="dt-bar d-flex justify-content-end">
          <label className="d-flex align-items-center gap-2 small text-secondary mb-0">
            Buscar:
            <input type="search" className="form-control form-control-sm" value={q} onChange={(e) => setQ(e.target.value)} />
          </label>
        </div>
      )}
      <div className="table-responsive">
        <table className={`table table-hover align-middle mb-0 w-100 dataTable ${responsive ? 'dt-responsive' : ''}`}>
          <thead>
            <tr>
              {columns.map((c) => {
                const activo = orden?.key === c.key
                const ordenable = c.sortable !== false
                return (
                  <th
                    key={c.key}
                    className={`${c.thClassName || ''} ${ordenable ? 'dt-sortable' : 'sorting_disabled'}`}
                    onClick={() => ordenarPor(c)}
                    aria-sort={activo ? (orden.dir === 'asc' ? 'ascending' : 'descending') : undefined}
                  >
                    {c.label}
                    {ordenable && <span className={`dt-arrow ${activo ? 'on' : ''}`}>{activo && orden.dir === 'desc' ? '▼' : '▲'}</span>}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={columns.length} className="text-center text-secondary py-4 dt-empty">Cargando…</td></tr>
            )}
            {!loading && visibles.length === 0 && (
              <tr>
                <td colSpan={columns.length} className="text-center text-secondary py-4 dt-empty">
                  {rows.length ? 'No se encontraron resultados' : 'Sin datos disponibles'}
                </td>
              </tr>
            )}
            {!loading && visibles.map((f, i) => (
              <tr key={f.id ?? i} className={rowClassName ? rowClassName(f) : undefined}>
                {columns.map((c) => (
                  <td key={c.key} data-label={c.label}
                    className={[c.className, c.primary && 'dt-primary', c.key === 'acciones' && 'dt-actions'].filter(Boolean).join(' ') || undefined}>
                    {c.render ? c.render(f) : valor(c, f)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="dt-foot row g-2 align-items-center">
        <div className="col-md-4">
          <label className="d-flex align-items-center gap-2 mb-0">
            Mostrar
            <select className="form-select form-select-sm w-auto" value={largo} onChange={(e) => setLargo(+e.target.value)}>
              {LONGITUDES.map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
            filas
          </label>
        </div>
        <div className="col-md-4 text-md-center">
          {total === 0 ? 'Sin registros' : `Mostrando ${p * largo + 1}–${Math.min(total, (p + 1) * largo)} de ${total} registros`}
          {termino && total !== rows.length && ` (filtrado de ${rows.length})`}
        </div>
        <div className="col-md-4">
          <Paginacion pagina={p} paginas={paginas} onChange={setPagina} />
        </div>
      </div>
    </>
  )
}

function Paginacion({ pagina, paginas, onChange }) {
  // Números visibles: primera, última y vecinas de la actual
  const nums = []
  for (let i = 0; i < paginas; i++) {
    if (i === 0 || i === paginas - 1 || Math.abs(i - pagina) <= 1) nums.push(i)
    else if (nums[nums.length - 1] !== '…') nums.push('…')
  }
  const Item = ({ i, label, disabled, active }) => (
    <li className={`page-item ${disabled ? 'disabled' : ''} ${active ? 'active' : ''}`}>
      <button type="button" className="page-link" onClick={() => onChange(i)} disabled={disabled}>{label}</button>
    </li>
  )
  return (
    <ul className="pagination pagination-sm">
      <Item i={pagina - 1} label="Anterior" disabled={pagina === 0} />
      {nums.map((n, k) =>
        n === '…'
          ? <li key={`e${k}`} className="page-item disabled"><span className="page-link">…</span></li>
          : <Item key={n} i={n} label={n + 1} active={n === pagina} />,
      )}
      <Item i={pagina + 1} label="Siguiente" disabled={pagina >= paginas - 1} />
    </ul>
  )
}
