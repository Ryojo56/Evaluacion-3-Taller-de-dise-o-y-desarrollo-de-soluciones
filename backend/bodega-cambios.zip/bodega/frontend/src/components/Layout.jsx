import { useEffect, useRef, useState } from 'react'
import { Link, Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import Icon from './Icon'

/*
  Menú lateral agrupado en secciones genéricas. Cada entrada:
    { label, icon, to }                       enlace directo
    { label, icon, items: [{ label, to, match? }] }   grupo desplegable
  "match" son rutas adicionales que marcan activo el enlace (p. ej. /items/12 → Catálogo).
*/
function menuPara(rol) {
  const gestor = rol === 'admin' || rol === 'bodeguero'
  if (!gestor) {
    return [
      { label: 'Inicio', icon: 'home', to: '/' },
      { label: 'Inventario', icon: 'box', items: [{ label: 'Catálogo', to: '/catalogo', match: ['/solicitar'] }] },
      { label: 'Préstamos', icon: 'swap', items: [{ label: 'Mis solicitudes', to: '/mis-prestamos', match: ['/devolver'] }] },
    ]
  }
  const menu = [
    { label: 'Inicio', icon: 'home', to: '/' },
    {
      label: 'Inventario', icon: 'box', items: [
        { label: 'Catálogo y stock', to: '/catalogo-stock', match: ['/items'] },
        { label: 'Bodegas', to: '/bodegas' },
        { label: 'Categorías', to: '/categorias' },
      ],
    },
    {
      label: 'Préstamos', icon: 'swap', items: [
        { label: 'Solicitudes', to: '/solicitudes' },
        { label: 'Historial', to: '/historial' },
      ],
    },
    {
      label: 'Reportes', icon: 'chart', items: [
        { label: 'Inventario', to: '/reportes/inventario' },
        { label: 'Movimientos', to: '/reportes/movimientos' },
        { label: 'Préstamos', to: '/reportes/prestamos' },
      ],
    },
  ]
  if (rol === 'admin') {
    menu.push({ label: 'Administración', icon: 'users', items: [{ label: 'Usuarios', to: '/usuarios', match: ['/usuarios/nuevo'] }] })
  }
  return menu
}

const activo = (pathname, to, match = []) =>
  to === '/' ? pathname === '/' : [to, ...match].some((r) => pathname === r || pathname.startsWith(r + '/'))

const grupoActivo = (pathname, g) => g.items?.some((i) => activo(pathname, i.to, i.match))

function leerCompacto() {
  try { return localStorage.getItem('bodega.sidebar') === 'compacto' } catch { return false }
}

export default function Layout() {
  const { user, logout } = useAuth()
  const { pathname } = useLocation()
  const menu = menuPara(user.rol)
  const [abierto, setAbierto] = useState(false)       // drawer en móvil
  const [compacto, setCompacto] = useState(leerCompacto) // solo íconos en escritorio
  const [expandidos, setExpandidos] = useState(() =>
    Object.fromEntries(menu.filter((g) => g.items).map((g) => [g.label, true])),
  )
  const [menuCuenta, setMenuCuenta] = useState(false)
  const cuentaRef = useRef(null)

  // Al navegar: cierra el drawer y abre el grupo de la página actual
  useEffect(() => {
    setAbierto(false)
    setMenuCuenta(false)
    const g = menu.find((x) => grupoActivo(pathname, x))
    if (g) setExpandidos((e) => ({ ...e, [g.label]: true }))
  }, [pathname]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    try { localStorage.setItem('bodega.sidebar', compacto ? 'compacto' : 'normal') } catch { /* sin almacenamiento */ }
  }, [compacto])

  useEffect(() => {
    const esc = (e) => e.key === 'Escape' && (setAbierto(false), setMenuCuenta(false))
    const fuera = (e) => cuentaRef.current && !cuentaRef.current.contains(e.target) && setMenuCuenta(false)
    document.addEventListener('keydown', esc)
    document.addEventListener('mousedown', fuera)
    return () => { document.removeEventListener('keydown', esc); document.removeEventListener('mousedown', fuera) }
  }, [])

  // Evita que el fondo se desplace con el drawer abierto
  useEffect(() => {
    document.body.classList.toggle('drawer-abierto', abierto)
  }, [abierto])

  return (
    <div className={`app ${compacto ? 'sb-compacto' : ''}`}>
      {/* Barra superior (solo tablet / móvil) */}
      <header className="topbar">
        <button type="button" className="btn btn-icon" onClick={() => setAbierto(true)} aria-label="Abrir menú"
          aria-expanded={abierto} aria-controls="menu-lateral">
          <Icon name="menu" size={22} />
        </button>
        <span className="fw-semibold">Bodega Central</span>
        <Link to="/perfil" className="avatar avatar-sm text-decoration-none" aria-label="Mi perfil">{user.iniciales}</Link>
      </header>

      {abierto && <div className="sb-backdrop" onClick={() => setAbierto(false)} aria-hidden="true" />}

      <aside id="menu-lateral" className={`sidebar ${abierto ? 'open' : ''}`} aria-label="Menú principal">
        <div className="sb-head d-flex align-items-center gap-3">
          <div className="logo flex-none"></div>
          <div className="sb-text flex-fill">
            <div className="fw-semibold">Bodega Central</div>
            <span className="badge badge-role">{user.rol}</span>
          </div>
          <button type="button" className="btn btn-icon text-white d-lg-none" onClick={() => setAbierto(false)} aria-label="Cerrar menú">
            <Icon name="close" />
          </button>
        </div>

        <nav className="sb-nav" aria-label="Secciones">
          {menu.map((g) =>
            g.to ? (
              <Link key={g.label} to={g.to} title={compacto ? g.label : undefined}
                className={`sb-link ${activo(pathname, g.to) ? 'active' : ''}`}
                aria-current={activo(pathname, g.to) ? 'page' : undefined}>
                <Icon name={g.icon} /> <span className="sb-text">{g.label}</span>
              </Link>
            ) : (
              <div key={g.label} className={`sb-group ${grupoActivo(pathname, g) ? 'has-active' : ''}`}>
                {compacto ? (
                  // En modo compacto el ícono lleva a la primera página del grupo
                  <Link to={g.items[0].to} title={g.label} className={`sb-link ${grupoActivo(pathname, g) ? 'active' : ''}`}>
                    <Icon name={g.icon} />
                  </Link>
                ) : (
                  <>
                    <button type="button" className="sb-link sb-group-btn"
                      aria-expanded={!!expandidos[g.label]}
                      onClick={() => setExpandidos((e) => ({ ...e, [g.label]: !e[g.label] }))}>
                      <Icon name={g.icon} /> <span className="sb-text flex-fill text-start">{g.label}</span>
                      <Icon name="chevron" size={14} className={`sb-chevron ${expandidos[g.label] ? 'rot' : ''}`} />
                    </button>
                    {expandidos[g.label] && (
                      <div className="sb-sub">
                        {g.items.map((i) => (
                          <Link key={i.to} to={i.to} className={`sb-sublink ${activo(pathname, i.to, i.match) ? 'active' : ''}`}
                            aria-current={activo(pathname, i.to, i.match) ? 'page' : undefined}>
                            {i.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            ),
          )}
        </nav>

        <div className="sb-foot position-relative" ref={cuentaRef}>
          <button type="button" className="sb-account" onClick={() => setMenuCuenta(!menuCuenta)}
            aria-expanded={menuCuenta} aria-haspopup="menu" title={compacto ? user.nombre_completo : undefined}>
            <span className="avatar flex-none">{user.iniciales}</span>
            <span className="sb-text text-start flex-fill lh-sm">
              <span className="d-block small fw-medium text-truncate">{user.nombre_completo}</span>
              <span className="d-block text-secondary text-truncate" style={{ fontSize: '.75rem' }}>{user.email}</span>
            </span>
          </button>
          {menuCuenta && (
            <div className="card account-menu p-1" role="menu">
              <Link to="/perfil" className="dropdown-item rounded-2 d-flex gap-2 align-items-center py-2" role="menuitem"><Icon name="user" size={16} /> Mi perfil</Link>
              <Link to="/cambiar-password" className="dropdown-item rounded-2 d-flex gap-2 align-items-center py-2" role="menuitem"><Icon name="key" size={16} /> Cambiar contraseña</Link>
              <button type="button" className="dropdown-item rounded-2 d-flex gap-2 align-items-center py-2 text-danger" role="menuitem" onClick={logout}>
                <Icon name="logout" size={16} /> Cerrar sesión
              </button>
            </div>
          )}
          <button type="button" className="btn btn-icon sb-collapse d-none d-lg-inline-flex" onClick={() => setCompacto(!compacto)}
            aria-label={compacto ? 'Expandir menú' : 'Contraer menú'} title={compacto ? 'Expandir menú' : 'Contraer menú'}>
            <Icon name={compacto ? 'expand' : 'collapse'} size={16} />
          </button>
        </div>
      </aside>

      <main className="main">
        <Outlet />
      </main>
    </div>
  )
}

/** Requiere sesión iniciada. Fuerza el cambio de contraseña temporal. */
export function RequireAuth({ children, permitirCambioPassword = false }) {
  const { user, cargando } = useAuth()
  const location = useLocation()
  if (cargando) return <div className="p-5 text-center text-secondary">Cargando…</div>
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />
  if (user.debe_cambiar_password && !permitirCambioPassword) return <Navigate to="/cambiar-password" replace />
  return children
}

/** Restringe un grupo de rutas a ciertos roles */
export function RequireRole({ roles }) {
  const { user } = useAuth()
  return roles.includes(user.rol) ? <Outlet /> : <Navigate to="/" replace />
}
