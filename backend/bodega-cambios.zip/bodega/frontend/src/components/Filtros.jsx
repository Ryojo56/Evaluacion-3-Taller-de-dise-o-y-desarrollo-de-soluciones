// Barra de filtros de reportes. El estado vive en la URL (?bodega=1&desde=...),
// así un reporte filtrado se puede recargar, compartir o guardar como marcador.
import { useSearchParams } from 'react-router-dom'
import Icon from './Icon'

const iso = (d) => d.toISOString().slice(0, 10)
export function rangoPreset(id) {
  const hoy = new Date()
  const hace = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return d }
  return {
    '7d': { desde: iso(hace(6)), hasta: iso(hoy) },
    '30d': { desde: iso(hace(29)), hasta: iso(hoy) },
    '90d': { desde: iso(hace(89)), hasta: iso(hoy) },
    mes: { desde: iso(new Date(hoy.getFullYear(), hoy.getMonth(), 1)), hasta: iso(hoy) },
    todo: { desde: '', hasta: '' },
  }[id]
}
const PRESETS = [['7d', '7 días'], ['30d', '30 días'], ['90d', '90 días'], ['mes', 'Este mes'], ['todo', 'Todo']]

/** Lee/escribe los filtros en la URL. `defaults` se usan cuando el parámetro no está. */
export function useFiltros(defaults = {}) {
  const [params, setParams] = useSearchParams()
  const valores = { ...defaults }
  params.forEach((v, k) => { valores[k] = v })
  function set(cambios) {
    const sig = { ...valores, ...cambios }
    const limpio = {}
    Object.entries(sig).forEach(([k, v]) => {
      // se guarda en la URL también el valor vacío cuando difiere del default (p. ej. "Todo" en fechas)
      if (v !== '' && v != null) limpio[k] = v
      else if (defaults[k]) limpio[k] = ''
    })
    setParams(limpio, { replace: true })
  }
  const limpiar = () => setParams({}, { replace: true })
  // Parámetros para la API (sin vacíos)
  const query = new URLSearchParams(Object.entries(valores).filter(([, v]) => v)).toString()
  return { valores, set, limpiar, query }
}

/**
 * campos: [{ key, label, tipo: 'select'|'fecha'|'buscar'|'check', opciones: [{id, nombre}], col }]
 */
export default function Filtros({ campos, filtros, conFechas = false, onExportar, totalFilas }) {
  const { valores, set, limpiar } = filtros
  const activos = campos.filter((c) => valores[c.key] && c.tipo !== 'buscar')
  const nombreDe = (c) => c.tipo === 'check' ? c.label : c.opciones?.find((o) => String(o.id) === String(valores[c.key]))?.nombre || valores[c.key]
  const presetActivo = conFechas && PRESETS.find(([id]) => {
    const r = rangoPreset(id)
    return r.desde === (valores.desde || '') && r.hasta === (valores.hasta || '')
  })?.[0]

  return (
    <div className="card filtros mb-3" role="search" aria-label="Filtros del reporte">
      {conFechas && (
        <div className="d-flex flex-wrap align-items-end gap-2 mb-2">
          <div>
            <span className="form-label d-block">Período</span>
            <div className="d-flex flex-wrap gap-1 filtro-rol" role="group" aria-label="Período rápido">
              {PRESETS.map(([id, l]) => (
                <button key={id} type="button" className={`btn btn-sm ${presetActivo === id ? 'btn-dark' : 'btn-light'}`}
                  aria-pressed={presetActivo === id} onClick={() => set(rangoPreset(id))}>{l}</button>
              ))}
            </div>
          </div>
          <div className="d-flex gap-2 flex-wrap">
            <div>
              <label className="form-label d-block" htmlFor="f_desde">Desde</label>
              <input id="f_desde" type="date" className="form-control form-control-sm" value={valores.desde || ''}
                max={valores.hasta || undefined} onChange={(e) => set({ desde: e.target.value })} />
            </div>
            <div>
              <label className="form-label d-block" htmlFor="f_hasta">Hasta</label>
              <input id="f_hasta" type="date" className="form-control form-control-sm" value={valores.hasta || ''}
                min={valores.desde || undefined} onChange={(e) => set({ hasta: e.target.value })} />
            </div>
          </div>
        </div>
      )}
      <div className="row g-2 align-items-end">
        {campos.map((c) => (
          <div key={c.key} className={c.col || 'col-6 col-md-4 col-xl'}>
            {c.tipo === 'check' ? (
              <div className="form-check form-switch mb-2">
                <input className="form-check-input" type="checkbox" role="switch" id={`f_${c.key}`}
                  checked={!!valores[c.key]} onChange={(e) => set({ [c.key]: e.target.checked ? '1' : '' })} />
                <label className="form-check-label small" htmlFor={`f_${c.key}`}>{c.label}</label>
              </div>
            ) : (
              <>
                <label className="form-label" htmlFor={`f_${c.key}`}>{c.label}</label>
                {c.tipo === 'buscar' ? (
                  <input id={`f_${c.key}`} type="search" className="form-control form-control-sm" placeholder={c.placeholder}
                    value={valores[c.key] || ''} onChange={(e) => set({ [c.key]: e.target.value })} />
                ) : (
                  <select id={`f_${c.key}`} className="form-select form-select-sm" value={valores[c.key] || ''}
                    onChange={(e) => set({ [c.key]: e.target.value })}>
                    <option value="">{c.todos || 'Todos'}</option>
                    {(c.opciones || []).map((o) => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                  </select>
                )}
              </>
            )}
          </div>
        ))}
      </div>
      <div className="d-flex flex-wrap align-items-center gap-2 mt-3">
        <span className="small text-secondary d-inline-flex align-items-center gap-1"><Icon name="filter" size={14} />
          {activos.length ? 'Filtros activos:' : 'Sin filtros adicionales'}
        </span>
        {activos.map((c) => (
          <span className="chip" key={c.key}>
            {c.tipo !== 'check' && <span className="opacity-75">{c.label}:</span>} {nombreDe(c)}
            <button type="button" aria-label={`Quitar filtro ${c.label}`} onClick={() => set({ [c.key]: '' })}>×</button>
          </span>
        ))}
        {(activos.length > 0 || valores.q) && (
          <button type="button" className="btn btn-link btn-sm p-0" onClick={limpiar}>Limpiar filtros</button>
        )}
        {onExportar && (
          <button type="button" className="btn btn-sm btn-outline-secondary ms-auto d-inline-flex align-items-center gap-1"
            onClick={onExportar} disabled={!totalFilas}>
            <Icon name="download" size={15} /> Exportar CSV{totalFilas ? ` (${totalFilas})` : ''}
          </button>
        )}
      </div>
    </div>
  )
}
