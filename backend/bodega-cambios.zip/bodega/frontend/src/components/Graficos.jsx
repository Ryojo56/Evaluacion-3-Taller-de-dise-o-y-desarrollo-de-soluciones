// Gráficos livianos en SVG/HTML (sin librerías). Paleta validada: azul #2a78d6, naranjo #eb6834.
import { useEffect, useRef, useState } from 'react'

export const SERIES = ['#2a78d6', '#eb6834']
const nf = new Intl.NumberFormat('es-CL')

function useAncho() {
  const ref = useRef(null)
  const [ancho, setAncho] = useState(600)
  useEffect(() => {
    if (!ref.current) return
    const ro = new ResizeObserver(([e]) => setAncho(Math.max(240, Math.floor(e.contentRect.width))))
    ro.observe(ref.current)
    return () => ro.disconnect()
  }, [])
  return [ref, ancho]
}

/** Tarjeta contenedora de un gráfico */
export function Panel({ titulo, subtitulo, children, className = '' }) {
  return (
    <div className={`card p-3 p-md-4 h-100 ${className}`}>
      <h2 className="h6 fw-bold mb-0">{titulo}</h2>
      {subtitulo && <div className="small text-secondary mb-2">{subtitulo}</div>}
      <div className="mt-2">{children}</div>
    </div>
  )
}

export function SinDatos({ texto = 'Sin datos para los filtros seleccionados.' }) {
  return <div className="text-secondary small text-center py-4">{texto}</div>
}

/** Barras horizontales de una serie, con el valor rotulado al final de cada barra */
export function BarrasH({ datos, unidad = '', color = SERIES[0], max: maxFijo }) {
  if (!datos?.length || datos.every((d) => !d.valor)) return <SinDatos />
  const max = maxFijo || Math.max(...datos.map((d) => d.valor), 1)
  return (
    <ul className="list-unstyled mb-0 barras-h">
      {datos.map((d) => (
        <li key={d.nombre} className="mb-2" title={`${d.nombre}: ${nf.format(d.valor)} ${unidad}`}>
          <div className="d-flex justify-content-between small gap-2">
            <span className="text-truncate">{d.nombre}</span>
            <span className="fw-semibold flex-none" style={{ fontVariantNumeric: 'tabular-nums' }}>{nf.format(d.valor)}{unidad && ` ${unidad}`}</span>
          </div>
          <div className="barra-track">
            <span style={{ width: `${d.valor ? Math.max(1.5, (100 * d.valor) / max) : 0}%`, background: color }} />
          </div>
        </li>
      ))}
    </ul>
  )
}

/**
 * Columnas agrupadas en el tiempo (1–2 series), con eje Y, leyenda y tooltip al pasar el cursor.
 *   datos: [{ etiqueta, etiquetaLarga, [serie.key]: número }]
 *   series: [{ key, nombre }]
 */
export function Columnas({ datos, series, alto = 230 }) {
  const [ref, ancho] = useAncho()
  const [hover, setHover] = useState(null)
  if (!datos?.length || datos.every((d) => series.every((s) => !d[s.key]))) {
    return <div ref={ref}><SinDatos /></div>
  }

  const m = { top: 10, right: 8, bottom: 26, left: 40 }
  const w = ancho - m.left - m.right
  const h = alto - m.top - m.bottom
  const maxBruto = Math.max(...datos.flatMap((d) => series.map((s) => d[s.key] || 0)), 1)
  const paso = Math.pow(10, Math.floor(Math.log10(maxBruto)))
  const max = Math.ceil(maxBruto / paso) * paso
  const ticks = [0, max / 2, max]
  const banda = w / datos.length
  const gap = 2
  const anchoBarra = Math.max(2, Math.min(28, (banda * 0.75 - gap * (series.length - 1)) / series.length))
  const grupo = anchoBarra * series.length + gap * (series.length - 1)
  const y = (v) => h - (h * v) / max
  const cadaN = Math.ceil(datos.length / Math.max(1, Math.floor(w / 56))) // etiquetas X sin solaparse

  // Barra con extremo superior redondeado (4px) anclada a la base
  const barra = (x, v) => {
    const top = y(v)
    const alturaB = h - top
    if (alturaB <= 0) return null
    const r = Math.min(4, anchoBarra / 2, alturaB)
    return `M${x},${h} V${top + r} Q${x},${top} ${x + r},${top} H${x + anchoBarra - r} Q${x + anchoBarra},${top} ${x + anchoBarra},${top + r} V${h} Z`
  }

  const d = hover != null ? datos[hover] : null
  return (
    <div ref={ref} className="position-relative">
      {series.length > 1 && (
        <div className="d-flex gap-3 small mb-2" aria-hidden="true">
          {series.map((s, i) => (
            <span key={s.key} className="d-inline-flex align-items-center gap-1">
              <span style={{ width: 10, height: 10, borderRadius: 3, background: SERIES[i], display: 'inline-block' }} /> {s.nombre}
            </span>
          ))}
        </div>
      )}
      <svg width={ancho} height={alto} role="img"
        aria-label={`Gráfico de columnas: ${series.map((s) => s.nombre).join(' y ')} por período`}
        onMouseLeave={() => setHover(null)}>
        <g transform={`translate(${m.left},${m.top})`}>
          {ticks.map((t) => (
            <g key={t}>
              <line x1={0} x2={w} y1={y(t)} y2={y(t)} stroke="#e5e7eb" strokeDasharray={t ? '3 3' : undefined} />
              <text x={-6} y={y(t)} dy="0.32em" textAnchor="end" fontSize="11" fill="#6b7280">{nf.format(t)}</text>
            </g>
          ))}
          {datos.map((p, i) => {
            const x0 = i * banda + (banda - grupo) / 2
            return (
              <g key={p.etiquetaLarga || i}>
                {hover === i && <rect x={i * banda} y={0} width={banda} height={h} fill="#f3f4f6" />}
                {series.map((s, k) => {
                  const path = barra(x0 + k * (anchoBarra + gap), p[s.key] || 0)
                  return path && <path key={s.key} d={path} fill={SERIES[k]} />
                })}
                {i % cadaN === 0 && (
                  <text x={i * banda + banda / 2} y={h + 17} textAnchor="middle" fontSize="11" fill="#6b7280">{p.etiqueta}</text>
                )}
                {/* zona de hover más grande que la barra */}
                <rect x={i * banda} y={0} width={banda} height={h} fill="transparent" onMouseEnter={() => setHover(i)}
                  onTouchStart={() => setHover(i)} />
              </g>
            )
          })}
        </g>
      </svg>
      {d && (
        <div className="chart-tip" style={{
          left: Math.min(Math.max(m.left + hover * banda + banda / 2, 70), ancho - 70),
          top: 6 + (series.length > 1 ? 26 : 0),
        }}>
          <div className="fw-semibold mb-1">{d.etiquetaLarga || d.etiqueta}</div>
          {series.map((s, i) => (
            <div key={s.key} className="d-flex justify-content-between gap-3">
              <span><span className="tip-dot" style={{ background: SERIES[i] }} />{s.nombre}</span>
              <strong>{nf.format(d[s.key] || 0)}</strong>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
