"""
Reportes con filtros. Cada endpoint aplica TODOS los filtros recibidos a la vez al
resumen (KPIs), a las series de los gráficos y a las filas de la tabla, para que lo
que se ve, lo que se grafica y lo que se exporta sea siempre lo mismo.

    GET /api/reportes/opciones/       valores para llenar los filtros
    GET /api/reportes/inventario/     ?bodega ?categoria ?tipo ?estado ?q
    GET /api/reportes/movimientos/    ?desde ?hasta ?bodega ?categoria ?tipo ?item ?usuario ?q
    GET /api/reportes/prestamos/      ?desde ?hasta ?trabajador ?estado ?categoria ?bodega ?tipo ?sobre_stock ?q
"""
from collections import Counter, defaultdict
from datetime import date, datetime, time, timedelta

from django.db.models import Prefetch, Q
from django.utils import timezone
from rest_framework.decorators import api_view, permission_classes
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response

from inventario.models import Bodega, Categoria, Item, MovimientoStock, Stock
from inventario.serializers import MovimientoSerializer
from prestamos.models import Solicitud
from prestamos.serializers import SolicitudSerializer
from usuarios.models import Usuario
from usuarios.permissions import EsGestor

LIMITE_FILAS = 2000


# --------------------------------------------------------------------------- utilidades
def _fecha(texto, nombre):
    try:
        return date.fromisoformat(texto)
    except (TypeError, ValueError):
        raise ValidationError({nombre: f"Fecha inválida: {texto} (usa AAAA-MM-DD)."})


def _rango(params, campo):
    """Filtro de fechas por rango de fecha/hora (seguro en MySQL sin tablas de zona horaria)."""
    filtro = {}
    desde = _fecha(params["desde"], "desde") if params.get("desde") else None
    hasta = _fecha(params["hasta"], "hasta") if params.get("hasta") else None
    if desde and hasta and desde > hasta:
        raise ValidationError({"hasta": "La fecha 'hasta' debe ser posterior a 'desde'."})
    if desde:
        filtro[f"{campo}__gte"] = timezone.make_aware(datetime.combine(desde, time.min))
    if hasta:
        filtro[f"{campo}__lt"] = timezone.make_aware(datetime.combine(hasta + timedelta(days=1), time.min))
    return filtro, desde, hasta


def _int(params, nombre):
    v = params.get(nombre)
    if not v:
        return None
    try:
        return int(v)
    except ValueError:
        raise ValidationError({nombre: "Valor inválido."})


# --------------------------------------------------------------------------- opciones
@api_view(["GET"])
@permission_classes([EsGestor])
def opciones(request):
    return Response({
        "bodegas": [{"id": b.id, "nombre": b.nombre} for b in Bodega.objects.order_by("nombre")],
        "categorias": [{"id": c.id, "nombre": c.nombre} for c in Categoria.objects.order_by("nombre")],
        "items": [{"id": i.id, "nombre": f"{i.sku} · {i.nombre}"} for i in Item.objects.order_by("nombre")],
        "trabajadores": [
            {"id": u.id, "nombre": u.nombre_completo}
            for u in Usuario.objects.filter(rol=Usuario.Rol.TRABAJADOR).order_by("nombre", "apellido")
        ],
        "usuarios": [{"id": u.id, "nombre": u.nombre_completo} for u in Usuario.objects.order_by("nombre", "apellido")],
        "tipos_item": [{"id": v, "nombre": l} for v, l in Item.Tipo.choices],
        "estados_stock": [{"id": v, "nombre": l} for v, l in Item.Estado.choices],
        "tipos_movimiento": [{"id": v, "nombre": l} for v, l in MovimientoStock.Tipo.choices],
        "estados_prestamo": [{"id": k, "nombre": v} for k, v in ESTADOS_REPORTE.items()],
    })


# --------------------------------------------------------------------------- inventario
@api_view(["GET"])
@permission_classes([EsGestor])
def inventario(request):
    p = request.query_params
    bodega_id = _int(p, "bodega")
    items = (
        Item.objects.filter(activo=True)
        .select_related("categoria")
        .prefetch_related(Prefetch("stocks", queryset=Stock.objects.select_related("bodega")))
        .order_by("nombre")
    )
    if p.get("categoria"):
        items = items.filter(categoria_id=_int(p, "categoria"))
    if p.get("tipo"):
        items = items.filter(tipo=p["tipo"])
    if p.get("q"):
        items = items.filter(Q(nombre__icontains=p["q"]) | Q(sku__icontains=p["q"]))

    bodegas = list(Bodega.objects.order_by("nombre"))
    if bodega_id:
        bodegas = [b for b in bodegas if b.id == bodega_id]

    filas = []
    for item in items:
        por_bodega = {s.bodega_id: s.cantidad for s in item.stocks.all()}
        total = sum(por_bodega.values())
        estado = Item.calcular_estado(total, item.stock_minimo, item.stock_critico)
        if p.get("estado") and estado != p["estado"]:
            continue
        stock = por_bodega.get(bodega_id, 0) if bodega_id else total
        if bodega_id and stock == 0 and estado != Item.Estado.SIN_STOCK:
            continue  # al filtrar por bodega, solo lo que hay en ella
        filas.append({
            "id": item.id, "sku": item.sku, "nombre": item.nombre,
            "categoria": item.categoria.nombre, "tipo": item.get_tipo_display(),
            "por_bodega": {str(b.id): por_bodega.get(b.id, 0) for b in bodegas},
            "stock": stock, "stock_total": total, "stock_minimo": item.stock_minimo,
            "estado": estado, "estado_display": Item.Estado(estado).label,
        })

    por_categoria = Counter()
    for f in filas:
        por_categoria[f["categoria"]] += f["stock"]
    ocupado_total = {b.id: b.unidades_ocupadas for b in bodegas}
    estados = Counter(f["estado"] for f in filas)

    return Response({
        "resumen": {
            "items": len(filas),
            "unidades": sum(f["stock"] for f in filas),
            "criticos": estados[Item.Estado.CRITICO] + estados[Item.Estado.SIN_STOCK],
            "stock_bajo": estados[Item.Estado.BAJO],
            "capacidad": sum(b.capacidad for b in bodegas),
            "ocupado": sum(ocupado_total.values()),
        },
        "bodegas": [
            {
                "id": b.id, "nombre": b.nombre, "abreviatura": b.abreviatura, "capacidad": b.capacidad,
                "unidades_filtradas": sum(f["por_bodega"].get(str(b.id), 0) for f in filas),
                "ocupado": ocupado_total[b.id],
            }
            for b in bodegas
        ],
        "por_categoria": [{"nombre": k, "valor": v} for k, v in por_categoria.most_common()],
        "por_estado": [{"id": e.value, "nombre": e.label, "valor": estados[e.value]} for e in Item.Estado],
        "filas": filas,
    })


# --------------------------------------------------------------------------- movimientos
@api_view(["GET"])
@permission_classes([EsGestor])
def movimientos(request):
    p = request.query_params
    filtro, desde, hasta = _rango(p, "fecha")
    qs = MovimientoStock.objects.filter(**filtro).select_related("item", "bodega", "usuario").order_by("-fecha")
    for campo, param in (("bodega_id", "bodega"), ("item_id", "item"), ("usuario_id", "usuario"),
                         ("item__categoria_id", "categoria")):
        if p.get(param):
            qs = qs.filter(**{campo: _int(p, param)})
    if p.get("tipo"):
        qs = qs.filter(tipo=p["tipo"])
    if p.get("q"):
        qs = qs.filter(Q(item__nombre__icontains=p["q"]) | Q(item__sku__icontains=p["q"]) | Q(detalle__icontains=p["q"]))

    movs = list(qs[:LIMITE_FILAS])
    T = MovimientoStock.Tipo
    suma = defaultdict(int)
    por_dia = defaultdict(lambda: {"ingresos": 0, "salidas": 0})
    salidas_item = Counter()
    for m in movs:
        suma[m.tipo] += m.cantidad
        dia = timezone.localtime(m.fecha).date()
        if m.cantidad > 0:
            por_dia[dia]["ingresos"] += m.cantidad
        else:
            por_dia[dia]["salidas"] += -m.cantidad
        if m.tipo == T.SALIDA:
            salidas_item[(m.item.sku, m.item.nombre)] += -m.cantidad

    # Serie diaria continua (incluye días sin movimientos) dentro del rango visible
    serie = []
    if movs:
        inicio = desde or min(por_dia)
        fin = hasta or max(por_dia)
        if (fin - inicio).days <= 120:
            d = inicio
            while d <= fin:
                serie.append({"fecha": d.isoformat(), **por_dia.get(d, {"ingresos": 0, "salidas": 0})})
                d += timedelta(days=1)
        else:  # rangos largos: agrupa por mes
            meses = defaultdict(lambda: {"ingresos": 0, "salidas": 0})
            for d, v in por_dia.items():
                k = d.replace(day=1)
                meses[k]["ingresos"] += v["ingresos"]
                meses[k]["salidas"] += v["salidas"]
            serie = [{"fecha": k.isoformat(), "mes": True, **v} for k, v in sorted(meses.items())]

    return Response({
        "resumen": {
            "movimientos": len(movs),
            "entradas": suma[T.ENTRADA],
            "salidas": -suma[T.SALIDA],
            "devoluciones": suma[T.DEVOLUCION],
            "ajustes": suma[T.AJUSTE],
            "truncado": qs.count() > LIMITE_FILAS,
        },
        "serie": serie,
        "top_salidas": [{"nombre": f"{sku} · {n}", "valor": v} for (sku, n), v in salidas_item.most_common(8)],
        "filas": MovimientoSerializer(movs, many=True).data,
    })


# --------------------------------------------------------------------------- préstamos
ESTADOS_REPORTE = {
    "pendiente": "Pendiente",
    "activo": "En préstamo",
    "vencido": "Vencido",
    "devuelto": "Devuelto",
    "consumido": "Entregado (consumible)",
    "rechazado": "Rechazado",
    "cancelado": "Cancelado",
}


def estado_reporte(s, ahora):
    E = Solicitud.Estado
    if s.estado == E.DESPACHADA:
        if not s.item.requiere_devolucion:
            return "consumido"
        return "vencido" if s.fecha_limite and s.fecha_limite < ahora else "activo"
    return {E.PENDIENTE: "pendiente", E.DEVUELTA: "devuelto", E.RECHAZADA: "rechazado",
            E.CANCELADA: "cancelado"}[s.estado]


@api_view(["GET"])
@permission_classes([EsGestor])
def prestamos(request):
    p = request.query_params
    filtro, _, _ = _rango(p, "fecha_solicitud")
    qs = (
        Solicitud.objects.filter(**filtro)
        .select_related("trabajador", "item", "item__categoria", "bodega", "responsable")
        .order_by("-fecha_solicitud")
    )
    for campo, param in (("trabajador_id", "trabajador"), ("item__categoria_id", "categoria"),
                         ("bodega_id", "bodega")):
        if p.get(param):
            qs = qs.filter(**{campo: _int(p, param)})
    if p.get("tipo"):
        qs = qs.filter(item__tipo=p["tipo"])
    if p.get("sobre_stock") == "1":
        qs = qs.filter(excede_stock=True)
    if p.get("q"):
        qs = qs.filter(Q(item__nombre__icontains=p["q"]) | Q(item__sku__icontains=p["q"])
                       | Q(trabajador__nombre__icontains=p["q"]) | Q(trabajador__apellido__icontains=p["q"]))

    ahora = timezone.now()
    sols = []
    for s in qs[:LIMITE_FILAS]:
        s.estado_reporte = estado_reporte(s, ahora)
        if p.get("estado") and s.estado_reporte != p["estado"]:
            continue
        sols.append(s)

    estados = Counter(s.estado_reporte for s in sols)
    devueltas = [s for s in sols if s.estado_reporte == "devuelto"]
    condicion = Counter(s.estado_devolucion for s in devueltas)
    a_tiempo = sum(1 for s in devueltas if s.fecha_limite and s.fecha_devolucion <= s.fecha_limite)
    por_trabajador = Counter(s.trabajador.nombre_completo for s in sols)
    por_item = Counter(f"{s.item.sku} · {s.item.nombre}" for s in sols)

    filas = SolicitudSerializer(sols, many=True).data
    for f, s in zip(filas, sols):
        f["estado_reporte"] = s.estado_reporte
        f["estado_reporte_display"] = ESTADOS_REPORTE[s.estado_reporte]
        f["categoria"] = s.item.categoria.nombre

    return Response({
        "resumen": {
            "solicitudes": len(sols),
            "unidades": sum(s.cantidad for s in sols),
            "pendientes": estados["pendiente"],
            "activos": estados["activo"],
            "vencidos": estados["vencido"],
            "devueltos": len(devueltas),
            "consumidos": estados["consumido"],
            "rechazados": estados["rechazado"] + estados["cancelado"],
            "sobre_stock": sum(1 for s in sols if s.excede_stock),
            "pct_a_tiempo": round(100 * a_tiempo / len(devueltas)) if devueltas else None,
            "pct_buen_estado": round(100 * condicion["bueno"] / len(devueltas)) if devueltas else None,
        },
        "por_estado": [{"id": k, "nombre": v, "valor": estados[k]} for k, v in ESTADOS_REPORTE.items()],
        "condicion_devolucion": [
            {"id": v, "nombre": l, "valor": condicion[v]} for v, l in Solicitud.EstadoDevolucion.choices
        ],
        "por_trabajador": [{"nombre": k, "valor": v} for k, v in por_trabajador.most_common(8)],
        "por_item": [{"nombre": k, "valor": v} for k, v in por_item.most_common(8)],
        "filas": filas,
    })
