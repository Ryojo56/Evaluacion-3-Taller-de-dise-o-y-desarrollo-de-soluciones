from django.urls import path

from . import views

urlpatterns = [
    path("opciones/", views.opciones, name="reporte_opciones"),
    path("inventario/", views.inventario, name="reporte_inventario"),
    path("movimientos/", views.movimientos, name="reporte_movimientos"),
    path("prestamos/", views.prestamos, name="reporte_prestamos"),
]
