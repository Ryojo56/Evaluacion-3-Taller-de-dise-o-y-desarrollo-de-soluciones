from django.db.models import Count, Q
from rest_framework import generics, status, viewsets
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView

from .models import Usuario, generar_password_temporal
from .permissions import EsAdmin
from .serializers import (
    CambiarPasswordSerializer,
    CrearUsuarioSerializer,
    LoginSerializer,
    PerfilSerializer,
    UsuarioSerializer,
)


class LoginView(TokenObtainPairView):
    permission_classes = [AllowAny]
    serializer_class = LoginSerializer


class MeView(generics.RetrieveUpdateAPIView):
    """GET: datos de la sesión. PATCH/PUT: actualizar 'Mi perfil'."""

    def get_object(self):
        return self.request.user

    def get_serializer_class(self):
        return UsuarioSerializer if self.request.method == "GET" else PerfilSerializer

    def update(self, request, *args, **kwargs):
        kwargs["partial"] = True
        super().update(request, *args, **kwargs)
        return Response(UsuarioSerializer(request.user).data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def cambiar_password(request):
    ser = CambiarPasswordSerializer(data=request.data, context={"request": request})
    ser.is_valid(raise_exception=True)
    user = request.user
    user.set_password(ser.validated_data["password_nueva"])
    user.debe_cambiar_password = False
    user.save(update_fields=["password", "debe_cambiar_password"])
    return Response({"detail": "Contraseña actualizada.", "usuario": UsuarioSerializer(user).data})


class UsuarioViewSet(viewsets.ModelViewSet):
    """Gestión de usuarios (solo administrador)."""

    permission_classes = [EsAdmin]

    def get_queryset(self):
        return Usuario.objects.annotate(
            solicitudes_total=Count("solicitudes", distinct=True),
            prestamos_activos=Count(
                "solicitudes", distinct=True,
                filter=Q(solicitudes__estado="despachada", solicitudes__item__tipo="herramienta"),
            ),
        ).order_by("nombre", "apellido")
    http_method_names = ["get", "post", "patch", "delete"]

    def get_serializer_class(self):
        return CrearUsuarioSerializer if self.action == "create" else UsuarioSerializer

    def create(self, request, *args, **kwargs):
        ser = self.get_serializer(data=request.data)
        ser.is_valid(raise_exception=True)
        user = ser.save()
        data = UsuarioSerializer(user).data
        data["password_temporal"] = user._password_temporal
        return Response(data, status=status.HTTP_201_CREATED)

    def perform_update(self, serializer):
        if serializer.instance == self.request.user and serializer.validated_data.get("rol", "admin") != "admin":
            from rest_framework.exceptions import ValidationError
            raise ValidationError({"rol": "No puedes quitarte el rol de administrador a ti mismo."})
        serializer.save()

    def destroy(self, request, *args, **kwargs):
        # No se borran usuarios (tienen historial): se desactivan.
        user = self.get_object()
        if user == request.user:
            return Response({"detail": "No puedes desactivar tu propia cuenta."}, status=400)
        if user.solicitudes.filter(estado="despachada", item__tipo="herramienta").exists():
            return Response(
                {"detail": f"{user.nombre_completo} tiene herramientas prestadas sin devolver. Regístralas antes de desactivarlo."},
                status=400,
            )
        user.is_active = False
        user.save(update_fields=["is_active"])
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=True, methods=["post"], url_path="reset-password")
    def reset_password(self, request, pk=None):
        user = self.get_object()
        password = generar_password_temporal()
        user.set_password(password)
        user.debe_cambiar_password = True
        user.is_active = True
        user.save()
        return Response({"password_temporal": password})

    @action(detail=False, methods=["get"], url_path="generar-password")
    def generar_password(self, request):
        return Response({"password": generar_password_temporal()})

    @action(detail=False, methods=["get"])
    def roles(self, request):
        return Response([{"value": v, "label": l} for v, l in Usuario.Rol.choices])
