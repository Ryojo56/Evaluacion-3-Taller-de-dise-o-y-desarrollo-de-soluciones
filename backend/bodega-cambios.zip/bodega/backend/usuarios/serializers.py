from django.contrib.auth import password_validation
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from .models import Usuario, generar_password_temporal


class UsuarioSerializer(serializers.ModelSerializer):
    nombre_completo = serializers.CharField(read_only=True)
    iniciales = serializers.CharField(read_only=True)
    rol_display = serializers.CharField(source="get_rol_display", read_only=True)
    solicitudes_total = serializers.IntegerField(read_only=True, default=None)
    prestamos_activos = serializers.IntegerField(read_only=True, default=None)

    class Meta:
        model = Usuario
        fields = [
            "id", "email", "nombre", "apellido", "nombre_completo", "iniciales",
            "telefono", "rol", "rol_display", "is_active", "debe_cambiar_password", "date_joined",
            "last_login", "solicitudes_total", "prestamos_activos",
        ]
        read_only_fields = ["debe_cambiar_password", "date_joined", "last_login"]

    def validate_email(self, value):
        value = value.lower()
        qs = Usuario.objects.filter(email__iexact=value)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError("Ya existe un usuario con este correo.")
        return value


class CrearUsuarioSerializer(UsuarioSerializer):
    """Pantalla 'Crear cuenta de usuario': el admin asigna una contraseña temporal."""

    password_temporal = serializers.CharField(write_only=True, required=False, allow_blank=True)

    class Meta(UsuarioSerializer.Meta):
        fields = UsuarioSerializer.Meta.fields + ["password_temporal"]
        extra_kwargs = {"rol": {"required": True}}

    def validate_password_temporal(self, value):
        if value:
            password_validation.validate_password(value)
        return value

    def create(self, validated_data):
        password = validated_data.pop("password_temporal", "") or generar_password_temporal()
        user = Usuario.objects.create_user(password=password, debe_cambiar_password=True, **validated_data)
        user._password_temporal = password
        return user


class PerfilSerializer(serializers.ModelSerializer):
    """Pantalla 'Mi perfil': exige confirmar la contraseña actual."""

    password_actual = serializers.CharField(write_only=True)

    class Meta:
        model = Usuario
        fields = ["nombre", "apellido", "telefono", "email", "password_actual"]

    def validate_email(self, value):
        value = value.lower()
        if Usuario.objects.filter(email__iexact=value).exclude(pk=self.instance.pk).exists():
            raise serializers.ValidationError("Ya existe un usuario con este correo.")
        return value

    def validate_password_actual(self, value):
        if not self.instance.check_password(value):
            raise serializers.ValidationError("La contraseña actual no es correcta.")
        return value

    def update(self, instance, validated_data):
        validated_data.pop("password_actual", None)
        return super().update(instance, validated_data)


class CambiarPasswordSerializer(serializers.Serializer):
    password_actual = serializers.CharField()
    password_nueva = serializers.CharField()
    password_confirmacion = serializers.CharField()

    def validate_password_actual(self, value):
        if not self.context["request"].user.check_password(value):
            raise serializers.ValidationError("La contraseña actual no es correcta.")
        return value

    def validate(self, attrs):
        if attrs["password_nueva"] != attrs["password_confirmacion"]:
            raise serializers.ValidationError({"password_confirmacion": "Las contraseñas no coinciden."})
        if attrs["password_nueva"] == attrs["password_actual"]:
            raise serializers.ValidationError({"password_nueva": "La nueva contraseña debe ser distinta a la actual."})
        password_validation.validate_password(attrs["password_nueva"], self.context["request"].user)
        return attrs


class LoginSerializer(TokenObtainPairSerializer):
    """Login con correo + contraseña. Devuelve tokens y los datos del usuario."""

    default_error_messages = {"no_active_account": "Correo o contraseña incorrectos."}

    def validate(self, attrs):
        attrs[self.username_field] = attrs.get(self.username_field, "").lower()
        data = super().validate(attrs)
        data["usuario"] = UsuarioSerializer(self.user).data
        return data
