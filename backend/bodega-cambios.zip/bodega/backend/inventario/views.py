from datetime import date, datetime, time, timedelta

from django.db.models import Count, Prefetch, Q, Sum
from django.utils import timezone
from rest_framework.exceptions import ValidationError
from django.db.models.deletion import ProtectedError
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from usuarios.models import Usuario
from usuarios.permissions import EsGestor, LecturaOGestor, es_gestor

from .models import Bodega, Categoria, Item, MovimientoStock, Stock
from .serializers import BodegaSerializer, CategoriaSerializer, ItemSerializer, MovimientoSerializer


class ProtegidoMixin:
    """Devuelve un 400 legible cuando un registro tiene datos asociados."""

    mensaje_protegido = "No se puede eliminar porque tiene registros asociados."

    def destroy(self, request, *args, **kwargs):
        try:
            return super().destroy(request, *args, **kwargs)
        except ProtectedError:
            return Response({"detail": self.mensaje_protegido}, status=status.HTTP_400_BAD_REQUEST)


class BodegaViewSet(ProtegidoMixin, viewsets.ModelViewSet):
    serializer_class = BodegaSerializer
    permission_classes = [LecturaOGestor]
    mensaje_protegido = "No se puede eliminar la bodega porque tiene stock o movimientos registrados."

    def get_queryset(self):
        return (
            Bodega.objects.select_related("responsable")
            .annotate(
                total_unidades=Sum("stocks__cantidad"),
                items_distintos=Count("stocks", filter=Q(stocks__cantidad__gt=0)),
            )
            .order_by("nombre")
        )

    @action(detail=False, methods=["get"])
    def responsables(self, request):
        """Usuarios que pueden quedar a cargo de una bodega."""
        qs = Usuario.objects.filter(is_active=True, rol__in=["admin", "bodeguero"]).order_by("nombre")
        return Response([{"id": u.id, "nombre": u.nombre_completo, "rol": u.rol} for u in qs])

    def destroy(self, request, *args, **kwargs):
        bodega = self.get_object()
        if bodega.stocks.filter(cantidad__gt=0).exists():
            return Response(
                {"detail": "La bodega aún tiene stock. Traslada o ajusta su stock antes de eliminarla."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        bodega.stocks.all().delete()
        return super().destroy(request, *args, **kwargs)


class CategoriaViewSet(ProtegidoMixin, viewsets.ModelViewSet):
    serializer_class = CategoriaSerializer
    permission_classes = [LecturaOGestor]
    mensaje_protegido = "No se puede eliminar la categoría porque tiene productos asociados."

    def get_queryset(self):
        return Categoria.objects.annotate(productos=Count("items", filter=Q(items__activo=True))).order_by("nombre")


class ItemViewSet(viewsets.ModelViewSet):
    """Catálogo. Filtros: ?search=texto  ?categoria=id  ?estado=critico  ?tipo=herramienta"""

    serializer_class = ItemSerializer
    permission_classes = [LecturaOGestor]

    def get_queryset(self):
        qs = (
            Item.objects.select_related("categoria")
            .prefetch_related(Prefetch("stocks", queryset=Stock.objects.select_related("bodega")))
            .annotate(_stock_total=Sum("stocks__cantidad"))
            .order_by("nombre")  # Meta.ordering no se aplica en consultas con GROUP BY
        )
        # Los trabajadores solo ven ítems activos
        if not es_gestor(self.request.user) or self.request.query_params.get("activos") == "1":
            qs = qs.filter(activo=True)
        p = self.request.query_params
        if p.get("search"):
            s = p["search"]
            qs = qs.filter(Q(nombre__icontains=s) | Q(sku__icontains=s) | Q(categoria__nombre__icontains=s))
        if p.get("categoria"):
            qs = qs.filter(categoria_id=p["categoria"])
        if p.get("tipo"):
            qs = qs.filter(tipo=p["tipo"])
        if p.get("estado") and self.action == "list":
            qs = [i for i in qs if i.estado == p["estado"]]
        return qs

    def destroy(self, request, *args, **kwargs):
        # Se desactiva para conservar el historial de préstamos y movimientos
        item = self.get_object()
        item.activo = False
        item.save(update_fields=["activo"])
        return Response(status=status.HTTP_204_NO_CONTENT)


class MovimientoViewSet(viewsets.ReadOnlyModelViewSet):
    """Reporte de movimientos de stock. Filtros: ?bodega=id ?item=id ?tipo=salida ?desde=AAAA-MM-DD ?hasta=..."""

    serializer_class = MovimientoSerializer
    permission_classes = [EsGestor]

    def get_queryset(self):
        qs = MovimientoStock.objects.select_related("item", "bodega", "usuario")
        p = self.request.query_params
        for campo in ("bodega", "item", "tipo"):
            if p.get(campo):
                qs = qs.filter(**{campo: p[campo]})
        # Rangos de fecha/hora en lugar de fecha__date: en MySQL ese lookup usa CONVERT_TZ,
        # que devuelve NULL si el servidor no tiene cargadas las tablas de zonas horarias.
        if p.get("desde"):
            qs = qs.filter(fecha__gte=self._inicio_dia(p["desde"]))
        if p.get("hasta"):
            qs = qs.filter(fecha__lt=self._inicio_dia(p["hasta"]) + timedelta(days=1))
        return qs[:2000]

    @staticmethod
    def _inicio_dia(texto):
        try:
            return timezone.make_aware(datetime.combine(date.fromisoformat(texto), time.min))
        except ValueError:
            raise ValidationError({"detail": f"Fecha inválida: {texto} (usa AAAA-MM-DD)."})
