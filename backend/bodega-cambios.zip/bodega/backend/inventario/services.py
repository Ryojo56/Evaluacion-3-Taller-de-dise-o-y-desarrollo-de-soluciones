"""Operaciones de stock. Siempre llamar dentro de transaction.atomic()."""
from rest_framework.exceptions import ValidationError

from .models import Bodega, MovimientoStock, Stock


def mover_stock(item, bodega, delta, tipo, usuario, detalle=""):
    """Suma (delta > 0) o resta (delta < 0) stock con bloqueo de fila y deja registro.

    Las entradas y ajustes no pueden superar la capacidad de la bodega. Las devoluciones
    sí se aceptan siempre: la herramienta ya ocupaba ese espacio antes de prestarse.
    """
    if delta == 0:
        return None
    if delta > 0 and tipo != MovimientoStock.Tipo.DEVOLUCION:
        bodega = Bodega.objects.select_for_update().get(pk=bodega.pk)
        disponible = bodega.espacio_disponible
        if delta > disponible:
            raise ValidationError({
                "detail": f"{bodega.nombre} no tiene espacio suficiente: quedan {max(disponible, 0)} "
                          f"unidades libres de {bodega.capacidad} y se intentan agregar {delta}."
            })
    stock, _ = Stock.objects.select_for_update().get_or_create(item=item, bodega=bodega)
    nuevo = stock.cantidad + delta
    if nuevo < 0:
        raise ValidationError(
            {"detail": f"Stock insuficiente de {item.nombre} en {bodega.nombre} (disponible: {stock.cantidad})."}
        )
    stock.cantidad = nuevo
    stock.save(update_fields=["cantidad"])
    return MovimientoStock.objects.create(
        item=item, bodega=bodega, tipo=tipo, cantidad=delta,
        stock_resultante=nuevo, usuario=usuario, detalle=detalle,
    )


def fijar_stock(item, bodega, cantidad, usuario, detalle="Ajuste manual"):
    """Deja el stock de un ítem en una bodega en una cantidad exacta (formulario de ítem)."""
    if cantidad < 0:
        raise ValidationError({"stocks": "El stock no puede ser negativo."})
    actual = Stock.objects.filter(item=item, bodega=bodega).values_list("cantidad", flat=True).first() or 0
    tipo = MovimientoStock.Tipo.ENTRADA if actual == 0 and cantidad > 0 else MovimientoStock.Tipo.AJUSTE
    return mover_stock(item, bodega, cantidad - actual, tipo, usuario, detalle)
