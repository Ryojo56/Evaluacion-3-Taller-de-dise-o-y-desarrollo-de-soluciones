from django.db import transaction
from rest_framework import serializers

from .models import Bodega, Categoria, Item, MovimientoStock
from .services import fijar_stock


class BodegaSerializer(serializers.ModelSerializer):
    abreviatura = serializers.CharField(read_only=True)
    unidades_ocupadas = serializers.IntegerField(read_only=True)
    espacio_disponible = serializers.IntegerField(read_only=True)
    ocupacion_pct = serializers.SerializerMethodField()
    items_distintos = serializers.IntegerField(read_only=True, default=0)
    responsable_nombre = serializers.CharField(source="responsable.nombre_completo", read_only=True, default=None)

    class Meta:
        model = Bodega
        fields = [
            "id", "nombre", "ubicacion", "capacidad", "responsable", "responsable_nombre", "descripcion",
            "abreviatura", "unidades_ocupadas", "espacio_disponible", "ocupacion_pct", "items_distintos",
        ]
        extra_kwargs = {
            "ubicacion": {"error_messages": {"blank": "Indica dónde está la bodega."}},
            "capacidad": {"min_value": 1, "error_messages": {"min_value": "La capacidad debe ser al menos 1 unidad."}},
        }

    def get_ocupacion_pct(self, obj):
        return round(100 * obj.unidades_ocupadas / obj.capacidad, 1) if obj.capacidad else 0

    def validate_nombre(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("El nombre es obligatorio.")
        return value

    def validate_capacidad(self, value):
        if self.instance and value < self.instance.unidades_ocupadas:
            raise serializers.ValidationError(
                f"La bodega ya tiene {self.instance.unidades_ocupadas} unidades: la capacidad no puede ser menor."
            )
        return value

    def validate_responsable(self, user):
        if user and user.rol not in ("admin", "bodeguero"):
            raise serializers.ValidationError("El responsable debe ser un bodeguero o administrador.")
        return user


class CategoriaSerializer(serializers.ModelSerializer):
    productos = serializers.IntegerField(read_only=True, default=0)

    class Meta:
        model = Categoria
        fields = ["id", "nombre", "productos"]


class StockLineaSerializer(serializers.Serializer):
    bodega = serializers.PrimaryKeyRelatedField(queryset=Bodega.objects.all())
    cantidad = serializers.IntegerField()

    def validate_cantidad(self, value):
        if value < 0:
            raise serializers.ValidationError("El stock no puede ser negativo.")
        return value


class ItemSerializer(serializers.ModelSerializer):
    categoria_nombre = serializers.CharField(source="categoria.nombre", read_only=True)
    tipo_display = serializers.CharField(source="get_tipo_display", read_only=True)
    stock_total = serializers.IntegerField(read_only=True)
    estado = serializers.CharField(read_only=True)
    estado_display = serializers.SerializerMethodField()
    requiere_devolucion = serializers.BooleanField(read_only=True)
    stock_por_bodega = serializers.SerializerMethodField()
    # Escritura: [{bodega: id, cantidad: n}, ...]
    stocks = StockLineaSerializer(many=True, write_only=True, required=False)

    class Meta:
        model = Item
        fields = [
            "id", "sku", "nombre", "descripcion", "tipo", "tipo_display", "categoria", "categoria_nombre",
            "stock_minimo", "stock_critico", "activo", "stock_total", "estado", "estado_display",
            "requiere_devolucion", "stock_por_bodega", "stocks",
        ]
        read_only_fields = ["sku"]

    def get_estado_display(self, obj):
        return Item.Estado(obj.estado).label

    def get_stock_por_bodega(self, obj):
        return [
            {"bodega": s.bodega_id, "bodega_nombre": s.bodega.nombre,
             "abreviatura": s.bodega.abreviatura, "cantidad": s.cantidad}
            for s in obj.stocks.all() if s.cantidad > 0
        ]

    def validate(self, attrs):
        minimo = attrs.get("stock_minimo", getattr(self.instance, "stock_minimo", 5))
        critico = attrs.get("stock_critico", getattr(self.instance, "stock_critico", 2))
        if critico > minimo:
            raise serializers.ValidationError({"stock_critico": "El stock crítico no puede superar al stock mínimo."})
        if self.instance and "tipo" in attrs and attrs["tipo"] != self.instance.tipo:
            raise serializers.ValidationError({"tipo": "El tipo no se puede cambiar porque define el SKU."})
        return attrs

    def _guardar_stocks(self, item, stocks, detalle):
        usuario = self.context["request"].user
        for linea in stocks:
            fijar_stock(item, linea["bodega"], linea["cantidad"], usuario, detalle)

    @transaction.atomic
    def create(self, validated_data):
        stocks = validated_data.pop("stocks", [])
        item = Item.objects.create(**validated_data)
        self._guardar_stocks(item, stocks, "Stock inicial")
        return item

    @transaction.atomic
    def update(self, instance, validated_data):
        stocks = validated_data.pop("stocks", None)
        item = super().update(instance, validated_data)
        if stocks is not None:
            self._guardar_stocks(item, stocks, "Ajuste desde formulario de ítem")
        # Descarta valores calculados antes del cambio para responder con el stock actualizado
        item.__dict__.pop("_stock_total", None)
        getattr(item, "_prefetched_objects_cache", {}).clear()
        return item


class MovimientoSerializer(serializers.ModelSerializer):
    item_sku = serializers.CharField(source="item.sku", read_only=True)
    item_nombre = serializers.CharField(source="item.nombre", read_only=True)
    bodega_nombre = serializers.CharField(source="bodega.nombre", read_only=True)
    tipo_display = serializers.CharField(source="get_tipo_display", read_only=True)
    usuario_nombre = serializers.SerializerMethodField()

    class Meta:
        model = MovimientoStock
        fields = [
            "id", "fecha", "item", "item_sku", "item_nombre", "bodega", "bodega_nombre",
            "tipo", "tipo_display", "cantidad", "stock_resultante", "usuario_nombre", "detalle",
        ]

    def get_usuario_nombre(self, obj):
        return obj.usuario.nombre_completo if obj.usuario else "—"
