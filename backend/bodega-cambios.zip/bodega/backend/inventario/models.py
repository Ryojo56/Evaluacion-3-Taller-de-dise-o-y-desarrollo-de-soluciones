from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Sum


class Bodega(models.Model):
    nombre = models.CharField(max_length=100, unique=True)
    ubicacion = models.CharField(
        "ubicación", max_length=200, help_text="Dirección o sector, p. ej. 'Galpón principal, Av. Industrial 1450'."
    )
    capacidad = models.PositiveIntegerField(
        "capacidad (unidades)", default=1000, help_text="Máximo de unidades que caben en la bodega."
    )
    responsable = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="bodegas_a_cargo", help_text="Bodeguero a cargo.",
    )
    descripcion = models.TextField("descripción", blank=True)

    class Meta:
        db_table = "bodega"
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre

    @property
    def abreviatura(self):
        """'Bodega Central' -> 'B. Central' (como en los mockups)."""
        if self.nombre.lower().startswith("bodega "):
            return "B. " + self.nombre[7:]
        return self.nombre

    @property
    def unidades_ocupadas(self):
        if hasattr(self, "total_unidades"):
            return self.total_unidades or 0
        return self.stocks.aggregate(t=Sum("cantidad"))["t"] or 0

    @property
    def espacio_disponible(self):
        return self.capacidad - self.unidades_ocupadas


class Categoria(models.Model):
    nombre = models.CharField(max_length=100, unique=True)

    class Meta:
        db_table = "categoria"
        ordering = ["nombre"]
        verbose_name = "categoría"

    def __str__(self):
        return self.nombre


class Item(models.Model):
    """Herramienta, material o EPP del catálogo."""

    class Tipo(models.TextChoices):
        HERRAMIENTA = "herramienta", "Herramienta"
        MATERIAL = "material", "Material"
        EPP = "epp", "Equipo de protección"

    PREFIJOS = {Tipo.HERRAMIENTA: "HRM", Tipo.MATERIAL: "MAT", Tipo.EPP: "EPP"}

    class Estado(models.TextChoices):
        DISPONIBLE = "disponible", "Disponible"
        BAJO = "bajo", "Stock bajo"
        CRITICO = "critico", "Crítico"
        SIN_STOCK = "sin_stock", "Sin stock"

    sku = models.CharField("SKU", max_length=20, unique=True, editable=False)
    nombre = models.CharField(max_length=150)
    descripcion = models.TextField("descripción", blank=True)
    tipo = models.CharField(max_length=20, choices=Tipo.choices, default=Tipo.HERRAMIENTA)
    categoria = models.ForeignKey(Categoria, on_delete=models.PROTECT, related_name="items")
    stock_minimo = models.PositiveIntegerField(
        "stock mínimo", default=5, help_text="Bajo este total el ítem se marca 'Stock bajo'."
    )
    stock_critico = models.PositiveIntegerField(
        "stock crítico", default=2, help_text="En o bajo este total el ítem se marca 'Crítico'."
    )
    activo = models.BooleanField(default=True)
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "item"
        ordering = ["nombre"]
        verbose_name = "ítem"

    def __str__(self):
        return f"{self.sku} · {self.nombre}"

    @property
    def requiere_devolucion(self):
        """Las herramientas se prestan y se devuelven; materiales y EPP se consumen."""
        return self.tipo == self.Tipo.HERRAMIENTA

    def save(self, *args, **kwargs):
        if not self.sku:
            self.sku = self.siguiente_sku(self.tipo)
        super().save(*args, **kwargs)

    @classmethod
    def siguiente_sku(cls, tipo):
        prefijo = cls.PREFIJOS.get(tipo, "ITM")
        ultimos = cls.objects.filter(sku__startswith=prefijo + "-").values_list("sku", flat=True)
        numeros = [int(s.split("-")[1]) for s in ultimos if s.split("-")[1].isdigit()]
        return f"{prefijo}-{(max(numeros) + 1 if numeros else 1):04d}"

    @staticmethod
    def calcular_estado(total, minimo, critico):
        if total <= 0:
            return Item.Estado.SIN_STOCK
        if total <= critico:
            return Item.Estado.CRITICO
        if total < minimo:
            return Item.Estado.BAJO
        return Item.Estado.DISPONIBLE

    @property
    def stock_total(self):
        if hasattr(self, "_stock_total"):
            return self._stock_total or 0
        return self.stocks.aggregate(t=Sum("cantidad"))["t"] or 0

    @property
    def estado(self):
        return self.calcular_estado(self.stock_total, self.stock_minimo, self.stock_critico)


class Stock(models.Model):
    """Cantidad de un ítem en una bodega."""

    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="stocks")
    bodega = models.ForeignKey(Bodega, on_delete=models.PROTECT, related_name="stocks")
    cantidad = models.IntegerField(default=0, validators=[MinValueValidator(0)])

    class Meta:
        db_table = "stock"
        constraints = [
            models.UniqueConstraint(fields=["item", "bodega"], name="stock_unico_item_bodega"),
            models.CheckConstraint(condition=models.Q(cantidad__gte=0), name="stock_no_negativo"),
        ]

    def __str__(self):
        return f"{self.item.sku} @ {self.bodega}: {self.cantidad}"


class MovimientoStock(models.Model):
    """Registro de cada cambio de stock (reporte 'Movimientos')."""

    class Tipo(models.TextChoices):
        ENTRADA = "entrada", "Entrada"
        SALIDA = "salida", "Salida (entrega)"
        DEVOLUCION = "devolucion", "Devolución"
        AJUSTE = "ajuste", "Ajuste"

    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name="movimientos")
    bodega = models.ForeignKey(Bodega, on_delete=models.PROTECT, related_name="movimientos")
    tipo = models.CharField(max_length=20, choices=Tipo.choices)
    cantidad = models.IntegerField(help_text="Positivo suma stock, negativo resta.")
    stock_resultante = models.IntegerField()
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="+")
    detalle = models.CharField(max_length=255, blank=True)
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "movimiento_stock"
        ordering = ["-fecha"]
