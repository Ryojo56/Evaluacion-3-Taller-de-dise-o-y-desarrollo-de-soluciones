"""
Carga datos de demostración basados en los mockups.

    python manage.py seed            # crea datos si la base está vacía
    python manage.py seed --reset    # borra todo y vuelve a cargar
"""
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from inventario.models import Bodega, Categoria, Item, MovimientoStock, Stock
from inventario.services import mover_stock
from prestamos.models import Solicitud
from usuarios.models import Usuario

PASSWORD_DEMO = "Bodega#2026"


class Command(BaseCommand):
    help = "Carga datos de demostración (usuarios, bodegas, catálogo y préstamos)."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Borra los datos existentes antes de cargar.")

    @transaction.atomic
    def handle(self, *args, **opts):
        if opts["reset"]:
            Solicitud.objects.all().delete()
            MovimientoStock.objects.all().delete()
            Stock.objects.all().delete()
            Item.objects.all().delete()
            Categoria.objects.all().delete()
            Bodega.objects.all().delete()
            Usuario.objects.all().delete()
        elif Usuario.objects.exists():
            self.stdout.write(self.style.WARNING("La base ya tiene datos. Usa --reset para recargar."))
            return

        R = Usuario.Rol
        def usuario(email, nombre, apellido, rol, cambiar=False, **extra):
            return Usuario.objects.create_user(
                email=email, password=PASSWORD_DEMO, nombre=nombre, apellido=apellido, rol=rol,
                debe_cambiar_password=cambiar, **extra,
            )

        admin = usuario("admin@bodega.cl", "Alexander", "Smith", R.ADMIN, telefono="+56 9 1123 5444",
                        is_staff=True, is_superuser=True)
        carla = usuario("carla.munoz@bodega.cl", "Carla", "Muñoz", R.BODEGUERO, telefono="+56 9 4455 6677")
        juan = usuario("juan.munoz@bodega.cl", "Juan", "Muñoz", R.BODEGUERO, telefono="+56 9 2233 1100")
        jose = usuario("jose.perez@bodega.cl", "José", "Pérez", R.TRABAJADOR)
        maria = usuario("maria.soto@bodega.cl", "María", "Soto", R.TRABAJADOR)
        luis = usuario("luis.reyes@bodega.cl", "Luis", "Reyes", R.TRABAJADOR)
        pedro = usuario("pedro.vidal@bodega.cl", "Pedro", "Vidal", R.TRABAJADOR)
        usuario("nuevo@bodega.cl", "Usuario", "Nuevo", R.TRABAJADOR, cambiar=True)

        central = Bodega.objects.create(
            nombre="Bodega Central", ubicacion="Galpón principal, Av. Industrial 1450", capacidad=1000,
            responsable=carla, descripcion="Bodega principal: herramientas eléctricas, fijaciones y EPP.")
        norte = Bodega.objects.create(
            nombre="Bodega Norte", ubicacion="Sector norte, nave 3", capacidad=300, responsable=juan,
            descripcion="Apoyo a faenas del sector norte.")
        sur = Bodega.objects.create(
            nombre="Bodega Sur", ubicacion="Sector sur, contenedor 2", capacidad=120, responsable=carla,
            descripcion="Bodega pequeña para materiales de construcción.")

        cat = {n: Categoria.objects.create(nombre=n) for n in [
            "Herramientas eléctricas", "Herramientas manuales", "Materiales de fijación",
            "Materiales de construcción", "Equipos de protección",
        ]}

        T = Item.Tipo
        catalogo = [
            # nombre, tipo, categoría, mínimo, crítico, {bodega: stock}
            ('Taladro percutor 1/2"', T.HERRAMIENTA, "Herramientas eléctricas", 5, 3, {central: 3, norte: 1}),
            ('Amoladora angular 4.5"', T.HERRAMIENTA, "Herramientas eléctricas", 4, 1, {norte: 5}),
            ("Sierra circular 7 1/4\"", T.HERRAMIENTA, "Herramientas eléctricas", 2, 1, {central: 2, sur: 1}),
            ("Atornillador inalámbrico 20V", T.HERRAMIENTA, "Herramientas eléctricas", 3, 1, {central: 6}),
            ("Martillo carpintero 16oz", T.HERRAMIENTA, "Herramientas manuales", 5, 2, {central: 12, sur: 4}),
            ("Juego de llaves combinadas", T.HERRAMIENTA, "Herramientas manuales", 3, 1, {norte: 2}),
            ("Nivel de burbuja 60 cm", T.HERRAMIENTA, "Herramientas manuales", 3, 1, {central: 7}),
            ('Tornillo autoperforante 2"', T.MATERIAL, "Materiales de fijación", 100, 30, {central: 340}),
            ("Tarugo plástico 8 mm (caja)", T.MATERIAL, "Materiales de fijación", 10, 3, {central: 25, norte: 8}),
            ("Cemento gris 25kg", T.MATERIAL, "Materiales de construcción", 10, 4, {}),
            ("Arena gruesa (saco)", T.MATERIAL, "Materiales de construcción", 10, 4, {sur: 6}),
            ("Casco de seguridad", T.EPP, "Equipos de protección", 10, 4, {central: 58}),
            ("Guantes de cabritilla (par)", T.EPP, "Equipos de protección", 20, 8, {central: 120, norte: 40}),
            ("Lentes de seguridad", T.EPP, "Equipos de protección", 15, 5, {central: 9}),
        ]
        items = {}
        for nombre, tipo, categoria, minimo, critico, stocks in catalogo:
            item = Item.objects.create(nombre=nombre, tipo=tipo, categoria=cat[categoria],
                                       stock_minimo=minimo, stock_critico=critico)
            for bodega, cantidad in stocks.items():
                m = mover_stock(item, bodega, cantidad, MovimientoStock.Tipo.ENTRADA, admin, "Carga inicial")
                MovimientoStock.objects.filter(pk=m.pk).update(fecha=timezone.now() - timedelta(days=26))
            items[nombre] = item

        ahora = timezone.now()
        S = Solicitud.Estado

        def solicitud(trabajador, item_nombre, cantidad, dias_atras, estado=S.PENDIENTE, bodega=None,
                      limite=None, devolucion=None, motivo=""):
            item = items[item_nombre]
            s = Solicitud.objects.create(trabajador=trabajador, item=item, cantidad=cantidad, motivo=motivo,
                                         fecha_solicitud=ahora - timedelta(days=dias_atras))
            if estado == S.PENDIENTE:
                return s
            salida = mover_stock(item, bodega, -cantidad, MovimientoStock.Tipo.SALIDA, carla, f"Entrega solicitud #{s.pk}")
            s.estado, s.bodega, s.responsable = S.DESPACHADA, bodega, carla
            s.fecha_entrega = s.fecha_solicitud + timedelta(hours=2)
            MovimientoStock.objects.filter(pk=salida.pk).update(fecha=s.fecha_entrega)
            if item.requiere_devolucion:
                s.fecha_limite = limite
            if devolucion:
                estado_dev, comentario = devolucion
                dev = mover_stock(item, bodega, cantidad, MovimientoStock.Tipo.DEVOLUCION, s.trabajador,
                                  f"Devolución solicitud #{s.pk}")
                s.estado = S.DEVUELTA
                s.fecha_devolucion = s.fecha_limite - timedelta(hours=6)
                MovimientoStock.objects.filter(pk=dev.pk).update(fecha=s.fecha_devolucion)
                s.estado_devolucion, s.comentario_devolucion = estado_dev, comentario
            s.save()
            return s

        # Préstamo vencido (fila roja del historial)
        solicitud(luis, 'Taladro percutor 1/2"', 1, 9, S.DESPACHADA, central, limite=ahora - timedelta(days=2),
                  motivo="Instalación de soportes, nave 2")
        # Préstamo que vence en menos de 24 h (fila amarilla)
        solicitud(maria, 'Amoladora angular 4.5"', 1, 2, S.DESPACHADA, norte, limite=ahora + timedelta(hours=18),
                  motivo="Corte de perfiles")
        # Préstamo ya devuelto
        solicitud(pedro, "Sierra circular 7 1/4\"", 1, 15, S.DESPACHADA, central, limite=ahora - timedelta(days=10),
                  devolucion=(Solicitud.EstadoDevolucion.BUENO,
                              "Funcionó sin problemas durante toda la faena, disco en buen estado."))
        solicitud(jose, "Martillo carpintero 16oz", 1, 20, S.DESPACHADA, central, limite=ahora - timedelta(days=17),
                  devolucion=(Solicitud.EstadoDevolucion.REGULAR,
                              "El mango tiene una trizadura pequeña, conviene revisarlo antes de prestarlo."))
        # Material entregado (no requiere devolución)
        solicitud(luis, 'Tornillo autoperforante 2"', 80, 4, S.DESPACHADA, central, motivo="Techumbre bodega sur")
        # Historia del mes: reposiciones y entregas de consumibles en distintos días
        historia = [
            (24, 'Tornillo autoperforante 2"', central, 120, "entrada"), (22, "Guantes de cabritilla (par)", central, -30, "salida"),
            (19, "Casco de seguridad", central, -6, "salida"), (17, "Tarugo plástico 8 mm (caja)", central, 10, "entrada"),
            (15, 'Tornillo autoperforante 2"', central, -60, "salida"), (12, "Lentes de seguridad", central, -4, "salida"),
            (10, "Guantes de cabritilla (par)", norte, 25, "entrada"), (8, "Arena gruesa (saco)", sur, -3, "salida"),
            (6, "Casco de seguridad", central, 12, "entrada"), (5, "Guantes de cabritilla (par)", central, -18, "salida"),
            (3, 'Tornillo autoperforante 2"', central, -40, "salida"), (2, "Tarugo plástico 8 mm (caja)", norte, -4, "salida"),
            (1, "Lentes de seguridad", central, 6, "entrada"),
        ]
        for dias, nombre, bodega, delta, tipo in historia:
            m = mover_stock(items[nombre], bodega, delta, tipo, carla,
                            "Reposición proveedor" if delta > 0 else "Entrega a cuadrilla")
            MovimientoStock.objects.filter(pk=m.pk).update(fecha=ahora - timedelta(days=dias, hours=3))

        # Pendientes de entrega
        solicitud(maria, 'Amoladora angular 4.5"', 1, 0, motivo="Mantención eléctrica taller B")
        solicitud(jose, "Casco de seguridad", 2, 0, motivo="Ingreso de personal nuevo")
        # Pide más de lo que hay (motivo obligatorio)
        s = solicitud(pedro, "Arena gruesa (saco)", 20, 1,
                      motivo="Radier de la bodega sur: se necesitan 20 sacos para terminar la obra esta semana.")
        s.stock_al_solicitar, s.excede_stock = items["Arena gruesa (saco)"].stock_total, True
        s.save(update_fields=["stock_al_solicitar", "excede_stock"])

        self.stdout.write(self.style.SUCCESS(
            f"Datos de demo cargados. Contraseña de todos los usuarios: {PASSWORD_DEMO}\n"
            "  admin@bodega.cl (admin) · carla.munoz@bodega.cl (bodeguero) · jose.perez@bodega.cl (trabajador)\n"
            "  nuevo@bodega.cl debe cambiar su contraseña en el primer inicio de sesión."
        ))
