from django.utils import timezone
from rest_framework import serializers

from inventario.models import Bodega

from .models import Solicitud


class SolicitudSerializer(serializers.ModelSerializer):
    trabajador_nombre = serializers.CharField(source="trabajador.nombre_completo", read_only=True)
    item_sku = serializers.CharField(source="item.sku", read_only=True)
    item_nombre = serializers.CharField(source="item.nombre", read_only=True)
    item_tipo = serializers.CharField(source="item.tipo", read_only=True)
    es_prestamo = serializers.BooleanField(read_only=True)
    estado_display = serializers.CharField(source="get_estado_display", read_only=True)
    bodega_nombre = serializers.CharField(source="bodega.nombre", read_only=True, default=None)
    responsable_nombre = serializers.CharField(source="responsable.nombre_completo", read_only=True, default=None)
    estado_devolucion_display = serializers.CharField(source="get_estado_devolucion_display", read_only=True)
    vencida = serializers.BooleanField(read_only=True)
    horas_restantes = serializers.SerializerMethodField()
    disponible_actual = serializers.SerializerMethodField()

    class Meta:
        model = Solicitud
        fields = [
            "id", "trabajador", "trabajador_nombre", "item", "item_sku", "item_nombre", "item_tipo",
            "es_prestamo", "cantidad", "motivo", "stock_al_solicitar", "excede_stock", "disponible_actual",
            "fecha_solicitud", "estado", "estado_display",
            "bodega", "bodega_nombre", "responsable_nombre", "fecha_entrega", "fecha_limite", "motivo_rechazo",
            "fecha_devolucion", "estado_devolucion", "estado_devolucion_display", "comentario_devolucion",
            "vencida", "horas_restantes",
        ]
        read_only_fields = [
            "trabajador", "fecha_solicitud", "estado", "stock_al_solicitar", "excede_stock", "bodega", "fecha_entrega", "fecha_limite",
            "motivo_rechazo", "fecha_devolucion", "estado_devolucion", "comentario_devolucion",
        ]

    def get_horas_restantes(self, obj):
        if obj.estado != Solicitud.Estado.DESPACHADA or not obj.fecha_limite:
            return None
        return round((obj.fecha_limite - timezone.now()).total_seconds() / 3600, 1)

    def validate_item(self, item):
        if not item.activo:
            raise serializers.ValidationError("Este ítem ya no está disponible en el catálogo.")
        return item

    def get_disponible_actual(self, obj):
        # Solo interesa mientras la solicitud está pendiente (para saber si ya se puede entregar)
        return obj.item.stock_total if obj.estado == Solicitud.Estado.PENDIENTE else None

    MOTIVO_MINIMO = 15

    def validate(self, attrs):
        """Se puede pedir más de lo disponible, pero entonces el motivo es obligatorio."""
        item, cantidad = attrs["item"], attrs["cantidad"]
        motivo = (attrs.get("motivo") or "").strip()
        attrs["motivo"] = motivo
        disponible = item.stock_total
        attrs["stock_al_solicitar"] = disponible
        attrs["excede_stock"] = cantidad > disponible
        if attrs["excede_stock"] and len(motivo) < self.MOTIVO_MINIMO:
            raise serializers.ValidationError({
                "motivo": (
                    f"Pides {cantidad} y hay {disponible} disponibles. Explica por qué necesitas esa cantidad "
                    f"(mínimo {self.MOTIVO_MINIMO} caracteres) para que el bodeguero pueda gestionar la reposición."
                )
            })
        return attrs


class EntregarSerializer(serializers.Serializer):
    bodega = serializers.PrimaryKeyRelatedField(queryset=Bodega.objects.all())
    fecha_limite = serializers.DateTimeField(required=False, allow_null=True)

    def validate_fecha_limite(self, value):
        if value and value <= timezone.now():
            raise serializers.ValidationError("La fecha límite debe ser futura.")
        return value


class RechazarSerializer(serializers.Serializer):
    motivo = serializers.CharField(max_length=300, required=False, allow_blank=True)


class DevolverSerializer(serializers.Serializer):
    estado_devolucion = serializers.ChoiceField(choices=Solicitud.EstadoDevolucion.choices)
    comentario = serializers.CharField(
        min_length=30, max_length=2500,
        error_messages={
            "min_length": "El comentario debe tener al menos 30 caracteres.",
            "max_length": "El comentario no puede superar los 2500 caracteres.",
        },
    )

