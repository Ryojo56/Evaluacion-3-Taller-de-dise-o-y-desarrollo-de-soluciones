from django.conf import settings
from django.core.validators import MaxLengthValidator, MinLengthValidator, MinValueValidator
from django.db import models
from django.utils import timezone

from inventario.models import Bodega, Item


class Solicitud(models.Model):
    """
    Ciclo de vida:
      PENDIENTE  --(bodeguero entrega)-->  DESPACHADA  --(trabajador devuelve)-->  DEVUELTA
          \\--(bodeguero rechaza / trabajador cancela)--> RECHAZADA / CANCELADA

    Los materiales y EPP quedan DESPACHADOS (se consumen). Las herramientas
    son préstamos: tienen fecha límite y deben devolverse con un comentario.
    """

    class Estado(models.TextChoices):
        PENDIENTE = "pendiente", "Pendiente"
        DESPACHADA = "despachada", "Despachada"
        DEVUELTA = "devuelta", "Devuelta"
        RECHAZADA = "rechazada", "Rechazada"
        CANCELADA = "cancelada", "Cancelada"

    class EstadoDevolucion(models.TextChoices):
        BUENO = "bueno", "Bueno"
        REGULAR = "regular", "Regular"
        CON_FALLA = "con_falla", "Con falla"

    # Solicitud (pantalla "Solicitar herramienta o material")
    trabajador = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="solicitudes")
    item = models.ForeignKey(Item, on_delete=models.PROTECT, related_name="solicitudes")
    cantidad = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    motivo = models.CharField(
        "motivo / tarea asociada", max_length=300, blank=True,
        help_text="Obligatorio cuando la cantidad pedida supera el stock disponible.",
    )
    stock_al_solicitar = models.PositiveIntegerField(default=0, help_text="Stock total al momento de solicitar.")
    excede_stock = models.BooleanField(default=False, help_text="Se pidió más de lo que había en bodega.")
    fecha_solicitud = models.DateTimeField(default=timezone.now)
    estado = models.CharField(max_length=20, choices=Estado.choices, default=Estado.PENDIENTE)

    # Entrega (pantalla "Solicitudes pendientes de entrega")
    bodega = models.ForeignKey(Bodega, on_delete=models.PROTECT, null=True, blank=True, related_name="solicitudes")
    responsable = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name="entregas"
    )
    fecha_entrega = models.DateTimeField(null=True, blank=True)
    fecha_limite = models.DateTimeField("fecha límite de devolución", null=True, blank=True)
    motivo_rechazo = models.CharField(max_length=300, blank=True)

    # Devolución (pantalla "Comentar herramienta devuelta")
    fecha_devolucion = models.DateTimeField(null=True, blank=True)
    estado_devolucion = models.CharField(max_length=20, choices=EstadoDevolucion.choices, blank=True)
    comentario_devolucion = models.TextField(
        blank=True, validators=[MinLengthValidator(30), MaxLengthValidator(2500)]
    )

    class Meta:
        db_table = "solicitud"
        ordering = ["-fecha_solicitud"]
        verbose_name_plural = "solicitudes"
        indexes = [models.Index(fields=["estado", "fecha_limite"])]

    def __str__(self):
        return f"#{self.pk} {self.item} x{self.cantidad} ({self.get_estado_display()})"

    @property
    def es_prestamo(self):
        return self.item.requiere_devolucion

    @property
    def vencida(self):
        return (
            self.estado == self.Estado.DESPACHADA
            and self.fecha_limite is not None
            and self.fecha_limite < timezone.now()
        )
