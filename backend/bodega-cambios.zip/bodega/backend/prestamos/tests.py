from datetime import timedelta

from django.utils import timezone
from rest_framework.test import APITestCase

from inventario.models import Bodega, Categoria, Item, MovimientoStock, Stock
from usuarios.models import Usuario

PWD = "Clave#Segura1"


class FlujoBodegaTests(APITestCase):
    def setUp(self):
        R = Usuario.Rol
        self.admin = Usuario.objects.create_user("admin@t.cl", PWD, nombre="Ad", rol=R.ADMIN, debe_cambiar_password=False)
        self.bod = Usuario.objects.create_user("bod@t.cl", PWD, nombre="Bo", rol=R.BODEGUERO, debe_cambiar_password=False)
        self.trab = Usuario.objects.create_user("tra@t.cl", PWD, nombre="Tra", rol=R.TRABAJADOR, debe_cambiar_password=False)
        self.central = Bodega.objects.create(nombre="Bodega Central", ubicacion="Galpón 1", capacidad=1000)
        self.cat = Categoria.objects.create(nombre="Herramientas")
        self.taladro = Item.objects.create(nombre="Taladro", tipo=Item.Tipo.HERRAMIENTA, categoria=self.cat,
                                           stock_minimo=5, stock_critico=2)
        Stock.objects.create(item=self.taladro, bodega=self.central, cantidad=4)

    def login(self, user):
        r = self.client.post("/api/auth/login/", {"email": user.email.upper(), "password": PWD}, format="json")
        self.assertEqual(r.status_code, 200, r.data)
        self.client.credentials(HTTP_AUTHORIZATION="Bearer " + r.data["access"])
        return r.data

    # --- Usuarios / auth -------------------------------------------------
    def test_login_devuelve_usuario_y_rol(self):
        data = self.login(self.trab)
        self.assertEqual(data["usuario"]["rol"], "trabajador")

    def test_login_incorrecto(self):
        r = self.client.post("/api/auth/login/", {"email": "tra@t.cl", "password": "x"}, format="json")
        self.assertEqual(r.status_code, 401)

    def test_admin_crea_usuario_con_password_temporal_y_primer_login(self):
        self.login(self.admin)
        r = self.client.post("/api/usuarios/", {"nombre": "Ana", "apellido": "Lagos", "email": "ana@t.cl",
                                                "telefono": "+569", "rol": "trabajador"}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        temporal = r.data["password_temporal"]
        self.assertTrue(r.data["debe_cambiar_password"])

        self.client.credentials()
        r = self.client.post("/api/auth/login/", {"email": "ana@t.cl", "password": temporal}, format="json")
        self.assertTrue(r.data["usuario"]["debe_cambiar_password"])
        self.client.credentials(HTTP_AUTHORIZATION="Bearer " + r.data["access"])
        # Contraseña débil: rechazada
        r = self.client.post("/api/auth/cambiar-password/", {"password_actual": temporal, "password_nueva": "abc",
                                                             "password_confirmacion": "abc"}, format="json")
        self.assertEqual(r.status_code, 400)
        r = self.client.post("/api/auth/cambiar-password/", {"password_actual": temporal, "password_nueva": "Nueva#Clave9",
                                                             "password_confirmacion": "Nueva#Clave9"}, format="json")
        self.assertEqual(r.status_code, 200, r.data)
        self.assertFalse(r.data["usuario"]["debe_cambiar_password"])

    def test_trabajador_no_gestiona_usuarios_ni_items(self):
        self.login(self.trab)
        self.assertEqual(self.client.get("/api/usuarios/").status_code, 403)
        r = self.client.post("/api/items/", {"nombre": "X", "tipo": "material", "categoria": self.cat.id}, format="json")
        self.assertEqual(r.status_code, 403)
        self.assertEqual(self.client.get("/api/items/").status_code, 200)

    def test_perfil_exige_password_actual(self):
        self.login(self.trab)
        r = self.client.patch("/api/auth/me/", {"telefono": "123", "password_actual": "mala"}, format="json")
        self.assertEqual(r.status_code, 400)
        r = self.client.patch("/api/auth/me/", {"telefono": "123", "password_actual": PWD}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["telefono"], "123")

    # --- Inventario ------------------------------------------------------
    def test_item_sku_automatico_estado_y_stock_negativo(self):
        self.login(self.bod)
        r = self.client.post("/api/items/", {"nombre": "Amoladora", "tipo": "herramienta", "categoria": self.cat.id,
                                             "stocks": [{"bodega": self.central.id, "cantidad": -1}]}, format="json")
        self.assertEqual(r.status_code, 400)
        r = self.client.post("/api/items/", {"nombre": "Amoladora", "tipo": "herramienta", "categoria": self.cat.id,
                                             "stock_minimo": 5, "stock_critico": 2,
                                             "stocks": [{"bodega": self.central.id, "cantidad": 3}]}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertEqual(r.data["sku"], "HRM-0002")
        self.assertEqual(r.data["estado"], "bajo")
        # Edición: el stock se fija y queda un movimiento de ajuste
        r = self.client.patch(f"/api/items/{r.data['id']}/", {"stocks": [{"bodega": self.central.id, "cantidad": 10}]},
                              format="json")
        self.assertEqual(r.data["stock_total"], 10)
        self.assertEqual(r.data["estado"], "disponible")
        self.assertTrue(MovimientoStock.objects.filter(tipo="ajuste", cantidad=7).exists())

    def test_reporte_movimientos_filtra_por_fecha(self):
        from inventario.services import mover_stock
        mover_stock(self.taladro, self.central, 2, MovimientoStock.Tipo.ENTRADA, self.admin, "hoy")
        self.login(self.bod)
        hoy = timezone.localdate().isoformat()
        ayer = (timezone.localdate() - timedelta(days=1)).isoformat()
        self.assertEqual(len(self.client.get(f"/api/movimientos/?desde={hoy}&hasta={hoy}").data), 1)
        self.assertEqual(len(self.client.get(f"/api/movimientos/?hasta={ayer}").data), 0)
        self.assertEqual(self.client.get("/api/movimientos/?desde=no-es-fecha").status_code, 400)

    def test_no_se_elimina_categoria_con_productos(self):
        self.login(self.admin)
        r = self.client.delete(f"/api/categorias/{self.cat.id}/")
        self.assertEqual(r.status_code, 400)
        self.assertIn("productos asociados", r.data["detail"])

    # --- Préstamos -------------------------------------------------------
    def test_flujo_completo_prestamo(self):
        self.login(self.trab)
        r = self.client.post("/api/solicitudes/", {"item": self.taladro.id, "cantidad": 9}, format="json")
        self.assertEqual(r.status_code, 400)  # más que el stock y sin motivo
        self.assertIn("motivo", r.data)
        r = self.client.post("/api/solicitudes/", {"item": self.taladro.id, "cantidad": 2, "motivo": "Taller B"},
                             format="json")
        self.assertEqual(r.status_code, 201, r.data)
        sid = r.data["id"]
        self.assertEqual(r.data["estado"], "pendiente")
        # El trabajador no puede entregarse a sí mismo
        self.assertEqual(self.client.post(f"/api/solicitudes/{sid}/entregar/", {"bodega": self.central.id}).status_code, 403)

        self.login(self.bod)
        r = self.client.post(f"/api/solicitudes/{sid}/entregar/", {"bodega": self.central.id}, format="json")
        self.assertEqual(r.status_code, 200, r.data)
        self.assertEqual(r.data["estado"], "despachada")
        self.assertIsNotNone(r.data["fecha_limite"])
        self.assertEqual(Stock.objects.get(item=self.taladro).cantidad, 2)

        self.login(self.trab)
        r = self.client.post(f"/api/solicitudes/{sid}/devolver/", {"estado_devolucion": "bueno", "comentario": "corto"},
                             format="json")
        self.assertEqual(r.status_code, 400)
        r = self.client.post(f"/api/solicitudes/{sid}/devolver/",
                             {"estado_devolucion": "con_falla", "comentario": "El percutor se traba al usar la segunda velocidad."},
                             format="json")
        self.assertEqual(r.status_code, 200, r.data)
        self.assertEqual(r.data["estado"], "devuelta")
        self.assertEqual(Stock.objects.get(item=self.taladro).cantidad, 4)

    def test_solicitud_sobre_stock_requiere_motivo(self):
        self.login(self.trab)
        r = self.client.post("/api/solicitudes/", {"item": self.taladro.id, "cantidad": 10, "motivo": "lo necesito"},
                             format="json")
        self.assertEqual(r.status_code, 400)  # motivo demasiado corto
        r = self.client.post("/api/solicitudes/", {"item": self.taladro.id, "cantidad": 10,
                                                   "motivo": "Cuadrilla de 10 personas para la faena del lunes"},
                             format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertTrue(r.data["excede_stock"])
        self.assertEqual(r.data["stock_al_solicitar"], 4)
        # Dentro del stock no hace falta motivo
        r = self.client.post("/api/solicitudes/", {"item": self.taladro.id, "cantidad": 1}, format="json")
        self.assertEqual(r.status_code, 201)
        self.assertFalse(r.data["excede_stock"])
        # Un ítem sin stock también se puede pedir con motivo
        Stock.objects.filter(item=self.taladro).update(cantidad=0)
        r = self.client.post("/api/solicitudes/", {"item": self.taladro.id, "cantidad": 1,
                                                   "motivo": "Reemplazo urgente de un taladro dañado"}, format="json")
        self.assertEqual(r.status_code, 201, r.data)

    def test_bodega_capacidad(self):
        self.login(self.admin)
        r = self.client.post("/api/bodegas/", {"nombre": "Bodega Mini", "ubicacion": "Patio", "capacidad": 5,
                                               "responsable": self.bod.id}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        mini = r.data["id"]
        self.assertEqual(r.data["espacio_disponible"], 5)
        # Sin ubicación: error de validación legible
        r = self.client.post("/api/bodegas/", {"nombre": "Otra", "ubicacion": "", "capacidad": 5}, format="json")
        self.assertIn("ubicacion", r.data)
        # Un trabajador no puede ser responsable
        r = self.client.patch(f"/api/bodegas/{mini}/", {"responsable": self.trab.id}, format="json")
        self.assertEqual(r.status_code, 400)
        # Stock que no cabe
        r = self.client.patch(f"/api/items/{self.taladro.id}/", {"stocks": [{"bodega": mini, "cantidad": 6}]}, format="json")
        self.assertEqual(r.status_code, 400)
        self.assertIn("espacio", str(r.data))
        r = self.client.patch(f"/api/items/{self.taladro.id}/", {"stocks": [{"bodega": mini, "cantidad": 5}]}, format="json")
        self.assertEqual(r.status_code, 200, r.data)
        # La capacidad no puede quedar bajo lo que ya hay
        r = self.client.patch(f"/api/bodegas/{mini}/", {"capacidad": 3}, format="json")
        self.assertEqual(r.status_code, 400)
        r = self.client.get(f"/api/bodegas/{mini}/")
        self.assertEqual((r.data["unidades_ocupadas"], r.data["espacio_disponible"], r.data["ocupacion_pct"]), (5, 0, 100.0))

    def test_reportes_aplican_filtros(self):
        norte = Bodega.objects.create(nombre="Bodega Norte", ubicacion="N", capacidad=100)
        cat2 = Categoria.objects.create(nombre="Materiales")
        tornillo = Item.objects.create(nombre="Tornillo", tipo=Item.Tipo.MATERIAL, categoria=cat2)
        Stock.objects.create(item=tornillo, bodega=norte, cantidad=50)
        self.login(self.bod)
        r = self.client.get("/api/reportes/inventario/").data
        self.assertEqual((r["resumen"]["items"], r["resumen"]["unidades"]), (2, 54))
        r = self.client.get(f"/api/reportes/inventario/?bodega={norte.id}").data
        self.assertEqual([f["sku"] for f in r["filas"]], [tornillo.sku])
        self.assertEqual(r["resumen"]["unidades"], 50)
        r = self.client.get(f"/api/reportes/inventario/?categoria={self.cat.id}&estado=bajo").data
        self.assertEqual(r["resumen"]["items"], 1)  # taladro: 4 < mínimo 5
        self.assertEqual(r["por_categoria"], [{"nombre": "Herramientas", "valor": 4}])

        from prestamos.models import Solicitud
        Solicitud.objects.create(trabajador=self.trab, item=self.taladro, cantidad=1)
        Solicitud.objects.create(trabajador=self.trab, item=tornillo, cantidad=3, estado="despachada", bodega=norte)
        r = self.client.get("/api/reportes/prestamos/").data
        self.assertEqual((r["resumen"]["solicitudes"], r["resumen"]["pendientes"], r["resumen"]["consumidos"]), (2, 1, 1))
        r = self.client.get("/api/reportes/prestamos/?estado=pendiente").data
        self.assertEqual(r["resumen"]["solicitudes"], 1)
        self.assertEqual(r["filas"][0]["estado_reporte"], "pendiente")
        r = self.client.get(f"/api/reportes/prestamos/?tipo=material&bodega={norte.id}").data
        self.assertEqual(r["resumen"]["unidades"], 3)

        from inventario.services import mover_stock
        mover_stock(tornillo, norte, -5, MovimientoStock.Tipo.SALIDA, self.bod, "x")
        mover_stock(self.taladro, self.central, 2, MovimientoStock.Tipo.ENTRADA, self.bod, "y")
        r = self.client.get("/api/reportes/movimientos/").data
        self.assertEqual((r["resumen"]["entradas"], r["resumen"]["salidas"]), (2, 5))
        r = self.client.get(f"/api/reportes/movimientos/?bodega={norte.id}").data
        self.assertEqual((r["resumen"]["movimientos"], r["resumen"]["entradas"]), (1, 0))
        self.assertEqual(r["top_salidas"][0]["valor"], 5)
        self.assertEqual(self.client.get("/api/reportes/movimientos/?desde=2026-05-10&hasta=2026-05-01").status_code, 400)
        # Los trabajadores no ven reportes
        self.login(self.trab)
        self.assertEqual(self.client.get("/api/reportes/inventario/").status_code, 403)

    def test_admin_edita_usuario_y_no_desactiva_con_prestamos(self):
        from prestamos.models import Solicitud
        Solicitud.objects.create(trabajador=self.trab, item=self.taladro, cantidad=1, estado="despachada",
                                 bodega=self.central, fecha_limite=timezone.now() + timedelta(days=1))
        self.login(self.admin)
        r = self.client.patch(f"/api/usuarios/{self.trab.id}/", {"nombre": "Trabajador", "telefono": "+56 9 1"}, format="json")
        self.assertEqual(r.status_code, 200)
        r = self.client.get("/api/usuarios/").data
        fila = next(u for u in r if u["id"] == self.trab.id)
        self.assertEqual((fila["nombre"], fila["prestamos_activos"], fila["solicitudes_total"]), ("Trabajador", 1, 1))
        self.assertIsNotNone(next(u for u in r if u["id"] == self.admin.id)["last_login"])
        self.assertEqual(self.client.delete(f"/api/usuarios/{self.trab.id}/").status_code, 400)
        self.assertEqual(self.client.patch(f"/api/usuarios/{self.admin.id}/", {"rol": "trabajador"}, format="json").status_code, 400)

    def test_entrega_sin_stock_en_bodega(self):
        norte = Bodega.objects.create(nombre="Bodega Norte", ubicacion="N", capacidad=100)
        self.login(self.trab)
        sid = self.client.post("/api/solicitudes/", {"item": self.taladro.id, "cantidad": 1}, format="json").data["id"]
        self.login(self.bod)
        r = self.client.post(f"/api/solicitudes/{sid}/entregar/", {"bodega": norte.id}, format="json")
        self.assertEqual(r.status_code, 400)
        self.assertIn("Stock insuficiente", str(r.data))

    def test_trabajador_solo_ve_sus_solicitudes_y_dashboard(self):
        otro = Usuario.objects.create_user("o@t.cl", PWD, nombre="Otro", debe_cambiar_password=False)
        from prestamos.models import Solicitud
        Solicitud.objects.create(trabajador=otro, item=self.taladro, cantidad=1)
        s = Solicitud.objects.create(trabajador=self.trab, item=self.taladro, cantidad=1, estado="despachada",
                                     bodega=self.central, fecha_limite=timezone.now() - timedelta(hours=1))
        self.login(self.trab)
        r = self.client.get("/api/solicitudes/")
        self.assertEqual([x["id"] for x in r.data], [s.id])
        self.assertTrue(r.data[0]["vencida"])
        d = self.client.get("/api/dashboard/").data
        self.assertEqual(d["tarjetas"][2]["valor"], 1)
        self.login(self.bod)
        self.assertEqual(len(self.client.get("/api/solicitudes/").data), 2)
