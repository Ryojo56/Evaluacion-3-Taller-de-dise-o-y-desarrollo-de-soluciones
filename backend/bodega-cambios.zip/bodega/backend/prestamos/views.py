from datetime import timedelta

from django.conf import settings
from django.db import transaction
from django.db.models import Q, Sum
from django.utils import timezone
from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action, api_view
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.response import Response

from inventario.models import Bodega, Item, MovimientoStock
from inventario.services import mover_stock
from usuarios.permissions import EsGestor, es_gestor

from .models import Solicitud
from .serializers import DevolverSerializer, EntregarSerializer, RechazarSerializer, SolicitudSerializer

E = Solicitud.Estado


class SolicitudViewSet(mixins.CreateModelMixin, mixins.ListModelMixin, mixins.RetrieveModelMixin,
                       viewsets.GenericViewSet):
    """
    Trabajador: crea solicitudes y ve las suyas.  Bodeguero/Admin: ve todas, entrega o rechaza.

    Filtros: ?estado=pendiente,despachada  ?mias=1  ?search=texto  ?prestamos=1 (solo herramientas)
    """

    serializer_class = SolicitudSerializer

    def get_queryset(self):
        qs = Solicitud.objects.select_related("trabajador", "item", "bodega", "responsable")
        p = self.request.query_params
        if not es_gestor(self.request.user) or p.get("mias") == "1":
            qs = qs.filter(trabajador=self.request.user)
        if p.get("estado"):
            qs = qs.filter(estado__in=p["estado"].split(","))
        if p.get("prestamos") == "1":
            qs = qs.filter(item__tipo=Item.Tipo.HERRAMIENTA)
        if p.get("search"):
            s = p["search"]
            qs = qs.filter(
                Q(item__nombre__icontains=s) | Q(item__sku__icontains=s)
                | Q(trabajador__nombre__icontains=s) | Q(trabajador__apellido__icontains=s)
            )
        return qs

    def perform_create(self, serializer):
        serializer.save(trabajador=self.request.user)

    def _bloquear(self, pk):
        return Solicitud.objects.select_for_update().select_related("item").get(pk=pk)

    @action(detail=True, methods=["post"], permission_classes=[EsGestor])
    @transaction.atomic
    def entregar(self, request, pk=None):
        self.get_object()  # 404 / permisos
        sol = self._bloquear(pk)
        if sol.estado != E.PENDIENTE:
            raise ValidationError({"detail": "Solo se pueden entregar solicitudes pendientes."})
        ser = EntregarSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        bodega = ser.validated_data["bodega"]

        mover_stock(sol.item, bodega, -sol.cantidad, MovimientoStock.Tipo.SALIDA, request.user,
                    f"Entrega solicitud #{sol.pk} a {sol.trabajador.nombre_completo}")
        ahora = timezone.now()
        sol.estado = E.DESPACHADA
        sol.bodega = bodega
        sol.responsable = request.user
        sol.fecha_entrega = ahora
        if sol.es_prestamo:
            sol.fecha_limite = ser.validated_data.get("fecha_limite") or ahora + timedelta(
                days=settings.PRESTAMO_DIAS_DEFAULT
            )
        sol.save()
        return Response(SolicitudSerializer(sol).data)

    @action(detail=True, methods=["post"], permission_classes=[EsGestor])
    @transaction.atomic
    def rechazar(self, request, pk=None):
        self.get_object()
        sol = self._bloquear(pk)
        if sol.estado != E.PENDIENTE:
            raise ValidationError({"detail": "Solo se pueden rechazar solicitudes pendientes."})
        ser = RechazarSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        sol.estado = E.RECHAZADA
        sol.responsable = request.user
        sol.motivo_rechazo = ser.validated_data.get("motivo", "")
        sol.save()
        return Response(SolicitudSerializer(sol).data)

    @action(detail=True, methods=["post"])
    @transaction.atomic
    def cancelar(self, request, pk=None):
        sol = self.get_object()
        if sol.trabajador_id != request.user.id:
            raise PermissionDenied("Solo quien hizo la solicitud puede cancelarla.")
        sol = self._bloquear(pk)
        if sol.estado != E.PENDIENTE:
            raise ValidationError({"detail": "Solo se pueden cancelar solicitudes pendientes."})
        sol.estado = E.CANCELADA
        sol.save(update_fields=["estado"])
        return Response(SolicitudSerializer(sol).data)

    @action(detail=True, methods=["post"])
    @transaction.atomic
    def devolver(self, request, pk=None):
        """Pantalla 'Comentar herramienta devuelta'. La herramienta vuelve a su bodega."""
        sol = self.get_object()
        if sol.trabajador_id != request.user.id and not es_gestor(request.user):
            raise PermissionDenied("No puedes registrar la devolución de este préstamo.")
        sol = self._bloquear(pk)
        if sol.estado != E.DESPACHADA or not sol.es_prestamo:
            raise ValidationError({"detail": "Este préstamo no está pendiente de devolución."})
        ser = DevolverSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        mover_stock(sol.item, sol.bodega, sol.cantidad, MovimientoStock.Tipo.DEVOLUCION, request.user,
                    f"Devolución solicitud #{sol.pk} ({ser.validated_data['estado_devolucion']})")
        sol.estado = E.DEVUELTA
        sol.fecha_devolucion = timezone.now()
        sol.estado_devolucion = ser.validated_data["estado_devolucion"]
        sol.comentario_devolucion = ser.validated_data["comentario"]
        sol.save()
        return Response(SolicitudSerializer(sol).data, status=status.HTTP_200_OK)


@api_view(["GET"])
def dashboard(request):
    """Datos de la pantalla Home: tarjetas de resumen y notificaciones (campana)."""
    user = request.user
    ahora = timezone.now()
    prestamos_activos = Solicitud.objects.filter(estado=E.DESPACHADA, item__tipo=Item.Tipo.HERRAMIENTA)
    notificaciones = []

    if es_gestor(user):
        items = Item.objects.filter(activo=True).annotate(_stock_total=Sum("stocks__cantidad"))
        criticos = sum(1 for i in items if i.estado in (Item.Estado.CRITICO, Item.Estado.SIN_STOCK))
        pendientes = Solicitud.objects.filter(estado=E.PENDIENTE).select_related("trabajador", "item")
        vencidos = prestamos_activos.filter(fecha_limite__lt=ahora).select_related("trabajador", "item")
        tarjetas = [
            {"titulo": "Bodegas", "valor": Bodega.objects.count(), "tono": None, "link": "/bodegas"},
            {"titulo": "Ítems en stock crítico", "valor": criticos, "tono": "danger", "link": "/catalogo-stock?estado=critico"},
            {"titulo": "Préstamos activos", "valor": prestamos_activos.count(), "tono": None, "link": "/historial"},
        ]
        for s in pendientes[:5]:
            notificaciones.append({"tipo": "pendiente", "link": "/solicitudes",
                                   "texto": f"{s.trabajador.nombre_completo} solicita {s.cantidad} × {s.item.nombre}"})
        for s in vencidos[:5]:
            notificaciones.append({"tipo": "vencido", "link": "/historial",
                                   "texto": f"Préstamo vencido: {s.item.nombre} ({s.trabajador.nombre_completo})"})
    else:
        mios = prestamos_activos.filter(trabajador=user).select_related("item")
        tarjetas = [
            {"titulo": "Mis préstamos activos", "valor": mios.count(), "tono": None, "link": "/mis-prestamos"},
            {"titulo": "Solicitudes pendientes",
             "valor": Solicitud.objects.filter(trabajador=user, estado=E.PENDIENTE).count(),
             "tono": None, "link": "/mis-prestamos"},
            {"titulo": "Préstamos vencidos", "valor": mios.filter(fecha_limite__lt=ahora).count(),
             "tono": "danger", "link": "/mis-prestamos"},
        ]
        for s in mios.filter(fecha_limite__lt=ahora + timedelta(hours=24)):
            vencido = s.fecha_limite < ahora
            notificaciones.append({
                "tipo": "vencido" if vencido else "por_vencer", "link": "/mis-prestamos",
                "texto": f"{s.item.nombre}: {'préstamo vencido, devuélvelo' if vencido else 'vence en menos de 24 h'}",
            })

    return Response({"tarjetas": tarjetas, "notificaciones": notificaciones})
