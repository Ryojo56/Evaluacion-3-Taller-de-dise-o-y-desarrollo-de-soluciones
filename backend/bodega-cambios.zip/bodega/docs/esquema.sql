-- Esquema SQL del sistema Bodega (MySQL 8)
-- Generado desde las migraciones de Django. NO es necesario ejecutarlo:
-- 'python manage.py migrate' crea estas tablas automáticamente. Sirve como documentación / diagrama.

SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE `usuario` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `debe_cambiar_password` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `bodega` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacidad` int unsigned NOT NULL,
  `descripcion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsable_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `bodega_responsable_id_1e03b1e6_fk_usuario_id` (`responsable_id`),
  CONSTRAINT `bodega_responsable_id_1e03b1e6_fk_usuario_id` FOREIGN KEY (`responsable_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `bodega_chk_1` CHECK ((`capacidad` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `categoria` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sku` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_minimo` int unsigned NOT NULL,
  `stock_critico` int unsigned NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `creado` datetime(6) NOT NULL,
  `categoria_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  KEY `item_categoria_id_039410a9_fk_categoria_id` (`categoria_id`),
  CONSTRAINT `item_categoria_id_039410a9_fk_categoria_id` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`id`),
  CONSTRAINT `item_chk_1` CHECK ((`stock_minimo` >= 0)),
  CONSTRAINT `item_chk_2` CHECK ((`stock_critico` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `stock` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int NOT NULL,
  `bodega_id` bigint NOT NULL,
  `item_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_unico_item_bodega` (`item_id`,`bodega_id`),
  KEY `stock_bodega_id_8687b127_fk_bodega_id` (`bodega_id`),
  CONSTRAINT `stock_bodega_id_8687b127_fk_bodega_id` FOREIGN KEY (`bodega_id`) REFERENCES `bodega` (`id`),
  CONSTRAINT `stock_item_id_3c6c6cdc_fk_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`),
  CONSTRAINT `stock_no_negativo` CHECK ((`cantidad` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `movimiento_stock` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tipo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad` int NOT NULL,
  `stock_resultante` int NOT NULL,
  `detalle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` datetime(6) NOT NULL,
  `bodega_id` bigint NOT NULL,
  `item_id` bigint NOT NULL,
  `usuario_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `movimiento_stock_bodega_id_7eaf5bbe_fk_bodega_id` (`bodega_id`),
  KEY `movimiento_stock_item_id_6af9431c_fk_item_id` (`item_id`),
  KEY `movimiento_stock_usuario_id_e28fba7f_fk_usuario_id` (`usuario_id`),
  CONSTRAINT `movimiento_stock_bodega_id_7eaf5bbe_fk_bodega_id` FOREIGN KEY (`bodega_id`) REFERENCES `bodega` (`id`),
  CONSTRAINT `movimiento_stock_item_id_6af9431c_fk_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`),
  CONSTRAINT `movimiento_stock_usuario_id_e28fba7f_fk_usuario_id` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `solicitud` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int unsigned NOT NULL,
  `motivo` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_solicitud` datetime(6) NOT NULL,
  `estado` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_entrega` datetime(6) DEFAULT NULL,
  `fecha_limite` datetime(6) DEFAULT NULL,
  `motivo_rechazo` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_devolucion` datetime(6) DEFAULT NULL,
  `estado_devolucion` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comentario_devolucion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `bodega_id` bigint DEFAULT NULL,
  `item_id` bigint NOT NULL,
  `responsable_id` bigint DEFAULT NULL,
  `trabajador_id` bigint NOT NULL,
  `excede_stock` tinyint(1) NOT NULL,
  `stock_al_solicitar` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitud_bodega_id_5d1d8747_fk_bodega_id` (`bodega_id`),
  KEY `solicitud_item_id_7e000e2a_fk_item_id` (`item_id`),
  KEY `solicitud_responsable_id_d5ae18d5_fk_usuario_id` (`responsable_id`),
  KEY `solicitud_trabajador_id_ba38b7a7_fk_usuario_id` (`trabajador_id`),
  KEY `solicitud_estado_e3f48d_idx` (`estado`,`fecha_limite`),
  CONSTRAINT `solicitud_bodega_id_5d1d8747_fk_bodega_id` FOREIGN KEY (`bodega_id`) REFERENCES `bodega` (`id`),
  CONSTRAINT `solicitud_item_id_7e000e2a_fk_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`),
  CONSTRAINT `solicitud_responsable_id_d5ae18d5_fk_usuario_id` FOREIGN KEY (`responsable_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `solicitud_trabajador_id_ba38b7a7_fk_usuario_id` FOREIGN KEY (`trabajador_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `solicitud_chk_1` CHECK ((`cantidad` >= 0)),
  CONSTRAINT `solicitud_chk_2` CHECK ((`stock_al_solicitar` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


SET FOREIGN_KEY_CHECKS = 1;
